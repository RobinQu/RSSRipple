# 错误处理规范

### 响应示例

```json
// 成功
{
  "success": true,
  "data": { "id": "...", "name": "..." },
  "error": null,
  "meta": {}
}

// 失败
{
  "success": false,
  "data": null,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "downloader_id is required",
    "details": { "field": "downloader_id" }
  },
  "meta": {}
}

// 500 内部错误（dev_mode=true 时带 stack trace）
{
  "success": false,
  "data": null,
  "error": {
    "code": "INTERNAL_SERVER_ERROR",
    "message": "Unexpected error",
    "stack": "Traceback (most recent call last): ..."
  },
  "meta": {}
}
```

### 错误码清单

| 错误码 | HTTP 状态码 | 说明 |
|--------|-------------|------|
| `UNAUTHORIZED` | 401 | 未认证或凭证无效（AuthMiddleware 对受保护路径统一返回；OTP 验证码错误同码） |
| `NOT_FOUND` | 404 | 请求的资源不存在 |
| `VALIDATION_ERROR` | 422 | 请求参数验证失败（字段缺失/格式错误/枚举非法） |
| `INVALID_FEED` | 422 | RSS URL 无效、不可达或解析失败 |
| `DUPLICATE_SUBMISSION` | 409 | 表单 Token 已被使用或重复提交 |
| `ALREADY_RUNNING` | 409 | 该 Channel/Agent 的后台任务已在执行中 |
| `DELETE_BLOCKED` | 409 | 资源仍被引用，禁止删除（如作品被 AgentWork 订阅、Library 被整理计划/规则引用） |
| `INVALID_STATE` | 409 | 当前状态不允许该操作（如整理计划仅 pending/failed 可执行/分类/取消） |
| `TRANSMISSION_ERROR` | 502 | Transmission RPC 连接失败或操作失败（含认证失败、磁盘不足等） |
| `MEDIA_SERVER_ERROR` | 502 | 媒体服务器（Plex/Emby/Jellyfin）连接或接口失败（如 `/media-servers/{id}/scan` 扫描时） |
| `LLM_ERROR` | 502 | LLM 调用失败（未配置 Key、超时、响应解析失败） |
| `INTERNAL_SERVER_ERROR` | 500 | 未预期错误；dev_mode 下附 stack trace，生产环境隐藏 |

### 全局异常处理

- 所有 HTTP 异常（RequestValidationError、HTTPException）由全局 exception handler 转换为统一响应格式。
- 未捕获异常统一转换为 `INTERNAL_SERVER_ERROR`，并记录日志（含 request_id、用户、URL、堆栈）。
- SSE 流式端点（`analyze-stream`、`analyze-url-stream`）发生错误时发送 `event: error` 事件：`data: {"code": "...", "message": "..."}`。
- Task queue 中的任务异常被捕获并记录到对应 Channel/Agent 的 `last_fetch_error`/`last_run_status` 字段，不抛出到全局。

---


### RATE_LIMITED（429）

OTP 尝试超出持久化来源或全局额度时返回统一错误结构，code 为 RATE_LIMITED，并携带 Retry-After（秒）。HTTP 异常处理器保留 exc.headers；401 仍表示验证码错误。额度数据库故障按既有 500 处理，不绕过额度继续认证。

### 浏览器状态变更来源防护

对 `/api/v1/` 的非 GET/HEAD/OPTIONS 请求，在认证和业务副作用前核验来源：Origin 必须为当前请求同源或 `CORS_ALLOWED_ORIGINS` 精确白名单；拒绝 null、非法或重复 Origin。没有 Origin 时核验 Referer 的 origin；两者皆无时拒绝 Sec-Fetch-Site 明确 cross-site/same-site。完全没有浏览器来源信息的程序端调用保持兼容；来源可信不能代替认证。显式 API-key 头不会绕过不可信来源限制，避免伪造空头使 Cookie 保护失效。

拒绝返回 403 `FORBIDDEN`、统一响应结构，不执行登录/退出或业务写入，不发送清 Cookie 头。CORS 仍决定浏览器是否可读该响应；不可信来源一般只能观察 fetch 失败。反向代理需正确传递并由受信代理配置还原外部 scheme/Host；不得把任意外部 Forwarded 头直接当可信 origin。
### Turso HTTP 冲突重试与请求重放

HTTP 重试层按实际消费保存请求分块，冲突重试从首块重放并继续未读流；超过 1 MiB 的缓存自动转私有临时文件，IO 在线程执行，请求结束/取消时关闭。只重试已识别锁/MVCC 冲突，最多五次，沿用退避；响应已开始或客户端已断开后不重试，其他异常/取消原样传播。WebSocket/lifespan 不进入 HTTP 重放。

这不是跨提交点的分布式事务：端点在冲突前已提交或发出外部副作用时，仍依赖各业务路径自己的幂等/事务边界。重放不能撤销既有副作用，不宣称将任意端点变成可安全重试操作。
