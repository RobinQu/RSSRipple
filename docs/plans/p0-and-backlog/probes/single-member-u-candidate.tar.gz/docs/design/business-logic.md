# 核心业务逻辑

旧集数协调 `reconcile_stale_raw_episodes` 在入口、逐个资源发布前和内部 commit 前验证队列所有权。失权向调用方传播，调用方事务回滚集数修订及资源发布记录；不能仅依赖后续 backfill 的提交保护，因为协调函数会提前提交。

HTTP 种子下载后的缓存目录创建、bencode 校验和磁盘写入通过 asyncio.to_thread 执行，避免这些同步操作占用队列事件循环。此改动仅治理该入口；取消协程不能停止已经启动的线程，文件发布隔离及其余同步检查路径仍须验证。

HTTP 种子新缓存路径为 `<resource_id>-<sha256(content)>.torrent`。同目录唯一临时文件完整写入后 os.replace 原子发布，失败清理临时文件；不同内容不共享最终路径，取消后的旧线程不能覆盖新内容路径。数据库仍通过 torrent_file 引用实际路径，旧缓存路径可继续读取。取消或进程终止产生的未引用文件回收仍须验收。

ensure_torrent_cached 的缓存命中路径也将文件存在检查、读取校验及无效文件删除移至线程；资源 ORM 字段更新仍在调用协程内执行，不把数据库 session 传入线程。未引用缓存的通用回收尚未实现，不得仅按文件年龄删除可能在途的文件。

maybe_inspect_torrent 的缓存存在检查、无效文件删除、parse_torrent_files 和 analyze_torrent_files 在工作线程执行。仅传入路径或普通文件清单，不传 ORM 对象/session；分类、指派和关联持久化仍在调用协程内。响应性测试使用录制种子及可控阻塞，不替代真实 Redis 租约接管验收。

### RSS 抓取流程（fetch_service）

入口：`fetch_channel_resources(channel_id: str)`，由定时任务或手动触发入队。

```
fetch_channel_resources(channel, db)
  │
  ├─ 1. 更新 channel.last_fetch_status = "running"
  │
  ├─ 2. 使用 feedparser 在 asyncio.to_thread 中抓取 RSS（超时 30s）
  │     ├─ 抓取失败 → 标记 channel.status="error"、记录 last_fetch_error → 返回
  │
  ├─ 3. 遍历 entries：
  │     ├─ a. 计算 guid（缺则用 link 或 title_raw 兜底）；查询是否已存在 → 跳过
  │     ├─ b. parse_entry(entry, channel.field_mapping) → 解析出各字段
  │     │     # 用户自定义 regex 一律按 re.IGNORECASE 匹配（"1080P"/"1080p" 等价）；
  │     │     # 解析后 resolution 统一正则化为小写 "Np" 形式（"1080P"→"1080p"，
  │     │     # "1920x1080" 等原样保留），降低订阅条件的编写成本
  │     ├─ c. 兜底提取 torrent_url：从 enclosure/link 中找 magnet 或 .torrent
  │     ├─ d. 创建 FileResource 对象（parsed_at = now）
  │     │     # 预解析同步内联：detect_batch / extract_compilation_work_title /
  │     │     # detect_subtitle_langs / detect_absolute_episode；合集命中即置
  │     │     # is_batch + batch_scope="season"（标题层默认，torrent 分析可修正）
  │     │     # 并清空 episode；全N季/N-M季整季标记（detect_season_span）
  │     │     # 额外落 batch_scope="multi_season" + batch_seasons=覆盖季集合
  │     │     #（覆盖度已知即可派发，torrent 分析可修正）
  │     ├─ d2. torrent 缓存与通道 A 内容检测（metadata 匹配前，工作锁之外）：
  │     │     # ① 一律缓存：所有 http(s) 直链资源先 ensure_torrent_cached
  │     │     #   （先 bencode 校验完整 payload，只有有效清单才落盘
  │     │     #   TORRENT_CACHE_DIR 并写回 torrent_file；已有缓存先校验，
  │     │     #   无效缓存删除后再尝试下载；magnet/下载失败静默——超时 20s，
  │     │     #   瞬时失败（超时/连接/非 200）自动重试一次，非 bencode/超限/
  │     │     #   写盘失败不重试），保证后续
  │     │     #   文件清单查询（GET /resources/{id}/files）无需重新下载；
  │     │     #   手动修订/确认端点（PATCH episode / PATCH 资源 /
  │     │     #   PUT associations）在 commit 后、入队定向运行前对
  │     │     #   torrent_file 缺失的 http(s) 资源 best-effort 重建缓存
  │     │     #   （ensure_torrent_cached + maybe_inspect_torrent，失败静默）
  │     │     # ② 合集分析门控：maybe_inspect_torrent 对 is_batch=false 的
  │     │     #   资源、以及已判合集但信息不完整（batch_scope 为 NULL，或
  │     │     #   scope="season" 缺 episode_start/end）的资源跑 bencode 解析
  │     │     #   文件清单 → analyze_torrent_files 判
  │     │     #   scope（season/multi_season/franchise）并补齐集数范围
  │     │     #   （season 分支对已链接且可验证单季的作品补 season=1；
  │     │     #   single/unknown 不降级既有合集判定），franchise 触发
  │     │     #   franchise_service.link_franchise_pack（成员作品逐个走
  │     │     #   process_title_only 匹配落库 → get-or-create franchise_pack
  │     │     #   来源 WorkCollection → 资源挂 collection_id、作品 FK 全清）。
  │     │     #   通道 B（下载后 RPC 修正）为保留优化项未实现。
  │     │     # ③ magnet 元数据解析：magnet: 链接无 .torrent 可缓存——
  │     │     #   enqueue_resolution 入队 resolve_magnet_torrent 后台任务
  │     │     #   （app/services/magnet_resolve.py，libtorrent upload_mode
  │     │     #   仅取元数据不下载 payload，超时默认 900s），由分离 worker 池
  │     │     #   （信号量并发 MAGNET_RESOLVE_CONCURRENCY，不占队列槽位）
  │     │     #   重建标准 .torrent 进同一缓存目录并写回 torrent_file，
  │     │     #   成功后经同一 maybe_inspect_torrent 跑通道 A；失败按
  │     │     #   MAGNET_RESOLVE_MAX_ATTEMPTS 自动重试（60s 间隔），状态/
  │     │     #   错误/次数落 FileResource.magnet_resolve_* 四列；
  │     │     #   每小时 sweep（magnet_resolve_sweep，双后端均注册）先回收
  │     │     #   卡死行（pending/running 且 updated_at 超过
  │     │     #   (1+max_attempts)*timeout + max_attempts*60s + 600s 安全
  │     │     #   余量——worker 崩溃/重启后分离任务随之消亡，认领 UPDATE 与
  │     │     #   手动重试又都排除 pending/running，不回收将永久卡死；
  │     │     #   回收置 NULL/清计数/记中断错误），再补扫 status IS NULL
  │     │     #   的存量 magnet 资源（单次 ≤50，含刚回收行）；手动重试
  │     │     #   POST /resources/{id}/magnet-resolve（重置计数再入队，
  │     │     #   pending/running 中 409，非 magnet/无 libtorrent/功能关闭
  │     │     #   422）。tracker 注入：抓取的 TPB magnet 无 tr= 参数（解析
  │     │     #   只剩 DHT），每次尝试合并 magnet 自带 + 手动重试自定义
  │     │     #   （严格校验 udp/http(s)+host，存 magnet_resolve_trackers，
  │     │     #   done 清空、failed 保留供下次预填）+ 默认公共 tracker 清单
  │     │     #   （MAGNET_RESOLVE_DEFAULT_TRACKERS，去重保序，trackers 与
  │     │     #   tracker_tiers 同步赋值；默认清单以
  │     │     #   http://tracker.opentrackr.org:1337/announce 打头占 tier 0——
  │     │     #   DHT 与 udp:// tracker 均依赖 UDP 出网（防火墙常封），
  │     │     #   http 形式走 TCP，UDP 被封锁的部署也能解析）。
  │     │     #   infohash 缓存镜像快速路径（P2P 之前的 step 0）：
  │     │     #   MAGNET_RESOLVE_CACHE_MIRRORS（默认 itorrents.org，空列表
  │     │     #   关闭）按 {infohash} 模板 HTTPS GET 缓存的 .torrent
  │     │     #   （15s 短超时，秒级 vs P2P 最长 15min；base32/v2-only
  │     │     #   magnet 无 v1 hash 静默跳过）；镜像对未知 hash 会 200 返回
  │     │     #   无关 torrent，故必须结构校验 + 重算 v1 infohash 比对
  │     │     #   （sha1(bencode(info))，bencodepy 输出即规范序）不符即弃；
  │     │     #   全部镜像失败静默回退 P2P，快速路径永不抛错。
  │     │     #   libtorrent 为运行时可选依赖：import 守卫，缺失时
  │     │     #   只记一次日志、状态永不迁移。失败静默，绝不阻塞抓取。
  │     ├─ e. 统一 Metadata Agent（通过 LangGraph ReAct 循环，单次调用完成标题清洗 + 单数据源 metadata 搜索）
  │     │     agent = UnifiedMetadataAgent()
  │     │     await agent.process(resource, channel, db)
  │     │     # Agent 内部完成：标题清洗 → episode/season 推断 → 选择唯一数据源搜索
  │     │     # 生产抓取使用频道主数据源（wikipedia/tmdb，默认 wikipedia）；
  │     │     # 评测/手动搜索与业务统一选择 tmdb/wikipedia/bangumi
  │     │     # 结果写入 resource.search_title, episode, season, series_id/movie_id
  │     │     # 并通过 MetadataCache(source="metadata_agent") 缓存
  │     ├─ f. fetch_and_link_metadata(resource, channel)  # 详见 Metadata 匹配流程
  │     ├─ g. 若 LLM 返回 poster_url 且为 http(s) URL → 下载到 POSTER_CACHE_DIR
  │     │     文件名: {sha256(url)[:16]}.{ext}，保存路径相对于 POSTER_CACHE_DIR
  │     │     更新 series.poster_url = /posters/xxx.jpg
  │     └─ h. db 批量提交
  │
  │     # 并发说明：e–h 的 metadata 处理按资源在独立短会话中并发执行（上限
  │     # MAX_METADATA_CONCURRENCY=4），但同一作品（规范化 search_title 相同）
  │     # 的资源在进程内串行锁下逐一处理并在锁内提交——否则多个同作品资源并发
  │     # 查不到彼此尚未提交的 series/movie 行，会重复创建同一作品的记录。
  │     # 跨进程（PostgreSQL 多副本）的重复仍由每日 04:00 dedup 兜底。
  │
  ├─ 4. 更新 channel.last_fetched_at = now, last_fetch_status="success",
  │        status = "active", last_fetch_error = null
  │
  └─ 5. 为该 channel 下所有 status="active" 的 Agent enqueue run_agent
```

### Resource Parser（字段映射解析引擎）

入口：`parse_entry(entry, field_mapping)`（`app/services/resource_parser.py`），按 Channel 的 `field_mapping` 配置把 feedparser entry dict 解析为 FileResource 字段。

支持两种格式：
- 新格式：`{"list_locator": {...}, "field_mappings": {field: {source, regex?, group?, transform?}}}`
- 旧格式（兼容）：`{field_name: {source, regex?, ...}, ...}`，整个 dict 视作 field_mappings。

单字段提取流程（`_extract_value`）：
1. `_resolve_source(entry, source)`：支持点路径与数组索引（如 `enclosures[0].url`）；路径任一段解析失败返回 None。
2. 可选 `regex` + `group`（默认 0）提取；一律按 `re.IGNORECASE` 匹配；正则不命中返回 None。
3. 可选 `transform`：`int` / `float` / `iso_datetime` / `lowercase` / `uppercase`；数值/时间转换失败返回 None。

其他约定：
- 单字段提取异常只记 debug 日志并置该字段为 None，不影响其他字段。
- `_postprocess_parsed` 把 `resolution` 统一为正则化小写 `Np` 形式（`"1080P"`→`"1080p"`；`"1920x1080"` 等原样保留）。
- `normalize_parsed_fields(title_raw, parsed)` 对 LLM 生成的 field_mapping 常见 regex miss 做**保守修复**：仅当 `title_cn`/`title_en` 泄漏方括号（多 bracket 标题只剥离了首个 `[...]`）时，从 raw title 重切作品名分段回填（`search_title` 优先取 latin 段）；并只在 tech 字段（resolution/source/video_codec/audio_codec/container）为 None 时从 raw title 补齐。已干净解析的资源不受影响。字幕组规范字段为 `subtitle_groups` 列表；联合发布先按连接符拆候选，无法由已注册名称确定时保留原值并标记 unresolved，再由受约束 judge 选择候选，确认结果自动登记映射表。
- 同模块的 `extract_episode_fallback` 提供 episode/season 通用回退（`normalize_parsed_fields` 在 episode/season 为 None 时调用）：覆盖方括号集号 `[NN]`（限 1-3 位数字，允许发布变体后缀 `[01a]`/`[02v2]`，`[1080p]`/`[2026]` 不误判）、`SxxExx`、`Season N`、`N(st|nd|rd|th) Season`（如 "2nd Season"）、`S N`、`第N季`（含中文数字）。版本/字母后缀不写入集号，仅保留数值集号，且不参与去重。各频道 field_mapping 的 episode 正则通常只覆盖 `- NN` 形式，该回退保证 fansub 方括号编号在抓取期即可解析；存量修复见 `scripts/repair_episode_parse.py`。字幕组仍以标题/频道映射为第一来源；通用标题回退支持 `[Group]`、`【Group】`、`［Group］` 三种开头括号且不覆盖已有值。标题没有结果时，torrent 文件清单富化阶段调用 `extract_subtitle_group_from_filename` 识别海外发布常见的 `...-GROUP.mkv`/`...[GROUP].mkv` 尾缀，过滤纯数字和 codec/source 技术词，并且只有整份 torrent 得到唯一一致组名时才回填 `FileResource.subtitle_group`。
- 对已关联 TV 单文件资源，torrent 清单中的确定性文件名集号（包括 `[01a]`）还会回写资源级 `season/episode`（`episode_confidence=raw`）；电影和音频资源不套用该规则。
- 同模块还提供抓取期预解析器：`detect_batch`（合集识别；除既有集数区间/批次关键字/整碟季包规则外，含整季标记 `全N季`（全+汉字/阿拉伯数字+季，如"全六季"）与 `N-M季`（如"1-6季"）——`季` 后缀强制，"全12话"/年份对 `[2020-2024]` 不误判；`detect_season_span` 返回覆盖季集合（全N季→1..N），抓取管线据此落 `batch_scope="multi_season"` + `batch_seasons`）、`detect_absolute_episode`（`NN(MM)` 双标记提取）、`detect_subtitle_langs`（字幕语言 BCP-47 标签）、`strip_season_from_title`（去尾部季后缀，含 Stage 序数/序数词后缀——" Second Stage"/" 2nd Stage"/" Final Stage" 同样剥离，两级标题兜底与 bangumi `_autolink_subject` 基础名比对据此对 Stage 命名生效），语义详见 data-models.md 的合集与集号 reconciliation 章节。共享季标记入口 `_season_marker`（`season_from_title` 与 `extract_season_episode_from_path` 共用）另识别英文序数 Stage 季标记（`(first|second|…|tenth) Stage` → 1..10，兼容 `2nd Stage` 数字序数；**"Final Stage" 刻意不映射季号**——词面推不出季号，猜错比不猜糟）。

### Metadata 匹配流程（metadata_service）

标题解析对明确的中/拉丁双语分隔符（`/`、`／`）做保守拆分，去除季号、合集范围和技术尾缀后回填缺失的 `title_en`/`search_title`，不覆盖已有值。`FLAC`、`ALAC`、采样率和位深仅是编码质量信息，不能单独把资源判为 AudioWork；音频类型须由 ASMR、Drama CD、Radio、OST、Soundtrack 等语义标记或 metadata 结果确认。AudioWork 不参与 TV 合集范围校验，已链接 AudioWork 不进入自动未匹配回填。

Metadata source 的 `found=false` 不是作品标题匹配证据，不得用其 `clean_title` 覆盖 parser 已得的 `FileResource.search_title`，空值也不从失败 verdict 回填；只有确认命中才允许细化搜索标题。但发布标题解析与作品搜索结果相互独立：verdict（包括缓存的 `not_found`）若识别出 `subtitle_group`，应在资源字段为空时回填，已有频道映射或人工修订值不得覆盖；该回填须先于本地作品标题短路，避免旧 miss 被历史作品证据纠正时丢失有效字幕组。作品级标题短路索引除 TVSeries/Movie 自身标题与 aliases 外，还收录 `metadata_matched_at` 非空、无 collection 的历史已链接 FileResource 的 `title_cn/title_en/search_title`，把同频道过往成功修订/匹配形成的译名与罗马字拼写作为确定性别名；同一别名指向多个作品时仍按 ambiguous 排除，绝不猜测。

缓存命中顺序区分 verdict：成功与 `non_work` 可直接返回；普通 `not_found` 必须先让上述本地历史标题索引尝试短路，只有仍未识别时才应用缓存 miss，避免较早的搜索失败压住后来形成的人工修订/兄弟资源成功证据。franchise 资源一旦进入 collection 形态，随后普通 title-level metadata 即使命中单个作品也不得恢复 `series_id/movie_id/audio_work_id`，collection 所有权与 flat FK 互斥不变量始终优先。

入口：`fetch_and_link_metadata(db, resource, channel)`。

```
fetch_and_link_metadata(resource, channel, db)
  │
  ├─ Layer 1: 已链接 → 直接返回
  │     if resource.series_id or resource.movie_id: return
  │
  ├─ Layer 2: ChannelRawTitleMapping（search_title_key 优先，raw_title fallback）
  │     search_key = normalize_title(extract_search_title(resource))
  │     mapping = db.query(ChannelRawTitleMapping).filter_by(
  │         channel_id=channel.id, search_title_key=search_key
  │     ).first()
  │     if not mapping:  # 兼容旧数据
  │         mapping = db.query(ChannelRawTitleMapping).filter_by(
  │             channel_id=channel.id, raw_title=resource.title_raw
  │         ).first()
  │     if mapping:
  │         写入 resource.series_id/movie_id
  │         若 mapping.search_title_override: resource.search_title = 覆盖值
  │         return
  │
  ├─ Layer 3: 本地 DB 精确/模糊匹配
  │     search_title = resource.search_title or resource.title_raw
  │     candidates_series = []
  │     candidates_movie = []
  │
  │     # 精确匹配 title_cn / title_en
  │     exact = query(TVSeries).filter(
  │         or_(TVSeries.title_cn == search_title, TVSeries.title_en == search_title)
  │     ).all()
  │     if exact: pick best → 写入 resource.series_id; return
  │     # Movie 同理
  │
  │     # 模糊匹配 title_cn/title_en/aliases，fuzz.ratio >= 70
  │     fuzzy_hits = []
  │     for series in all_series:
  │         titles = [series.title_cn, series.title_en, *(series.aliases or [])]
  │         best_ratio = max(fuzz.ratio(search_title, t) for t in titles if t)
  │         if best_ratio >= 70: fuzzy_hits.append( (best_ratio, series) )
  │     if fuzzy_hits:
  │         按 ratio 降序取 top1；若 top1 ratio >= 85 自动链接——但有两道守卫：
  │           ① resource.title_year（标题解析出的年份）与作品 start/release 年份
  │              相差超过 ±1 → 不自动链接（同名翻拍/重启防护，如 攻壳机动队 2026）；
  │           ② 归一化 search_title 同时精确等于 >1 个本地作品的 title_cn/title_en
  │              （TVSeries+Movie 合计）→ 不做 top-1 自动链接。
  │           被守卫拦截的候选与 70-84 分一样 fall through 到 Layer 4。
  │         否则跳过（留 LLM 层处理，避免误匹配）
  │     # Movie 同理
  │
  ├─ Layer 4: 统一 MetadataAgent（仅当 channel.metadata_agent_enabled == True 时执行）
  │     调用 UnifiedMetadataAgent.process() — ReAct 循环
  │     数据源：频道、评测与手动搜索统一使用 wikipedia/tmdb/bangumi；三主源未命中可走受可信站点约束的 wigolo 回退
  │     单次执行只允许调用所选数据源的工具，不做跨数据源级联或 fallback
  │     结果直接写入 resource.series_id/movie_id 并写 MetadataCache；
  │     若首选结果被 agent 标记为 work 级 ambiguous（`ambiguous: true`）→ 不链接，
  │     记录 not_found，保持可手动 link
  │
  └─ 全部失败 → resource 保持未链接（series_id/movie_id 均为 null）
```

人工标题映射也适用于默认 UnifiedMetadataAgent 路径，先于成功缓存和自动匹配。有效电影/季作品人工映射优先于标题音频判形，即使强制刷新也不能绕过。资源并发快照包括 is_batch/batch_scope，查询期间改变合集形态时放弃旧单作品候选。缓存和本地作品快捷返回同样必须在应用候选及缓存解析字段前核验资源与映射，不能绕过并发编辑保护。强制刷新在外部查询前只读取映射，不能先应用关联而使 autoflush 跨网络持有资源写锁；查询后锁定并核验资源及映射，发生变更则放弃旧候选，再应用仍有效的人工关联。外部候选写入使用保存点；并发合并导致外键失败时，仅在回滚并刷新后确认映射确已改变才放弃候选，其他完整性错误继续上抛。普通已有链接保持 Layer 1 优先；强制刷新可补齐人工目标的元数据，但候选类型或季作品目标冲突时不得创建替代作品或改变关联，资源候选字段随保存点回滚。franchise 资源不进入单作品匹配：保留合集、resource_work_links 和 resource_file_assignments，清除退役的扁平作品 FK；该约束同样适用于直接 metadata GET，不依赖抓取外层收尾。

**Bangumi 频道源匹配流程（`metadata_bangumi`，镜像 wikipedia 的 search-then-judge 形态）**：复用 wikipedia 的 query 清洗（`_candidate_queries`）→ `POST /v0/search/subjects` 限 `type=[2]`（动画分类，命中即动漫）→ 确定性 auto-link（归一化标题相等 + 标题年份守卫 ±1，**唯一命中**才免 LLM；**季感知**——Bangumi 一个 subject 就是一季，资源/刷新提示带季号 >1 时基础名条目（恒为第一季）永不 auto-link，仅"候选标题自带同季标记且基础名命中查询"的唯一候选可免 LLM，其余交 judge）→ 否则单次 LLM judge（专用 prompt `_BANGUMI_JUDGE_SYSTEM_PROMPT`）→ 命中条目经详情（`GET /v0/subjects/{id}`）+ 剧集（`GET /v0/episodes` 分页）端点展开为 matched_entity：`external_id=bangumi:{id}`（身份证据自动落 `is_anime=True`）、title_cn=name_cn、original_title=name、description=summary、rating=rating.score、start_date=date、number_of_episodes=eps、genre=tags（出口钳制）、`is_anime=True`；TV 条目不伪造 `seasons`/`number_of_seasons`，而携带仅在本次匹配链路使用的 `single_season_entry=true`——Bangumi 的一个 subject 本身就是一季（作品单季化后该语义固化为注册表粒度 `granularity="season"`：`bangumi:{id}` 身份直接落**季作品**袋，匹配即得对应季作品），因此标题无季标记时可由统一缺季规则安全补季号，同时不污染作品级总季数；platform=剧场版时不写该证据。episode_list 取本篇（type=0）条目：集号优先用季内 `ep`，缺 `ep` 回退全局 `sort`——后续季 subject 常沿用全系列连续编号（如第三季条目 sort=25-36 配 ep=1-12），若整列最小值 >1 则按最小值 rebase 为 1..N（`_episode_list_from`），同时携带 `airdate` → `air_date`；season 标签用资源解析出的季号（无则 1）；platform=剧场版 → content_type=movie。found=False 走统一有序网络搜索回退（仅补身份）；缓存命名空间 `metadata_agent:bangumi`；手动搜索/评测（`process_title_only`）同样支持，手动搜索响应保留 `single_season_entry` 供链接时判定。客户端 `bangumi_client`：UA 固定 `robinqu/RSSRipple`，token 走 `runtime_config.bangumi_api_key`（env `BANGUMI_API_KEY` 或设置页覆盖），API 基础地址走 `settings.bangumi_api_base`（env `BANGUMI_API_BASE`，默认 `https://api.bgm.tv/v0`，可指向镜像/mock），无独立启用开关——token 即启用。

**Bangumi 关联条目扩展（系列图谱，`bangumi_relations`）**：Bangumi 一个 subject 就是一季，franchise/multi_season 合集包链接到基础条目（如「頭文字D First Stage」）只覆盖了第一季；本 pass 经关联条目端点（`bangumi_client.get_subject_relations` → `GET /v0/subjects/{id}/subjects`）把同 IP 的其余条目展开成完整系列图谱。**触发条件保持收敛**：仅 `is_batch` 且 `batch_scope ∈ {franchise, multi_season}` 且已链接 bangumi 身份的资源（种子取自互斥 FK、`resource_work_links` 与 franchise 包的合集成员；主列或身份袋中的 `bangumi:{id}` 均可），挂载点为 `_process_resource_metadata` 链接后（`bind_single_work_assignments` 之后、commit 之前），单集资源不增加任何 API 调用。从种子 BFS 遍历关系图（上限 24 节点），**续集/前传/主线故事节点入队前先过同 IP 闸门**（Bangumi 的续集边会跨 IP——頭文字D Final Stage → MFゴースト）：候选条目剥离季标记后的归一化基础名（`strip_season_from_title` + `normalize_title`，name/name_cn 双语都试）必须与种子作品基础名相等或互为包含（"Final Stage" 类无数字季标记但含基础名的仍通过）；未过闸门的节点不 upsert、不 link、**不再从其继续 BFS**（整个异 IP 子图被隔绝），空气日期阈值与日期排序也只在过闸节点集合内计算（异 IP 节点的更晚日期不再把阈值推过合法的无标记续集）。随后按关系类型 + 条目 platform 确定性映射（`classify_work_shape`，franchise 成员解析共用同一函数、relation 置 None 时仅凭 platform）：**续集/前传/主线故事** → 季作品（季号优先取条目自身标题季标记——`season_from_title` 含 Stage 英文序数；无标记条目仅在播出日期严格晚于全部有日期标记条目时按日期序续排季号——如 Final Stage 接 Fifth 之后得 6；仍不可定跳过记 warning，绝不猜）；**剧场版** → Movie 作品；**番外篇**（OVA/spinoff）→ 同合集 `season_number=0` 季作品——`(collection, season 0)` 槽位只能有一个作品：**按播出日期最早者占槽**；其余不同身份的番外条目 upsert 为各自单季壳合集（series_group，season_number=1）的作品，仍经 `resource_work_links` 链到资源（跨合集 links 合法，`sync_resource_collection` 按既有语义把 season 系 scope 的资源 `collection_id` 置空，如实反映跨合集）；**不同演绎/重制**（如 Legend 新剧场版 vs Third Stage）→ movie 形态时保持独立 Movie 条目（不合并不降级），TV 形态跳过。所有成员经既有 upsert 入口创建/链接（`create_or_update_series_from_external` 带 season_hint——`season_hint=0` 为合法特典季号，不再被真值链吞掉；电影走 `create_or_update_movie_from_external`），身份走 bangumi 逐季粒度，creator-wins 主 id、身份袋与人工编辑保护不变；**创建季作品前先按 `(目标合集, season_number)` 查成员复用**（命中且成员无冲突 bangumi 身份时仅补身份入袋，不新建重复季作品）；袋命中作品带陈旧默认季号（成员解析对无季标记条目的 s1 猜测）时，图谱的确定性季指派会**订正 `season_number`**（人工编辑过的除外、目标槽位被占除外）；同样地，种子作品的季号若出自该默认猜测（标题带限定词但无季标记——`_season_is_default_guess`，season 0 的 OVA 形态证据除外），不计入 marked/日期证据集合并可作为普通节点重新入图接受指派（`_assign_seasons` 只见过滤后的证据种子）。落入单成员 `series_group` 壳合集的成员经 `try_absorb_shell_collection` 并入目标合集；占用作品的合集若为**同基础名的 auto 合集**（series_group/franchise_pack，归一化基础名相等或互为包含，多成员也允许——两者本就是同一 IP 的重复物）经 `try_absorb_same_name_collection` 整个并入（身份袋/aliases 去重合并、季槽位冲突的成员留在原合集、有 `manually_edited_fields` 的不吸收只记 warning）；**两个吸收函数删除合集行前都会把 park 在其上的 `FileResource.collection_id` 显式重挂到存留合集**（ORM 的删除置空只覆盖当 session 加载的作品成员，资源不重挂会留下悬空外键）；解析到**其他真实合集**的作品保留但不链接（s0 槽位占用后的番外壳作品除外——跨合集 link 是如实表达）。资源侧经 `resource_work_links` 建立多关联（`source="auto"`，manual/llm 行永不动；种子作品自身也补 link——multi_season 覆盖度键读 links 表），随后 `sync_resource_collection` 沉淀 `resource.collection_id`（franchise 不碰）、`batch_seasons` 取并集镜像（含 season 0，只增不减）。**仅扩展、不降级**：关系拉取或单成员展开失败静默记日志，原链接判定完全保留，幂等可重跑。图谱扩展之后紧跟一次幂等的簇级绑定复跑（`bind_hint_clusters`）：torrent 检测期的首跑发生在 metadata 链接之前，看不到图谱新建/改判的作品——复跑让未绑簇（如 "Initial D Fifth Stage" 经季标记层命中 s5 成员）对新成员解析，并把已绑 auto 行的 season 镜像到改判后的作品季号（如 Final Stage s1→s6）。

**关联形态与成员解析的配套规则（franchise 成员解析 / 簇绑定侧）**：①franchise 合集标题（`_pack_title`）只用清洗后的作品名——优先 `search_title`/`title_cn`，否则原始标题经发布信息 token 清洗（剥括号块、全N季/季范围/季标记、语言/字幕/清晰度/编码分节丢弃），含「全六季.日语.英文字幕.[BD][1080p][AV1]」的原始串禁止成为合集名；②franchise 成员解析与簇绑定的外部命中在 upsert 前**先查本地库**（`find_local_work_for_entity`：身份袋反查 + 归一化标题精确/模糊匹配 ≥ `AUTO_LINK_THRESHOLD` 85，两道拒绝守卫——候选已携带同 source 不同 id 即"同 IP 不同条目"绝不复用，以及标题数字 token 一致才接受——"Extra Stage 2" 不会并入 "Extra Stage"），命中仅补身份入袋（creator-wins 不抢主 id）、不新建重复行；web fallback 保持 identity-only 语义（只补身份，内容以主源为准）；③形态分类两处统一走 `classify_work_shape`（TV→季作品、剧场版→Movie、番外/OVA platform→s0 季作品，bangumi matched_entity 新增随实体携带的 `_platform` 键供成员解析判形态，落库前 pop）；④**带限定词但无数字季标记的 TV 条目**（"頭文字D Final Stage"——`single_season_entry` 只证明"是一季"不证明"是哪一季"）在 upsert 内不再享受单季默认 s1：`_has_unresolved_title_qualifier` 命中时 season 保持 None——合集中有多成员或单成员+限定词时挂合集待确认（袋身份），无合集可归时落各自单季壳合集（season_number=1），季号由系列图谱的确定性指派补正；`_resolve_collection_member` 复用成员前另加同 source 身份冲突守卫（成员已携带同 source 不同 id——含合成 `{id}#s{N}` 的基形式比对；wikipedia 豁免——不同 pageid 是同作品的不同语言版本）——冲突则身份挂合集、绝不合并进错误作品；⑤**图谱季槽位两阶段接纳（C1）**：季节点 upsert 前先跑"既有作品季号纠正"阶段（按节点指派订正默认猜测/簇提示落的错位季号，滚动至 fixpoint 最多 3 轮——`_correct_work_season`，人工编辑与槽位占用守卫不变），再逐节点 upsert 新季作品（纠正分支保留为兜底重试）——"Fifth 槽位被 Final 的簇提示落位占住、Final 随后被改判 s6"的序列下 Fifth/Final 都落位，无重试丢失；⑥**混合 franchise 包合集挂载（C2）**：LLM 精判绑定电影后不再整体跳过 `link_franchise_pack`——跳过条件收紧为纯电影包（精判自身把全电影作品包的 `batch_scope` 升级为 `movies`，franchise 判定分支天然排除），混合包（电影已绑、TV 簇 hint-only）照常建立/复用清洗标题的 franchise 合集并把全部关联作品（含已绑电影）挂入，`resource.collection_id` 沉淀；⑦**同资源同日期电影去重（C4，`dedupe_resource_movies`，挂在系列图谱扩展与二次簇绑定之后）**：成员解析（web fallback 英文标题）与系列图谱（日文标题）可能为同一部电影各建一行且跨语言标题无法桥接——同一资源 links 的电影作品中，**同 IP**（共享合集或 Round A 基础名 family：归一化基础名相等/互为包含）且**日期证据一致**（`release_date` 年份相等；web fallback 行无内容字段时改用其绑定文件路径的 `[YYYY]` 目录年份，单一取值才算）的不同身份行经既有去重合并机器（`_merge_movie_group`：assignments/links/decisions/agent works 重指向、身份袋并集、删重复行）合并——存留方为**频道主源身份行**（随后按 bangumi > tmdb > wikipedia > douban > mal > anilist > imdb > exa_web 次序），creator-wins 恢复存留方主 id/主 source（合并机器的 canonical 主 id 重选被回滚）；**无日期证据绝不合并**；⑧**无季证据 TV 成员不占主合集季槽位（D1）**：franchise 成员解析中，没有任何季证据（标题无季/Stage 数字标记——注意后缀表会剥但不能映射数字的 "Final Stage" 类词在此处只算限定词）的 TV 形态成员**不得**以默认 s1 挂入主合集——只有标题与合集基础名**原文**（不剥季）相等或包含于合集基础名的真基础名条目（"头文字D"/"Initial D" vs 双语合集名"头文字D Initial D"，`_is_pack_base_name`）才允许占 (collection, s1)；其余落限定名壳合集（series_group）并照常 link——否则占位者会让真首季滞留壳合集、季标记层把整季文件错绑到占位作品（"Initial D Battle Stage" 占 s1 → First Stage 26 文件误绑的录制事故）。bangumi/逐季粒度身份经 `classify_work_shape` 落 s0 的番外行为不变；⑨**季标记层限定词兼容（D2，纵深防御）**：season marker tier 选中成员前校验簇 hint 与候选成员标题的限定词残量（标题 token 减去合集名 token 与 hint 基础名 token 的差集；只有映射得出数字的季标记才被剥离——`_strip_numbered_marker`，"Final Stage" 不剥）——成员残量与 hint 残量必须相等（双方皆空=基础名作品，不受限），否则拒绝该层匹配（不绑，hint 保留）。

**Bangumi 手动搜索列表模式**：`POST /metadata/search`（UI 手动搜索，`listing=True`）在 `source=bangumi` 时不走 search-then-judge 收敛管线，直接 `list_bangumi_subjects`（复用 `_bangumi_queries` 查询清洗，多查询合并去重，limit 20，仍限 `type=[2]` 动画分类），每个 subject 映射一条薄候选（身份 `bangumi:{id}`、标题/年份/海报/简介 + `metadata.subject_season` 标注条目自身季标记供前端对照 season_hint），全量返回、不调 LLM；剧场版 platform 的条目 content_type=movie（受请求的 content_type 边界过滤）。作品刷新管线（`refresh_work_by_source`）保持 `listing=False` 的确定性 pick-one 行为不变。列表候选被选定后，preview/apply 检测到 bangumi 身份且候选 metadata 缺 `episode_list` 时按需展开——`build_entity_for_subject`（复用 `_build_matched_entity`：详情+剧集端点，season 取作品自身 `season_number`）补齐完整 entity 再比对（`_expanded_candidate_values`，展开失败保留薄候选、diff 相应变少，apply 内部 preview 复用同一份展开值不重复取网）。

**季号验证规则（season never guessed）**：季号只能来自标题季标记或经元数据证据验证，绝不猜测。

- **Agent-free 链接路径**（Layer 2/3 与 Layer 4 链接成功后的统一链接后步骤 `reconcile_linked_series_resource`，以及 known-work 短路与 `manual_link_metadata`）：历史惯例推断与绝对集号定位之后若 `resource.season` 仍为 None，统一走共享 helper `resolve_missing_work(resource, entity, work=链接作品)`（metadata_episode_reconcile；`resolve_missing_season` 保留为兼容别名）。**链接作品自身身份是最强季证据**（`work_verified_season`：季作品即季——`season_number≠1` 直接可信；`season_number=1` 需单季证据才可信：legacy 惰性列的单季证据或 Bangumi `single_season_entry` 条目证据，`season_evidence_from_series` 对已关联 Bangumi 身份的作品恢复该证据）。裸标题尾缀（如中英标题同时以 `2` 或 `II` 结尾）不在抓取 pre-parser 阶段单独采信；作品链接后，仅当两个不同语言标题的尾缀一致、且作品元数据证明该季存在时，才将其作为经验证的季号。可验证 → 落对应季号；多季或季数未知 → `episode_confidence = "ambiguous"`（进入所属 Channel 的文件资源待确认）；系列级身份只解析到合集而季不可定时，资源由 `park_resource_on_collection` 挂合集待确认（清作品 FK、保留 `collection_id`）。合集资源同样适用上述标题验证与单季默认：`batch_scope` 为 NULL/`season` 且可验证季号时落 `season`，但**绝不标 ambiguous**（多季/无证据保持 season=None，走合集 coverage 待确认门禁）；`multi_season`/`franchise`/`movies` 与 `manual` 行不触碰；电影链接不受影响。torrent 内容检测的 season 分支（`maybe_inspect_torrent`）对已链接且可验证单季的作品同样补季号。存量剧集链接资源用 `scripts/reconcile_season_backfill.py`（dry-run 默认，`--apply` 执行）回填，候选含 scope 为 NULL/season 且缺季号的合集行，不创建 Agent PendingDecision。
- **MetadataAgent 路径**（`_validate_inferred_season` + `_apply_verified_season_default`）：finalize 结果 `content_type=tv` 时先用 `matched_entity` 的 `number_of_seasons`/`seasons` 证据**确定性校验 LLM 给出的 `inferred_season`**——不在 `seasons` 列表内、超出 `number_of_seasons` 范围、或完全无季证据 → 丢弃该季号并置 `season_ambiguous=True`（season 0 特典是结构标记，不校验）；随后 `inferred_season` 为空时做同一判定——恰为 1 季 → `season=1` 并清除 ambiguous；否则置 `season_ambiguous=True` 载体（`ResourceMetadata` 字段，随 MetadataCache 往返）。`_apply_to_resource` 在 upsert 落库**之后**经 `reconcile_linked_series_resource` 完成绝对集号定位（沿合集成员）、单季算术与验证季默认；均得不到季号时落 `episode_confidence="ambiguous"`（合集与 manual 除外）或挂合集待确认。
- **一致性交叉检查**（`apply_episode_reconcile`）：资源同时带 season 与 `absolute_episode` 且 confidence 非 `manual` 时，用 `locate_absolute_episode` 复核；绝对集号算术定位到的 (season, episode) 与现值不一致 → `episode_confidence="ambiguous"`（标题季标记与绝对算术冲突，绝不静默信一方）；locate 返回 None 视为无证据，不改动。
- **历史优先 reconciliation**：已链接作品的单集 TV 资源先用同频道/同作品 `manual|reconciled` 记录推导发布组的 absolute 编号偏移，然后才走作品自身集数算术（季作品的 `number_of_episodes`；legacy 行回退惰性 seasons 列）。证据分两层：**近邻层**——只用目标 absolute 之前 ±2 窗口内的记录（同组相邻 manual 一条即可；跨组需双样本共识），防止同集平行资源互相强化错误解析；**远推层**——近邻无记录时放开距离窗口（双向、排除同 absolute 平行行），但规则只由人工修订锚定：全部 manual 行必须收敛到唯一 `(season, offset)` 约定、且与非 manual 历史不冲突，再经季集数 +2 容差校验才外推（一次人工修正即推广为该剧该发布规律的持久规则，跨周/跨季断档同样生效），冲突继续待确认。对于只有季号缺失的同集发布变体（如同组 E07 简体/繁体/简繁版），同频道+同作品+同发布组的同 episode 人工修订一条即可继承 season；无 manual 时至少两条结构化历史必须同季一致，有冲突绝不默认。**人工修订的即时推广**：`PATCH /resources/{id}/episode` 与 `PATCH /resources/{id}`（发送集号字段）提交前先跑 `heal_sibling_episodes`——同作品+同频道仍处 `ambiguous/raw` 的兄弟资源立即套用新约定批量修复（manual 行与批次不动），随本次定向运行一并派发，不再逐条等人修。全局 5 分钟 metadata backfill 同时扫描可修复的 `ambiguous/raw/reconciled/NULL` 行，修订与 metadata 发布事件同事务提交，之后唤醒 active Agent 普通增量运行，保留历史排除范围。
- **LLM 指引**：系统/judge prompt 与 finalize 工具说明均要求——标题无季标记时必须依据工具结果的 `number_of_seasons`/`seasons` 验证（单季 → `inferred_season=1`；多季 → `ambiguous=true` + `ambiguous_candidates`），且输入带 `title_year` 提示时优先年份一致的候选（年份冲突 >±1 是反对证据）。

`extract_search_title(resource)`（同步、无 LLM；Layer 2/3 的匹配 key 来源）优先级：

1. `title_cn` 或 `title_en`（field_mapping 已解析），剥离尾部季后缀（`第三季` / `S04` / `Season 4` / `3期`）后返回。
2. `title_raw` 正则清洗：去除首个 `[字幕组]` 括号对、按 ` / ` 分隔只取第一个 alt-title 段、依次剥离 `- 集数` 尾部 / `SxxExx` / 游离季标记（`S04`）/ 尾部独立集数 / 尾部单个质量标签括号，最后去季后缀并修剪装饰分隔符。
3. 清洗结果为空时兜底返回原始 `title_raw`。

该函数设计上是保守的：多括号标题（`[Group][Work][S04][13]`）无法用正则可靠分离作品名与发布元数据，交由 LLM agent 处理；本函数只需"足够好"以支撑本地 DB/FTS 匹配和 agent 禁用/失败时的兜底。

`create_or_update_series_from_external(db, data, *, season_hint=None)` 逻辑（作品单季化重写，返回 `TVSeries | None`）：

1. **按注册表粒度分类身份**（`_identity_granularity`，`SourceSpec.granularity`：wikipedia/tmdb/imdb=series 级、bangumi/mal/anilist/douban=season 级、tmdb/douban 电影形态=movie；合成形式 `{id}#s{N}` 拆出系列级 id + 季号）。目标季号判定顺序：`season_hint`（资源解析上下文，`resource_season_hint`：标题季标记优先、双语续作尾缀验证推断次之）→ 合成身份的 `#s{N}` → 实体标题季标记 → 可验证单季证据（=1）。
2. **逐季 id → 作品袋反查**；命中即得季作品（更新分支 `_update_series_from_entity`：字段语义同拆分前——人工编辑保护、creator-wins 主 id、别名合并、海报缓存、genre 钳制、`apply_is_anime`；惰性孤儿 `seasons`/`number_of_seasons` 列**永不写入**，`number_of_episodes`/`start_date`/`end_date`/`episode_list` 全部按季取值）。
3. **系列级 id → 合集袋反查 → 成员选择**（`_resolve_collection_member`）：按 `(collection_id, season_number)` 找成员作品，缺失则**惰性创建**（`_create_season_work`：从父条目 `seasons`/`episode_list` 取该季数据建季作品，基础名入主列、季限定变体进 aliases，袋合成身份 `{系列id}#s{N}`；不物化未出现的季）。合集可验证单季（仅一个成员或实体可验证单季）时无季号也可落定；多季/未知则把系列级 id 落合集袋并**返回 None**——调用方经 `find_collection_for_entity` 找回合集后 `park_resource_on_collection` 挂合集待确认，绝不猜季。
4. **legacy 兼容**：仍袋在/列为未拆分 legacy TVSeries 行主 id 的身份按原样收敛到该行（季拆分迁移负责搬家）。
5. **两级标题兜底**：袋全落空时先以剥季基础标题匹配合集（`_find_collection_by_titles`：归一化标题 + 合集 aliases 的 Python 侧比较，复用 franchise get-or-create 模式）；命中合集后在其成员中按季号选作品（季感知——「第三季」剥季后绝不错撞 S1 作品）；合集也没有才新建「壳合集 + 季作品」。每次成功 upsert 把实体的全部 id 按粒度落袋（`_bag_entity_ids_by_granularity`），合集 aliases 顺带合并（`_merge_collection_aliases`）。
6. web fallback（metadata_web_fallback.py）身份按其注册表粒度落袋（系列级 id 落合集袋），其余不变。

`create_or_update_movie_from_external` 同理。

`create_or_update_audio_work_from_external` 同为幂等 upsert，但带**空壳守卫**：创建新记录时 `title_cn/title_en/original_title` 全空则拒绝（记 warning、返回 None）——LLM verdict 可能偏离 schema 返回无标题的 audio 类 matched_entity，空 AudioWork 没有价值（更新已有行不受限）。对应地，`_apply_to_resource` 的 audio 分支在调用前做两级修补：注入 `meta.content_type`（LLM 的 content_type 在 ResourceMetadata 顶层、从不在 matched_entity 里，缺它创建会错误兜底为 `"other"`）；matched_entity 无任何标题时依次用 `meta.title_cn/title_en/clean_title` 兜底回填。回填后仍无标题则不建 AudioWork、不设置 `resource.audio_work_id`，资源保持未匹配（记 warning）。

### Wikipedia 跨语言收敛（langlinks）

Wikipedia 的 page id 按语言站点独立编号，同一作品的 zhwiki 页面（如 `wikipedia:7727654`"黃泉使者"）与 enwiki 页面（`wikipedia:70545449`"Daemons of the Shadow Realm"）external_id 不同、标题槽各填一个语言，标题回退无法命中 → 同一作品被建成多行。修复：`_execute_get_wikipedia_page` 抓取页面时一并取 **langlinks**（仅 en/zh/ja），search-then-judge 两条 finalize 路径据此：

- 补齐缺失语言的标题槽（auto-link 直接填；LLM judge 仅在对应槽缺失时回填）；
- 把全部 langlink 标题放入 `matched_entity.alt_titles`，upsert 的标题回退与 aliases 合并都纳入它们。

**P3 增强（langlinks pageids 入身份袋）**：wikipediaapi 的 langlinks 只带标题/URL，`_execute_get_wikipedia_page` 额外用 MediaWiki `prop=info` 逐语言解析出 pageid（`_fetch_langlink_pageids`，并行、best-effort），经 `langlink_pageids` 键穿线到 search-then-judge 两条 finalize 路径，作为 `matched_entity.alt_external_ids`（`{source: "wikipedia", id: "wikipedia:<pid>"}`）在 upsert 时全部入身份袋。此后任何语言页的 pageid 命中都直接经袋反查收敛到同一作品行，不再依赖标题。

效果：第二种语言的匹配通过 alt_titles 精确命中已有行实现收敛，且 aliases 一旦带上跨语言标题，每日 04:00 的 metadata 去重（按共享标题/别名聚类）也能自动合并历史重复行。

### Wikipedia 季/集内容提取（Phase P2，确定性解析，无 LLM）

wikipedia 主源频道的**季/集内容一律来自 Wikipedia 页面本身**（源一致性规则：内容不从其他源补；LLM judge 仍只做作品识别，judge schema 不含 seasons）。链路：

1. **抓取**：页面被选中后（search-then-judge 的 auto-link 短路**和** LLM judge 选中两条路径都会走），`_attach_wikipedia_content` 用 `fetch_wikipedia_wikitext`（MediaWiki `action=parse&prop=wikitext`，httpx + Wikimedia UA）取选中页面的原始 wikitext；完全解析失败时经 langlinks 重试**一次**（zh↔ja，剧集列表常只在一侧）。
2. **解析**（`app/services/wikipedia_episode_parser.py`，纯函数）：infobox **仅取 `{{Infobox animanga/TVAnime}}` 块**（zh/ja 同名；块到下一个 `{{Infobox animanga/` 子模板为止；无 TVAnime 块的页面——如史萊姆主页面——返回 None，绝不把 Novel/Manga 块的 話數 当 TV 季数）→ `parse_seasons_from_infobox`（支持 `{{ubl|...}}` 与 `<br />` 分隔、`第N季/第N期/第一季`（汉字序数）、`話數/话数/話数/集數` 字段、全/共、全/半角数字；无季标记的 `全M話` 视作单季、但仅当恰好一个 plain 计数 TV 块）；**播出日期** → `parse_season_air_dates`（TVAnime 块的 `播放開始`/`播放結束`/`放送開始`/`放送終了` 字段，产出 `{season: {air_date, end_date}}`：`第N季` 标记项归对应季（含 cour/篇章后缀——`第1季上半`/`第2期前半クール`/`第4期喪失編` 均归该季，同季多段取最早开始/最晚结束）、季内区间 `開始－結束` 同行解析、错位写在结束字段里的区间同样还原开始日期、悬挂区间符（`2026年8月12日 -`）按开放区间只取开始、结束字段的无标记首项在恰好一季缺结束时跨字段闭合、仅到月/仅到年的片段降级为月首/月末、年初/年末占位日以保年份；无季标记的 plain 日期仅在恰好一个 plain 日期块时归第 1 季，多个 plain 块=独立续作不猜）；`各話列表/各話リスト` 章节 → `parse_episode_list`（zh `{{劇集列表/base}}` 与 ja 规则变体 `{{エピソードリスト/base}}`；`Chapter = 第N季/期` 设当前季，`Number = 第M話`（含汉字数字 `第一話`）成行，Title/Subtitle 去 `{{lang|ja|...}}`/wiki 链接/简单模板，Aux5 解析 `'''2023年'''<br />10月8日` 与续年 `10月15日` 为 ISO 日期）。无 Chapter 标记 → 单季（season=1）；章节内编号若从 >1 开始（跨年绝对编号）则重排为季内 1 起；`番外編` 等无集号行跳过。无剧集章节 → 返回 None。已采样确认 zh/ja 真实页面（100カノ zh+ja、無職転生、小書痴、史萊姆、攻殻機動隊 SAC——后者无剧集章节，按 None 处理）；其余语言/模板形态本阶段不支持（代码注释注明）。
3. **合并进 matched_entity**：`seasons`（infobox 集数权威；剧集列表季数更多时以列表为准——连载中 infobox 滞后）、`number_of_seasons`、`number_of_episodes`（求和）与新键 `episode_list`；逐季播出日期以 `air_date`/`end_date` 键叠加进 `seasons` 条目（季作品 upsert 的 `_work_start_date`/`_work_end_date` 优先读它们）。`ResourceMetadata.from_dict`/MetadataCache 整体携带 `matched_entity`，`episode_list` 随缓存往返不丢失。此外，若实体尚无 `start_date`，从 `episode_list` 最早的非空 `air_date` 派生、再退到 `seasons` 条目最早 `air_date`（series upsert 只认 `start_date` 键）；已有 `start_date` 不覆盖。
4. **落库**：季作品 upsert 在 `episode_list` 存在时调用 `upsert_episodes`（按 `(series_id, season, episode)` 幂等 upsert title/air_date；只增不删；季作品只收本季条目，逐季源实体的条目标到其 `season_number`）。**连续编号防护**：季作品的清单若不以第 1 集起始（前序季连续编号特征）且作品 `number_of_episodes` 已知，超出 集数+2 容差的条目被丢弃并记 warning（防御 `sort` 续号污染）；以第 1 集起始的清单整体可信（开播中作品可超出滞后集数）。存量污染修复走 `scripts/bangumi_episode_repair.py`（dry-run 默认 + `--apply`；在线模式以 bangumi 季内 `ep` 为权威重建清单——删界外行、补缺失行、仅填 NULL/占位标题与日期，顺带用权威清单长度修复滞后 `number_of_episodes`（尊重人工编辑）；`--offline` 仅对"整列续号且行数等于集数"的作品做平移 rebase）。作品单季化后 `series.seasons`/`number_of_seasons` 两列退役为惰性孤儿、**永不写入**——实体的逐季数据改用于：惰性创建缺失季作品时的季级字段（该季 `number_of_episodes`/`start_date`/`end_date` 取自父条目 `seasons` 项与 `episode_list` 子集）与上述 Episode 落库；旧 `seasons_overwrite_allowed` 防退化 guard 随列退役从 metadata_service 删除。
5. **覆盖率评测与回填**：`scripts/wikipedia_seasons_eval.py`（dry-run 默认）对所有 wikipedia 链接的 TVSeries 逐部抓取 + 解析并输出覆盖率汇总；`--apply` 复用同一 `evaluate_series` 读路径执行写回填（批量提交 + `upsert_episodes`）。防退化 guard 已**内联进脚本**（解析季数少于既有行即 `[guard-skip]` 不写入），仅服务季拆分迁移前的存量行——对 wikipedia 主源 legacy 作品取代 `series_seasons_backfill.py` 的 seasons 回填；完成 `season_split_migration.py` 后该回填路径失去意义（新季作品不再携带 seasons 列数据）。**日期回填**走 `scripts/wikipedia_airdate_backfill.py`（dry-run 默认 + `--apply`）：对缺 `start_date`/`end_date` 的 wikipedia 身份季作品重抓页面跑 `parse_season_air_dates`，经 `_work_start_date`/`_work_end_date` 同一语义派生本季日期，只填 NULL 字段、尊重 `manually_edited_fields`；身份解析覆盖 `wikipedia:{lang}:{pageid}`（剥离 `#s{N}`）、legacy 裸 pageid/标题形式（zh→en→ja 探测）、`wikipedia_url`（`/wiki/` 与 `?curid=` 两种形式）与身份袋；链接版本页无日期时依次回退 zh/ja langlink 对应页、`<标题> (アニメ)`/` (動畫)` 动画子页面探测、同合集兄弟季作品的 locator（共享系列级页面），最终回退 bangumi 袋/主身份的按 id 精确查询（季粒度首播日期）。**遗留 wikipedia 身份重扫**走 `scripts/bangumi_rescan.py`（dry-run 默认 + `--apply`）：对 `external_source='wikipedia'` 的季作品经 `refresh_work_by_source` 单一管线以 bangumi 源重扫（只填空字段、尊重人工编辑、candidate 身份按自身 source 入身份袋——bangumi 主源未命中时回退的 mal/imdb/wikipedia 身份同样入袋，已属他作品的报 dedup candidate 不抢），并顺带把 `source` 列与 id 自声明前缀不一致的身份袋脏行重挂到声明源；bangumi 搜索限 TV 动画分类，电影不在范围；宿主机直连数据库运行时需 `--llm-base-url` 覆盖容器内地址、`POSTER_CACHE_DIR` 指向宿主可写目录再人工同步进容器卷。

网络搜索回退仍只补身份/链接（`seasons`/集数继续被剥离），内容以 Wikipedia 主源为准。

### TMDB 季/集内容提取（Phase P4，与 Wikipedia 对称）

tmdb 主源频道的**季/集内容一律来自 TMDB API 本身**（同一源一致性规则）。TMDB series details 只带 `seasons[]`（季数/每季集数），逐集数据需逐季 `GET /tv/{id}/season/{n}`：

1. **抓取**：`fetch_tmdb_episode_list(tmdb_id, seasons)`（`metadata_source_io.py`，httpx）按季并发拉取（并发上限 4，跳过 season 0 特别篇，单季失败容忍仅缺该季，>30 季直接跳过），产出 `[{season, episode, title, air_date}]`——与 wikipedia 解析器同形。
2. **接线**：`_attach_tmdb_episode_list` 在 tmdb ReAct finalize 后（`process` 与 `process_title_only` 两处）触发——仅当 found=True、content_type=tv、matched_entity 携带 tmdb id 且有 `seasons` 且无 `episode_list` 时填充；回退实体 seasons 已剥离，天然不触发（单源规则）。`episode_list` 复用 P2 消费路径（`create_or_update_series_from_external` → `upsert_episodes`），随 MetadataCache 往返。
3. **回填**：`scripts/tmdb_episodes_backfill.py`（dry-run 默认，`--apply` 执行，批量提交）对 canonical `tmdb:` 身份的 TVSeries 跑同一抓取 + `upsert_episodes`；`series.seasons` 缺失时用 TMDB details 补齐输入（不改写 series 字段）。

### 主来源身份接地

Wikipedia judge 和 Wikipedia ReAct 回退共用身份证据选择：按 `(语言版本,pageid)` 去重，主身份必须对应已观察页面；旧裸 pageid 仅在语言唯一时接受并规范化。ReAct 仅采纳成功来源工具的页面数据，语言取自返回的 Wikipedia 页面 URL。重复搜索/详情响应归并为同一页面；类别、页面 URL 和跨语言别名取自来源数据，不能沿用模型编造的身份字段。

TMDB ReAct 仅采纳成功 `search_tmdb`/`get_tmdb_details` 工具消息。搜索候选使用 `external_id/content_type`，详情使用 `tmdb_id/media_type`；必须同时匹配数字 ID 与 TV/movie 类型，互相冲突的类型不提供证据。现有 TMDB 工具未提供跨来源身份，模型输出的别名和 Wikipedia URL 均清除。错误状态、失败工具、畸形数据、无类型身份不能作为依据。

无法确认主身份时，保留标题与诊断，返回可重试的 `found=False` 并清空实体，阻止写入作品及身份袋。缓存 generation=7 使旧 verdict 懒失效，不能据此声称已经清理历史写入的错误身份；已有作品清理需要独立审计。

### genre 归一化（统一分类标签）

作品 genre 统一为 **TMDB 封闭分类集（27 类）英文 canonical 名**，权威清单一处定义在 `app/services/genre_registry.py`（取值约定见 data-models.md「genre 取值约定」）。多数据源归一靠"prompt 注入 + 出口钳制"而非逐源映射表：

- **prompt 注入**：ReAct `_SYSTEM_PROMPT`、wikipedia judge `_JUDGE_SYSTEM_PROMPT`、web fallback judge `_WEB_FALLBACK_JUDGE_SYSTEM_PROMPT` 三处 matched_entity schema 注入 `genre_prompt_block()` 生成的完整枚举清单，LLM 根据外部作品详情（摘要/categories/snippet）一并输出 genre；指令为**尽力推测**——源未显式列标签时须依据简介推断，有简介至少给一个，杜绝"不确定就留空"。judge schema 的 genre description 同步列枚举。wiki auto-link 路径不经 LLM，genre 留空由兜底/回填补齐。
- **兜底推断**：`_ensure_genre`（`metadata_agent.py`）在钳制后仍无 genre 且 matched_entity 有 description 时，用 `genre_inference_system_prompt()` 发一次低成本 LLM 调用按简介分类，结果再过 `normalize_genres`；失败静默不阻塞匹配。由此 judge 留空、auto-link 无 LLM、回退仅身份三条路径产出的作品都能拿到标签。
- **出口钳制**：统一 finalize 消费点 `_clamp_finalize_genre`（`metadata_agent.py`，`process` 与 `process_title_only` 各一处）对 `matched_entity["genre"]` 调 `normalize_genres`——id 直译、大小写不敏感、少量别名，表外值丢弃（debug 日志），空结果置 None 视为"未提供"，genre 绝不阻塞匹配。TMDB 直连的 `_tmdb_genre_map` 动态拉取与注册表取交集、失败回退注册表静态表。同一消费点紧跟 `_normalize_finalize_dates`：确定性日期键名归一——series/tv 无 `start_date` 时依次从 `first_air_date`/`release_date` 补（TMDB 工具结果带 `first_air_date`，LLM 不总按 prompt 键名抄录），movie 对称补 `release_date`；只补空缺、绝不覆盖已有值。
- **写回**：`metadata_service` 全部 genre 写入点（series/movie/audio 的新建/更新、刷新管线 `apply_work_metadata` 填空）先过 `normalize_genres`；非空才覆盖，归一化为空不清空旧值。
- **缓存**：judge schema/指令变更属 verdict 逻辑变更，`METADATA_CACHE_GENERATION` 当前为 7（3=genre 入 schema + 钳制；4=prompt 改尽力推测 + `_ensure_genre` 兜底；6=网络回退候选身份与季集出口保护；7=Wikipedia/TMDB 主来源身份接地及别名证据约束），旧缓存惰性失效重跑。
- **存量**：`scripts/genre_backfill.py`——模式 A（默认）就地规范化既有 genre 数组；模式 B（`--refresh-empty`）对仍为空的 series/movie 调 `refresh_work_by_source` 重跑补齐（身份源为 wikipedia/tmdb 时用原源，否则回退 wikipedia 标题判定；有网络/LLM 成本，`--limit/--delay` 限速）。
- **消费面**：通知 payload `work.genre` 快照同样归一化；Filter DSL 新增 `series.genre`/`movie.genre`（list-of-string 逐元素语义，见 filter-dsl.md）。

### is_anime 分层判定（三态动漫标记）

作品 `is_anime` 的取值约定与确定性信号（身份源 / Wikipedia infobox / TMDB / LLM）见 data-models.md「is_anime 判定约定」；本节描述运行时的分层判定。统一入口 `classify_is_anime_post_link`（metadata_service）挂在资源成功链接作品的**全部 5 处落点**（`metadata_repository._apply_to_resource` + metadata_service 匹配流程 4 处：Layer 2 mapping 链接、Layer 3 精确/模糊自动链接两处、Layer 4 LLM 链接）：

1. **频道默认标记**（`apply_channel_default_is_anime`）：`channels.default_is_anime`（创建后不可改）开启的频道，其资源链接到的作品 `is_anime` 先置 True（已有 True 不动）。
2. **第一层 Bangumi 验证**（`maybe_verify_is_anime_via_bangumi`）：未开默认标记的频道，作品 `is_anime` 仍为 NULL 且有 Bangumi token 时，按作品标题（title_cn/original_title/title_en）搜 Bangumi（**不带 type 过滤**，让三次元条目可作实拍证据），`anime_signals.bangumi_verdict` 在归一化标题相等 + 年份守卫（±1，作品年份未知则放行）后按条目类型判定：type 2（动画）→ True、type 6（三次元）→ False、其他类型忽略；已判定（非 NULL）作品跳过；验证异常静默记 warning，不阻塞匹配。
3. **第二层上下文推断**：既有信号经 `apply_is_anime` 在 upsert 时赋值（True sticky / False 只填 NULL）——Wikipedia infobox（TVAnime + 新增 Movie|Film|OVA 检测 `has_animanga_film_infobox`，剧场版/OVA 的确定性信号）、TMDB Animation+ja/JP、judge/ReAct 的 `is_anime` 输出（prompt 已强化制作公司指引）。
4. **最终 NULL = 无法判断**：留待用户在作品详情页手动修正（详情页统一「编辑」表单中的动漫判定字段，走 PUT series/movies 保存）。

### 人工编辑保护（自动扫描不覆盖人工编辑字段）

作品详情页从「单字段编辑」（如动漫判定三态 Select）改为**统一「编辑」入口**：一个编辑表单可改 `MANUAL_EDITABLE_FIELDS`（标题三字段、动漫判定、简介、评分、分类、状态、季集、日期等），数据源等系统托管字段（external_id/external_source/wikipedia_*/seasons/collection_id/content_type 等）不可编辑。保存走 `PUT /series/{id}` / `PUT /movies/{id}`，后端按显式发送字段记入 `manually_edited_fields`。

- **自动扫描一律跳过**：`create_or_update_*_from_external` 更新分支、`apply_is_anime`、`apply_channel_default_is_anime`、`maybe_verify_is_anime_via_bangumi` 在写字段前检查 `field_manually_edited`（metadata_service），命中即不改写；新建作品无该列表不受影响。
- **刷新元数据默认保护人工字段**：手动流程经 `/metadata/search → /works/metadata/preview → /works/metadata/apply`，同步候选提供的非人工字段；候选空值不清空。仅显式 `override_manual_edits=true` 时覆盖人工字段。
- **语义**：人工编辑是"最后写赢"的显式声明——即便用户把某字段清空为 null，自动扫描也不会再回填（除非勾选覆盖）。

### Metadata 一致性防护（缓存版本化 / 跨表守卫 / 修正联动 / 跨表去重）

针对"错误 verdict 被缓存复用 + Movie/Series 分表产生跨表重复"这一类问题（案例：franchise 页被旧分类器误判 movie 后，新频道的同标题资源命中陈旧缓存，在已有 Series 的情况下又建了 Movie）：

- **缓存逻辑版本化**：`MetadataCache.generation` 记录产生 verdict 的逻辑版本（`METADATA_CACHE_GENERATION`），读取时旧代条目视为未命中并懒删除。分类/判定逻辑变更时 bump 常量即全部失效（详见 data-models.md）。
- **落库前跨表守卫与在线纠错**：`metadata_repository` 的 upsert 分发处，movie verdict 先按 canonical external_id 查 TVSeries（tv verdict 对称查 Movie）。正常的相反表 owner 仍采用 creator-wins：翻转到已有行，避免一次错误 verdict 产生跨表重复；但若 TVSeries 行自身已明确 `content_type="movie"` 且没有 Episode/单集资源证据，则它属于历史错表数据，立即创建/复用 Movie、迁移 FileResource/AgentWork/ChannelRawTitleMapping/PendingDecision/合集 links 与文件 assignments、合并身份袋并删除错误 TVSeries。这样明确电影不会因旧 FK 被要求 season/episode。
- **手动修正联动清缓存**：手动 link（`manual_link_metadata`）提交后，按 `external_id` 删除命中的 MetadataCache 行，让用户的类型纠正当即传播到后续资源。
- **每日去重的跨表合并**：`merge_cross_type_duplicates`（随 04:00 去重任务运行）检测共享 canonical external_id 或共享归一化标题（含别名、简繁折叠）的 (Movie, TVSeries) 对。存留规则：任一侧存在带集号的资源或 Episode 行 → 保留 Series；否则保留 Movie。失败方的 FileResource / AgentWork / ChannelRawTitleMapping / PendingDecision 引用全部改指存留方并合并标题/别名后删除。

### WorkCollection（大 IP 合集分组）

**定位：collection 是组织层而非消歧核心**——匹配/派发仍以单个作品行（TVSeries/Movie）为准，合集只提供浏览分组、详情页"同系列作品"和 DSL 过滤维度。作品单季化后合集升级为**系列级元数据载体**：每部剧集作品必属一个合集（无自然合集时 upsert 自动建 `series_group` 壳合集），系列级源身份落合集身份袋（`work_type="collection"`），季限定/跨语言标题变体收进合集 `aliases` 供两级标题兜底；franchise 包挂载时若成员作品的壳合集只含该作品，壳合集被 franchise 合集吸收（身份袋合并、空壳删除）。

- **确定性 TMDB 链接（不经 LLM）**：`link_movie_collection(db, movie)`（collection_service）在 Movie upsert 后调用——`metadata_repository._apply_to_resource` 两处与 `metadata_service` 的 Layer-4 落库、`manual_link_metadata`。当 `movie.external_id` 为 canonical `tmdb:<digits>` 且 `collection_id` 为空时，直接 httpx 拉 TMDB movie details 读 `belongs_to_collection`（{id, name, poster_path}），按 `(external_source="tmdb_collection", external_id=原始数字 id)` 幂等 upsert WorkCollection 并回填 FK。不能用 LLM `matched_entity`（Layers 1-3、S1 短路、缓存命中都绕过 TMDB details；bangumi 模式没有 TMDB 工具）；不能用 `canonicalize_external_id`（会把 collection id 改写进电影 id 空间）。TMDB 未配置/禁用、电影无合集、已链接时静默 no-op。存量电影用 `scripts/collection_backfill.py`（dry-run 默认，`--apply` 执行）回填。
- **同名作品注入（替代合集注入）**：Agent 消息在 ReAct 循环前构建，只有本地库信息，故不做 collection 注入。改为 `_find_same_title_works`（原 `_has_same_title_collision` 重构为返回碰撞作品列表，Layer-3 布尔语义以列表真值保持）：≥2 个本地作品归一化标题精确碰撞时，把列表（标题、年份、类型、季数）注入 `_build_production_message`，提示结合标题年份选择正确作品——修复的真实错误模式是"链接到错误的既有本地作品"。
- **去重合并保留合集归属**：`_merge_movie_group`/`_merge_series_group` 中存留方保留自己的 collection_id，为空时取重复行的（collection 链接是作品级副作用，不 bump `METADATA_CACHE_GENERATION`）。
- **Wikidata TV 归组回填（确定性带外脚本，非 agent 数据源）**：TV 没有 TMDB collection 等价物，故 series 归组走 `scripts/tv_collection_backfill.py`（dry-run 默认，`--apply` 执行，逻辑在 `app/services/wikidata_collection.py`）。对每个 `collection_id IS NULL` 的 TVSeries（作品单季化迁移后常态下不存在——剧集作品必属合集，本脚本仅服务迁移前的存量行）：先按行上 LLM 挂载的 `wikipedia_url`（URL host 锁定语言版，可信）→ `wikipedia_page_id`（不带语言版，逐 en/zh/ja 尝试且实体 label/alias 必须与作品标题精确匹配才采纳）→ `wbsearchentities` 兜底（仅当恰好一个结果 label/alias 与标题精确匹配，消歧即跳过）解析 Wikidata 实体 QID；再读实体的 P179（"part of the series"）claim——无 P179 跳过、多个不同 P179 值判 ambiguous 跳过（绝不猜 franchise）；单个则按 `(external_source="wikidata", external_id=franchise QID)` 幂等 upsert WorkCollection（title_cn/title_en 取 franchise 实体 zh/en label）并回填 `series.collection_id`。同 franchise 作品经唯一约束收敛到同一行。全程确定性、无 LLM、不进 metadata agent 循环。
- **TMDB collection parts 按需可见性（不落库，非 agent 数据源）**：`GET /collections/{id}?include_parts=true` 对 `tmdb_collection` 合集实时拉 TMDB `/collection/{id}` 的 parts（`fetch_tmdb_collection_parts`，进程内 10 分钟 TTL 缓存防刷新打爆 TMDB），与本地电影 canonical `tmdb:<id>` external_id 集合（`tracked_movie_tmdb_ids`）求差集（`filter_untracked_parts` 纯函数），响应附 `untracked_parts`——本地库尚未收录的 franchise 作品（如未上线的新作）。已收录部分本就在 `works` 中。parts 永不持久化：WorkCollection 保持轻量分组实体，非 TMDB 合集或 TMDB 未配置时不输出该字段（拉取失败输出空数组）。

### Metadata Search Agent 数据源策略

MetadataAgent 不再采用多级搜索或跨数据源 fallback。每次搜索必须选择且只选择一个数据源，由 LLM 基于该数据源返回的证据做标题理解、集数/季数推断和最终结构化输出。

**统一三数据源架构**：频道、手动搜索、作品刷新、批量任务与评测均只允许 `wikipedia | tmdb | bangumi`。历史来源不可运行；Jina 的配置、客户端、ReAct tools 与缓存路径均已删除。

所有交互与评测调用统一 `search_metadata_candidates` 服务。在线请求显式携带 `source` 与 `trusted_sites`；可信站点既是 Wigolo 域名白名单也是候选优先级，`null` 使用默认顺序，`[]` 禁用回退，并同时执行 `include_domains` 下推与 URL 注册表硬过滤。

运行时支持的数据源（`SUPPORTED_METADATA_SOURCES = {"tmdb", "wikipedia", "bangumi"}`）：
- `wikipedia`：Wikipedia Search，代码默认数据源（`DEFAULT_METADATA_SOURCE = "wikipedia"`）。仅使用 Wikipedia 搜索与页面工具；未命中时可触发下方网络搜索回退。
- `tmdb`：TMDB Search。仅使用 TMDB API 的搜索/详情工具，适合结构化影视库匹配；未命中时同样可触发下方网络搜索回退（P4 起与 wikipedia 路径统一）。
- `bangumi`：Bangumi Subject Search（限动画分类 type 2），search-then-judge 形态同 wikipedia（确定性 auto-link 优先，否则单次 judge，流程详见「Metadata 匹配流程」）；命中作品自动落 `is_anime=True`；未命中时同样走下方网络搜索回退。无独立启用开关——配置了 token（`BANGUMI_API_KEY` 或设置页）即启用。

**有序网络搜索回退（wigolo，三频道主源未命中时统一触发）**：主源判定返回 found=False 后（wikipedia 路径在 judge found=False 时、tmdb 路径（P4 起）在 ReAct finalize found=False 时、bangumi 路径在 auto-link 未中且 judge found=False 时；transient 失败如 agent error/超时**不**触发，避免用确定性回退 verdict 掩盖基础设施故障），`web_fallback_judge`（模块 `metadata_web_fallback`，函数名保留 exa 时代的 `exa_fallback_judge`→已更名，历史缓存 reason 由 transient marker 兼容匹配）用自托管 **wigolo** 搜索守护进程 + 单次 LLM judge 在频道 `metadata_fallback_sources`（JSON 有序站点白名单；NULL=默认顺序 `bangumi → mal → anilist → tmdb → wikipedia → imdb → douban`，`[]`=禁用回退；`process_title_only` 无频道上下文，用默认顺序）限定的站点内补身份：候选 URL 按白名单硬过滤，靠前站点在证据呈现中优先（tiebreak）。回退只提供身份/链接——matched_entity 不得携带 `seasons`/`number_of_seasons`/`number_of_episodes`（LLM 输出也会被剥离），内容一律以主数据源为准。站点身份体系为 7 站注册表 `metadata_source_registry`（wikipedia/tmdb/bangumi/mal/anilist/imdb/douban；baidu_baike、eiga 已移除）。wigolo 对接走 **REST `/v1/search`**（`wigolo_client`，POST `{WIGOLO_BASE_URL}/v1/search`，非回环绑定的 daemon 需 `WIGOLO_API_TOKEN` Bearer），`WEB_FALLBACK_ENABLED=false` 时跳过回退。与被替换的神经检索不同，关键词引擎吃不下原始发布标题噪声，因此：①查询复用共享清洗器 `_candidate_queries`（≤3 个候选变体按序尝试，首个有产出者即停，全部无产出回退裸标题）；②白名单经 `SITE_DOMAINS` 映射下推为请求参数 `include_domains`（子域名命中），后置硬过滤仍保留作双保险；③hit URL 一律 `unquote` 归一化后再提取身份（百分号编码 slug 与明文必须收敛为同一 external_id）。wigolo 自身失败（网络/限流/协议错误）记为 transient 不缓存；回退命中时 `search_method` 分别为 `search_then_web_fallback`（wikipedia）/ `react_then_web_fallback`（tmdb、bangumi 共用共享回退函数 `_maybe_web_fallback`）。无法解析出注册表身份的页面沿用历史标记 `external_source="exa_web"`（已落库值，保持稳定）。

**回退证据边界（2026-09-06）**：上述“首个有产出”指按 URL 注册表解析、通过频道白名单之后仍有候选；外站结果不能耗尽本轮查询，搜索返回的自声明 source/id 不可信。排序后最多五条即为 judge 和出口验证共享的候选集合。found=true 必须通过 `_bind_selected_entity`：显式 URL（百分号解码后）只能指向该集合中的同一候选；无 URL 时必须有唯一精确 source/id；模型 id/source 与 URL 身份冲突、未知候选或缺身份均返回 `web fallback judge returned ungrounded identity`，沿现有 transient 路径重试且不缓存。不得把模型生成的另一个页面当证据。回退出口除季数/集数外亦剥离 `episode_list`、`single_season_entry`、`alt_external_ids`，避免绕过季集与身份袋约束；found=false 不携带 matched_entity。历史 exa_web 行不迁移，新判定不再凭无依据标题创建 exa_web 身份。缓存代际升至 6，旧 verdict 惰性失效；不会自动解除既有作品关联或覆盖人工编辑。

数据源选择规则：
- 一个数据源当且仅当启用且凭证已配置时才在 UI 中可选；`wikipedia` 无需凭证，`bangumi` 配置 token 即启用。启用开关为 `WEB_FALLBACK_ENABLED` / `TMDB_ENABLED` / `WIKIPEDIA_ENABLED`。
- 作品库手动刷新必须通过统一来源目录选择来源、可信站点和具体候选；批量刷新同样携带 `source + trusted_sites`，但只自动应用确定性候选。
- **频道级定期刷新（原全局自动刷新已废除）**：Channel 新增 `metadata_refresh_enabled` / `metadata_refresh_interval_minutes`（NULL=默认 1440）/ `metadata_refresh_full_scope` 三列。开启后调度器按间隔入队 `refresh_channel_works`（stable key `channel-refresh:<id>`），handler 只做参数派生——source = 频道自身 `metadata_source`、`override_manual_edits=False`——作品选集经 `select_channel_works_for_refresh`（默认缺失门控：只选确有待填空字段的作品，谓词与 `metadata_search` 的 fill 字段表一致；`full_scope=True` 跳过门控刷全部关联作品），随后复用与手动刷新完全相同的 `refresh_work_by_source → search_metadata_candidates → apply_work_metadata → process_title_only` 单一管线执行——剧集作品刷新会把自身 `season_number` 作为 `season_hint` 传入搜索（bangumi 季感知 auto-link/judge 据此选对当季条目，不会把第一季条目身份错填进后续季作品），日期写回走与 upsert 一致的季级语义（`_work_start_date`/`_work_end_date`：season 粒度实体取自身日期；系列级实体仅在该季 `seasons` 条目/集日期子集有证据时填本季日期，第一季或可验证单季才回落实体级日期）；season-0 特典作品跳过刷新（跳过网络搜索前先做确定性 start_date 兜底：NULL 且未人工编辑时取同合集非特典季作品的最早 start_date 落库，定期刷新据此自然收敛存量）；candidate 身份已被他作品占用时 409 不抢、以 `identity_conflict` 结果上报（去重候选）。存量频道开关一律收敛为关闭（轻迁移）。

兼容规则：
- `combined` 仅作为旧评测数据集值保留；运行时归一化为默认 `wikipedia`，不得作为新数据集或新搜索任务的数据源类型。
- 单次搜索必须保持"只使用一个数据源"的约束，不得跨数据源 fallback（三频道主源的有序网络搜索回退是唯一的、仅补身份的例外）。
- eval 标注平台的新建 Dataset 必须选择 `tmdb` / `wikipedia` / `bangumi` 并保存相同的 `source + trusted_sites` 搜索配置；历史来源数据集只读且不可重跑。

### Wikipedia 匹配的 content_type 判定

Wikipedia 数据源没有 TMDB media_type 这类权威字段，tv/movie 由页面 **categories 关键词**推断（`_infer_content_type_from_categories`）：

- **TV 指示词优先**：页面分类含任何 TV 指示词（`television series`、`anime television`、`電視動畫`、`电视动画`、`電視劇`、`テレビアニメ` 等）即判 `tv`，即使同时含电影分类。原因：franchise/作品总页面（如轻小说系列）会同时携带各季 TV 动画分类与剧场版分类（如 `2021年日本電視動畫` 与 `2022年日本動畫電影` 并存），该页面代表的是剧集，电影有自己独立的页面；且电影关键词可能来自制作公司分类（如 `Liden Films` 含 `films`），不能单独作为判 movie 的依据。
- 仅含电影指示词（`film`、`movie`、`電影`、`映画` 等）且无 TV 指示词时判 `movie`；两者皆无默认 `tv`。
- LLM judge 提示词遵循同一规则：TV 分类存在时 franchise 总页面一律判 `tv`。

该判定发生在确定性 auto-link（标题相似度 ≥ `AUTO_LINK_THRESHOLD` 且页面判为 work）与 LLM judge 两条路径；Movie 落库后无自动重分类机制，修正需走手动 search + link（见下文手动匹配流程）。

### Agent 运行生命周期（run_agent）

入口：task queue worker `_handle_run_agent(payload)`（`app/main.py`），payload 为 `{"agent_id", "resource_ids"?, "scan_since"?}`（`scan_since` 为 naive UTC ISO 字符串或 null，键的存在即表示"指定起始时间运行"）。每次运行持久化一条 `AgentRun` 记录（开始即插入 `status="running"`，结束回填计数与状态）。

**事务边界**（避免长时间持有 SQLite 写锁阻塞前台写请求）：handler 分两个阶段——阶段 1 短事务内插入 AgentRun、选定本次资源并立即提交；阶段 2 处理阶段（含 LLM 调用与 Transmission RPC）以 `process_resources(..., autocommit=True)` 运行，每完成一次派发/决策即增量提交，写锁绝不跨越外部调用持有。各单元操作幂等（任务去重 / 决策 upsert），块级锁重试或中途崩溃后重跑会跳过已提交部分。四种运行模式：

| 模式 | 触发条件 | 处理范围 | 消费进度 |
|------|----------|----------|----------|
| **增量运行** | 无 `resource_ids` / `scan_since` | 本次提交前缀内、cursor 之后且满足历史准入的发布事件；按事件顺序去重资源 | 无内部错误才按 channel/generation 确认快照；首次 NULL 时间且无进度时仅初始化当前前缀，不回填 |
| **定向运行** | 显式 `resource_ids` 或 B9 持久修订请求 | 指定资源，按当前规则评估 | 绕过历史准入，不确认普通发布游标 |
| **回填提交** | rules-preview 保存，`dispatch_resource_ids` 为数组（含空数组） | 派发所选资源 | 保存成功后同事务重置 baseline/cursor 为当前发布前缀，更换 generation、清空历史时间准入 |
| **指定起始时间运行** | payload 含 `scan_since`，null 表示全历史 | 按 `created_at > scan_since` 选择，null 不限 | 处理前持久化历史准入及重试游标；成功只确认开始快照，失败可由普通增量恢复 |

scenario ④ 的 AgentRun 记录 `scan_since` 字段：null 表示增量/定向运行，`1970-01-01` 表示显式"不限制"全量扫描，其余为实际起始时间。用途：补派"符合订阅条件但从未成功下载"的较早资源（episode 去重保证已有活动/完成任务的集数不会被重复派发，error/expired 的旧任务会被重新派发）；`scan_since` 为未来时间时 API 返回 422。

> 旧实现的 `limit(200)`（按 `published_at` 取最近 200 条）已废弃——它会在高频频道上静默丢弃更早的资源。发布进度提供可重试消费；资源可能多次入选，已提交任务和决策沿用业务去重，不承诺外部副作用恰好一次。

### Agent 过滤流程（agent_service）

入口：`process_resources(agent: Agent, resources: list[FileResource], db, *, autocommit=False)`，对**已由 run_agent 选定**的资源列表执行过滤、去重、冲突处理与派发。`resources` 的筛选（增量/定向）在上层完成，本函数只关心单次处理逻辑。`autocommit=True`（仅后台 run_agent handler 使用）在每次派发/决策后增量 `commit`；请求路径保持默认，由请求结束统一提交。

```
process_resources(agent, resources, db)
  │
  ├─ 1. 构造规则快照 rule_set = _build_rule_set(agent)
  │     含 scope_channel_wide / filter_config / work_by_series_id / work_by_movie_id。
  │     独立于 Agent ORM 对象，使 rules-preview 能比较 old vs new 规则而不改动持久化数据。
  │
  ├─ 2. 初始化 RunResult:
  │     candidates_by_key: dict[(type, id, episode?), list[FileResource]] = defaultdict(list)
  │     suggestions: dict[search_title, 分组] = {}
  │     matched_resource_ids: list[str] = []   # 本次通过 work-scope + filter 的资源
  │
  ├─ 3. 对每个 resource:
  │     │
  │     ├─ a. Channel 文件资源确认门禁:
  │     │     未链接 metadata、适用于当前形态的 Channel 必选字段缺失、单集 TV
  │     │     季/集号不确定、合集覆盖范围不确定，任一命中即不参与 Agent
  │     │     过滤/下载（unrecognized++）。问题仅进入 Channel 文件资源待确认，
  │     │     不创建 AgentSuggestion/PendingDecision；修订后定向重跑。
  │     │     links-only multi_season 包（作品单季化终态：作品 FK 全清、季作品
  │     │     挂在 resource_work_links）经 links 表识别——links 非空即视为
  │     │     已关联作品，覆盖度取关联季作品 id 集合。
  │     │
  │     ├─ b. work-scope + filter 评估（_resource_matches_rules）:
  │     │     matched, work = _resource_matches_rules(resource, rule_set)
  │     │     # scope=false 时需命中订阅作品（links-only multi_season 包任一
  │     │     #   关联季作品被订阅即在范围内）；再与 effective_filter（全局
  │     │     #   filter_config AND work.filter_overrides）求值
  │     │     if not matched:
  │     │         # 区分"在订阅范围内但 filter 未通过"与"不在范围内"
  │     │         if 在订阅范围内（scope_channel_wide 或命中 work）: filter_failed++
  │     │         continue
  │     │
  │     ├─ c. 合集分支（resource.is_batch=True）:
  │     │     先查同一 FileResource 的 active/completed 任务（防重跑重复派发）。
  │     │     再按内容覆盖度去重（_batch_coverage_key）：规范化作品类型、
  │     │     作品 ID、季号及集数区间；文件指派为权威，区间合并保留缺口。
  │     │     无指派时仅单电影或季号/起止集明确的单季包可回退；
  │     │     多作品必须逐作品有指派，未拆季 legacy 作品覆盖未知。
  │     │     半季和整季即使作品集合相同也不能合并。
  │     │     覆盖度已知 → 先查同
  │     │     agent 同作品 active 任务中是否有覆盖度完全相同的合集
  │     │     （Python 侧比对；剧集包受 enable_episode_dedup 门控、电影包
  │     │     与单集电影一致不门控；links-only 包与 agent 其他 FK 全清的
  │     │     合集资源比对），命中则 duplicates_skipped++；否则以
  │     │     ("batch", work_id, coverage) 进 candidates_by_key，与单集走
  │     │     同一冲突解决（ask → PendingDecision，episode 置哨兵 -1 与
  │     │     无集号单集决策区分，season 分量由作品 season_number 填充，
  │     │     reason 用合集文案；auto → 优选偏好 →
  │     │     LLM pick → 启发式评分）。覆盖度不同的合集（S1 包 vs S2 包、S1-S2 vs
  │     │     S1-S3）互不冲突、各自派发；franchise 包作品 FK 全清走不到
  │     │     这里。已知限制：links-only multi_season 包的决策共享
  │     │     (series=NULL, season=NULL, episode=-1) 幂等槽位（幂等列编不下
  │     │     作品 id 集合）。
  │     │
  │     ├─ d. 去重检查（仅单集资源）:
  │     │     电影：按 movie_id 查询 active DownloadTask，存在则跳过；key=("movie", movie_id, None, None)
  │     │     TV 单集：dedup = work.enable_episode_dedup if work else True
  │     │             dedup 且 episode 非空时按 (series_id, episode) 查询 active 任务，
  │     │             存在则跳过——作品单季化后槽位身份为 (series, episode)
  │     │             （季已编码在季作品身份，旧的「季兼容」比对逻辑整体删除）
  │     │             key=("series", series_id, episode)
  │     │
  │     └─ e. candidates_by_key[key].append(resource)；matched++；
  │           matched_resource_ids.append(resource.id)
  │
  ├─ 4. 候选聚合处理:
  │     for key, candidates in candidates_by_key.items():
  │         if len(candidates) == 1:
  │             dispatch_download(agent, candidates[0])  # dispatched++
  │         else:
  │             if agent.conflict_resolution == "ask":
  │                 create_pending_decision(agent, key, candidates, db)
  │                 # upsert 同一 (agent, target, season, episode, pending) 行；合并 candidates；
  │                 # 建议经 _suggest_pick 填充 llm_picked_resource_id 与
  │                 # llm_suggestion（用户可点 "AI 自动处理" 一键采纳）：
  │                 # 优选偏好唯一命中 → 确定性建议（reason 标注规则来源）；
  │                 # 打平 → _generate_llm_pick
  │             else:  # "auto"
  │                 tier, _ = pick_by_preferences(candidates, agent.pick_preferences)
  │                 # 优选偏好先行（只排序不过滤）：唯一胜者直接派发、零 LLM 调用；
  │                 # 打平子集交 LLM（agent.llm_prompt 优先，否则内置默认 prompt）；
  │                 # LLM 未启用 / 调用失败 / 无有效选择时回退启发式 score_and_pick
  │                 chosen = tier 唯一 ? tier[0] : (LLM 选中候选 or score_and_pick(tier, agent, work))
  │                 # 启发式评分：分辨率高（2160p>1080p>720p）> 文件体积大 > 发布时间新
  │                 #   > 字幕语言加分（zh-CN > zh-TW > 无，末位 tie-break）
  │                 dispatch_download(agent, chosen)
  │
  ├─ 5. 兼容清理旧版遗留的资源修订型 PendingDecision，使其不再出现在 Agent 列表。
  │
  └─ 6. 返回 RunResult（dispatched / pending_decisions / filter_failed /
        duplicates_skipped / unrecognized / suggestions / errors / matched_resource_ids）
        ——run_agent 据此回填 AgentRun 记录与 Agent.last_run_status
          （均为运行结束时的快照；待决策处理完后的状态修正见下）
```

**待决策处理后的状态复位**：PendingDecision 经 confirm/skip/batch 端点处理（status → decided/skipped）后，若该 agent 已无其他 pending 决策且 `last_run_status == "pending_decisions"`，复位为 `"success"`（decisions.py 的 `_maybe_reset_agent_run_status`，同事务内完成）。历史 AgentRun 行不回写，由 `GET /agents/{id}/runs` 读时修正（见 api-endpoints.md）。

**优选偏好层**（`pick_by_preferences`，P5）：`Agent.pick_preferences` 是有序 FieldCondition JSON 列表（复用 Filter DSL 的字段白名单与叶子求值 `evaluate_field_condition`，校验走 `validate_field_conditions`，保存时 422），在冲突解决中提供**确定性排序**：字典序语义——第一条规则把候选分命中/未命中两档、命中者优先，打平由下一条决胜；在当前档内全命中或全不命中的规则无区分度、跳过。**偏好只排序、绝不过滤候选**（无偏好/单候选/全员打平时原样返回）。唯一胜者直接入选（不调用 LLM，LLM 关闭或不可用时照样生效）；打平子集交 `_generate_llm_pick` 决胜，再回退启发式。三处接入：`auto` 路径直接派发；`ask` 模式经 `_suggest_pick` 生成建议（偏好命中时 reason 标注「命中优选偏好规则（确定性选择）」与 LLM 建议区分）；`POST /decisions/{id}/ai-pick` 同样偏好先行。`pick_preferences` 为空 = 行为与引入前完全一致。典型用法：`{"field": "subtitle_langs", "operator": "contains", "value": "zh-CN"}` 确定性优先简体中文字幕版本。

**已下载历史去重**：单集、电影和合集覆盖度的跨运行去重，除活动态与 `completed` 外，也把 `status=cancelled AND completed_at IS NOT NULL` 视为已占用下载槽位。该组合是 organize `move` 成功后移除下载器 torrent、保留任务历史的正常终态，不能因状态改为 cancelled 而重新下载相同作品/季；下载完成前取消（`completed_at IS NULL`）不占槽位，后续资源仍可重新派发。

**LLM 候选选择器**（`_generate_llm_pick`）：`conflict_resolution="auto"` 多候选自动选择、`"ask"` 模式下的 LLM 建议、以及 `POST /decisions/{id}/ai-pick` 共用同一逻辑。返回 `(picked_resource_id, reason)`：使用 `agent.llm_prompt`（若非空）否则内置默认 prompt（metadata 字段最完整 > 清晰度最高 > 带字幕 > 发布时间最新），要求 LLM 返回 JSON `{"pick": <候选编号>, "reason": "<一句话理由>"}`，`_parse_llm_pick` 兼容 markdown 包裹与裸数字兜底。发给 LLM 的候选摘要包含 `title`（资源原始标题）与关联作品的 `year`（电影 `release_date` / 剧集 `start_date` 的年份）、`rating`（0-10 分），无关联作品或字段为空时为 `null`；prompt 中附带字段说明。LLM 未启用 / 无 API key / 调用失败 / 未给出有效选择时返回 `(None, None)`，`"auto"` 回退到纯启发式评分（分辨率 > 体积 > 发布时间）。结果缓存在 `PendingDecision.llm_picked_resource_id`，AI 自动处理优先复用缓存值。

`dispatch_download(agent, resource)`：
1. 创建 `DownloadTask(status="pending")` 并 `db.add()`（**不立即 flush**：flush 会发出 INSERT 并持有 SQLite 写锁跨过整个 Transmission RPC）。
2. 解析下载目录：`effective_download_dir = join(downloader.download_dir, agent.download_subdir)`；若 `download_subdir` 为空则直接使用 `downloader.download_dir`。
3. 校验 `download_subdir`：必须是相对路径，禁止绝对路径、`..`、空段逃逸、控制字符；标准化后不得跳出 `downloader.download_dir`。
4. 将 `effective_download_dir` 写入 `DownloadTask.download_dir`，用于审计、重试与后续配置变更隔离。
5. 调用 `TransmissionWrapper.add_torrent(payload, download_dir=effective_download_dir)`，payload 由 `resolve_torrent_payload(resource)` 得出：`resource.torrent_file`（通道 A 缓存的本地 .torrent）存在时读字节推送（读失败回退 URL），否则透传 `torrent_url`（URL/magnet 原样）。
6. 成功 → 更新 `task.status="downloading"`, `task.transmission_torrent_id=返回值`, `task.confirmed_at=now`。
7. 失败 → 更新 `task.status="error"`, `task.error_message=异常信息`；触发重试逻辑（若 retry_count < max_retries 则入队重试）。
8. RPC 结束后统一 `flush`，由调用方（请求路径）或 autocommit（后台路径）提交。

`dispatch_download` 的"创建任务 + 提交下载器"主体已抽取为 `create_and_submit_task(resource, downloader, db, agent_id, download_dir)`，供手动创建复用。手动创建下载任务（`POST /tasks`）完全绕过 Agent：用户从资源列表/资源详情选择 Downloader，后端直接以 `agent_id=None`、`download_dir=downloader.download_dir`（根目录，不加子目录）调用同一 `create_and_submit_task` 提交；不做去重检查（手动创建是显式用户意图，允许重复任务）。

### 手动 metadata 搜索与修正流程

```
用户在资源详情点击"修正 metadata"
  │
  ├─ 1. 用户输入 query、选择 content_type、主来源与可信站点
  │
  ├─ 2. 前端 POST /metadata/search（只读，返回统一候选）
  │
  ├─ 3. 用户选择本地作品或在线候选；在线候选仅进入向导草稿
  │
  ├─ 4. 最终 PUT /resources/{id}/associations
  │     同一事务物化在线作品并应用 works/assignments/FK；失败完整回滚
  │
  └─ 5. commit 后仅入队一次定向 Agent 重跑
```

### Schedule 调度

Dashboard 实时读取与后台调度相互独立：SPA 每 3 秒只请求 `/dashboard/downloads`，下载器 `list_torrents` 并发执行且单实例最多等待 2 秒；统计、Top4 Agent 与待办通过 `/dashboard/overview` 每 30 秒刷新。待确认总数仍调用统一 Channel 确认策略精确计算，但扫描查询必须显式限制 ORM 关系加载，禁止 Channel/Agent 默认 `selectin` 关系级联。

APScheduler（AsyncIOScheduler，内存 store）在 **worker 进程**启动时初始化（`APP_ROLE=worker` 或 `all`；`APP_ROLE=web` 的进程不起调度器、不消费队列）。**所有周期 job 只 enqueue 不执行**。两层机制保证 N 个 worker 各跑一份调度器时每个 interval 只执行一次：① tick 节流——`queue.throttle(<type>, ttl=interval)`（Redis SET NX EX，键 `rssripple:tick:<type>`），本 interval 内第一个 tick 胜出，其余直接跳过（active-key 去重只挡并发重复，挡不住错峰 tick，必须有这层）；② 队列 active-key 去重兜底并发窗口，BLPOP 单消费者保证恰好执行一次。job 函数体仍可直接调用（单测依赖）。

```
startup:
  │
  ├─ 1. 查询所有 status="active" 的 Channel:
  │     for ch in channels:
  │         scheduler.add_job(
  │             func=enqueue_fetch,
  │             trigger=IntervalTrigger(seconds=ch.fetch_interval),
  │             id=f"channel:{ch.id}",
  │             args=[ch.id],
  │             next_run_time=datetime.utcnow() + 5,  # 启动 5s 后首次执行
  │             replace_existing=True,
  │         )
  │         # 频道级定期作品元数据刷新（可选，默认关）：同 pattern 注册
  │         # id=f"channel-refresh:{ch.id}"、IntervalTrigger(minutes=间隔 or 1440)，
  │         # enqueue "refresh_channel_works"（stable key 同 id，active-key 去重防重叠）
  │
  ├─ 2. Channel CRUD 时动态调整:
  │     创建/更新 → active? add_job/reschedule_job（fetch 与 channel-refresh 两 job）: remove_job
  │     删除/paused → remove_job（两 job 一并移除）
  │
  ├─ 3. 全局每分钟任务:
  │     enqueue "sync_progress"（key=job:sync_progress）
  │
  ├─ 4. 全局每小时任务:
  │     enqueue "check_downloaders"  # handler 调用 POST /downloaders/{id}/test
  │
  ├─ 5. 每 30 秒任务（仅 Turso 后端注册；PostgreSQL 无边车，
  │     search_text + pg_trgm 由 ORM 钩子同事务维护）:
  │     enqueue "fts_drain"          # FTS 边车同步：把 fts_outbox 变更行定向投递到
  │                                  # 边车影子表（ORM 钩子与作品行同事务入队，
  │                                  # 幂等全量写；写入失败留给对账兜底）。
  │                                  # 搜索路径额外在读前 drain（search_*_fts 顶部
  │                                  # 先清空 outbox），保证"刚提交即可搜到"的
  │                                  # read-your-writes 一致性（手动 link 后立即
  │                                  # 搜索、调度器关闭的部署都成立），此 30 秒任务
  │                                  # 退化为批量化与脚本/非 API 写入的兜底。
  │
  ├─ 5b. 每 5 分钟任务:
  │     enqueue "backfill_metadata"  # 重试可重试的未匹配资源；顺带重跑
  │                                  # stale raw 集数 reconcile（链接时季作品
  │                                  # 尚无集数数据、后补齐 number_of_episodes
  │                                  # 的绝对集号资源，reconcile_stale_raw_episodes，
  │                                  # seasons_map_for_work 取季作品自身计数，
  │                                  # legacy 行回退惰性 seasons 列）
  │
  ├─ 5c. 每小时任务（仅 Turso 后端注册）:
  │     enqueue "fts_reconcile"      # FTS 影子表对账：全量 diff 基表 vs 影子表，
  │                                  # 修补绕过 outbox 的路径（脚本、直连 SQL）
  │
  ├─ 6. 每分钟任务（NOTIFY_ENABLED 开启时）:
  │     enqueue "download_notifications"  # handler 三段式 tick：
  │                                    # ① 入队：为 completed 且无通知的任务停种（best-effort）
  │                                    #   + 补建 DownloadNotification（download_task_id 唯一
  │                                    #   + SAVEPOINT 竞争回读，幂等；仅当 Agent 有启用
  │                                    #   webhook 或存在启用 OrganizeRule 时才补建，
  │                                    #   两者皆无不生成通知）；
  │                                    # ② fan-out：ensure_deliveries 为"通知 × 每启用
  │                                    #   webhook"补建缺失的 pending WebhookDelivery；
  │                                    # ③ 投递：deliver_due_deliveries 并发投递到期 delivery
  │                                    #   （每 tick 上限 50 条、Semaphore(10) 并发、180s
  │                                    #   超时、指数退避，超限转 failed）。唯一投递路径，
  │                                    #   详见 notifications.md
  │
  └─ 7. 全局每日任务（CronTrigger + misfire_grace_time=3600：默认 1s 宽限
        会被 LLM 重负载阻塞的事件循环反复错过，宽限放大到 1 小时兜底）:
        enqueue "daily_cleanup"      # 删除 completed 且 completed_at < now - task_expire_days 的任务
                                 # （跳过其通知存在任一非 done delivery 的任务；
                                 # 超过 NOTIFY_RETENTION_DAYS 保留期的通知整行删除，
                                 # delivery 随级联清理）+ 过期 pending decision → expired
        enqueue "daily_dedup"  # 04:00 运行：合并重复的 TVSeries/Movie 行（安全网，
                            # 防止 metadata agent 偶尔为同一作品新建第二行）。聚类 key 基于
                            # 共享的 title_cn/title_en/original_title **+ aliases**（归一化
                            # 含 OpenCC 繁转简），只折叠可证明为同一作品的行；作品单季化后
                            # 聚类按 **season_number 隔离**——同 IP 不同季标题再像也绝不互
                            # 合并，legacy 未拆分系列级行只互相聚类；**年份守卫**：
                            # 首播/发行年相差 >1 年的同标题聚类不合并（重制/重启/同名系列，
                            # 记 note 跳过）；子表重指向防撞——Episode/AgentWork/
                            # PendingDecision 自然键冲突的重复行删除而非强转（幂等）；
                            # ResourceWorkLink/ResourceFileAssignment 随之重指向存留方
                            # （唯一键碰撞折叠、manual provenance 转移，不再被 FK CASCADE
                            # 静默丢行）；手动合并入口 POST /works/merge 复用同一合并机器。
                            # P3：合并时身份袋取并集（存留方继承重复方的主 id 与袋行，见
                            # merge_external_id_bags；跨表合并同样处理，标题配对同样受
                            # 年份守卫约束，外部 id 相等不受）
```

任务队列使用 MemoryQueue（默认）或 RedisQueue（配置时），承载手动触发的 fetch/run 与全部周期任务；同 key 的 active key 与执行 token 保证当前有效领取唯一；失权旧协程可能仍在运行，其数据库提交和外部副作用由各 handler 的所有权检查、条件写入及幂等协议保护，不承诺恰好执行一次。**web/worker 分离**（`APP_ROLE`）：web 进程只 HTTP + enqueue（`queue.start(consume=False)`）；worker 进程（`python -m app.worker`）跑调度器 + 消费队列。RedisQueue 必须先取得并发槽位，再以原子 `LMOVE` 把 job 从持久 backlog 移至该 consumer 的 processing 列表，禁止无界预取到进程内等待；consumer 以短 TTL 租约持续心跳，正常完成才从 processing 确认删除。worker 优雅退出时未完成 job 原样重新入队；进程崩溃时描述符仍留在 processing，其他 worker 在租约过期后通过全局恢复锁幂等重新入队，状态回退为 queued 且保留 active-key 去重锁，禁止产生永久 running 僵尸或窃取仍存活 consumer 的任务。旧版本遗留、没有可恢复描述符的 running 状态在升级启动时标记 failed 并释放 active 锁。`sync_progress`、`download_notifications`、`check_downloaders` 三类短周期运维 job 走队首优先级，避免下载状态与通知被 LLM 长任务积压。每个 job handler 执行前重读 `load_runtime_config`（进程本地缓存，跨进程设置变更靠此收敛）。分布式 compose 默认 1 web + 3 worker；standalone 单进程 `APP_ROLE=all` 行为不变。

升级执行所有权协议时，必须先停止全部旧版本 worker，再启动新版本 worker。旧代码的无条件回写无法受新代码中的 WATCH/CAS 约束，不支持据此宣称新旧版本滚动混跑安全。无可恢复描述符的旧 running 作业转 failed；具有持久描述符、作业身份和 active key 一致的作业按租约恢复，身份不一致时不得窃取替代作业。

### 频道调度对账

每个 worker/all 进程启动时及每 30 秒直接读取已提交的 Channel 调度列，差异更新本进程 APScheduler（`channel_schedule.reconcile_channel_jobs`）。这是本地维护，不能入共享队列或持有跨 worker 全局锁。抓取/作品刷新分别比较间隔：新增/变化注册（约 5 秒首次触发），无变化保留 next_run_time；active/error 均调度且互转不重置，inactive/已删除移除。对账 job 设置 coalesce=True、max_instances=1、misfire_grace_time=30；DB 故障保留现有 jobs 下轮重试，单频道非法配置隔离并记录。仅列查询避免 Channel selectin 全量关联。

频道 API 不修改 web 内存调度。POST /channels 先 commit 再为非 inactive 频道首次入队（SCHEDULER_ENABLED=false 不入队）；自动抓取/刷新 payload 携带内部 scheduled=true，开始执行时重查频道存在/启用及刷新开关，陈旧自动任务跳过；手动抓取不受自动开关限制，已开始任务不取消。正常配置变更下一轮对账生效；沿用队列 active-key 并发去重，不承诺恰好执行一次。

### 下载状态同步

每分钟由定时任务调用。注意：`TransmissionWrapper` 依赖 transmission-rpc **v7 的 snake_case 属性**（`t.percent_done`、`t.left_until_done`、`t.is_finished` 等；唯一例外是 camelCase 的 `t.hashString`），用 camelCase 访问会静默拿到 `getattr` 默认值（进度恒 0、`left_until_done` 恒 0），导致任务被误判 completed。

```
sync_download_progress():
  │
  ├─ 1. 查询所有 status in ("downloading","queued","pending") 的 DownloadTask；
  │     另带自愈条件：status="error" 且 error_message 以 "Transmission unreachable"
  │     开头（历史故障级联遗留）且 transmission_torrent_id 非空的任务也纳入同步，
  │     下载器恢复后自动回到正常跟踪（无 torrent id 的任务从未提交成功，须走重试）
  │     按 downloader_id 分组，减少 RPC 调用
  │
  ├─ 2. 对每个 downloader:
  │     try:
  │         torrents = TransmissionWrapper(downloader).get_all_torrents()
  │         torrent_map = {t.id: t for t in torrents}
  │         for task in downloader.tasks:
  │             t = torrent_map.get(task.transmission_torrent_id)
  │             if t is None:
  │                 task.status = "cancelled"
  │                 continue
  │             task.progress = t.percent_done
  │             task.download_speed = t.rate_download
  │             task.upload_speed = t.rate_upload
  │             task.eta = t.eta
  │             task.error_message = None  # 同步成功即清除历史故障遗留的错误信息
  │             if t.is_finished or (t.left_until_done == 0 and t.total_size > 0):
  │                 # left_until_done 需搭配 total_size>0：magnet 元数据未下载时两者皆为 0
  │                 task.status = "completed"
  │                 task.completed_at = now
  │             elif t.status == "stopped":
  │                 task.status = "paused"
  │             elif t.status in ("downloading","queued"):
  │                 task.status = "downloading" if t.rate_download > 0 else "queued"
  │     except TransmissionError:
  │         # RPC 失败不代表任务失败（种子在 daemon 中照常运行）：
  │         # 只标记 downloader.status = "error"，任务保持最后已知状态，
  │         # 下次同步成功后自动恢复；不再级联把任务标记为 error
  │         downloader.status = "error"
  │     # 每个 downloader 处理后立即 commit：否则下一轮迭代的查询会 autoflush
  │     # 这些 UPDATE，导致 SQLite 写锁在整个 list_torrents RPC 期间被持有
  │
  └─ 3. db.commit()
```

### Mock Downloader（用于测试）

`DownloaderInstance.type = "mock"` 提供一个纯内存模拟器，行为如下：

- **连接测试**：`test_connection()` 总是返回成功（`"Mock Downloader 1.0"`），`free_space` 返回 1 TB。
- **add_torrent**：立即返回 `torrent_id`，同时把该"下载"记入内存 registry。
- **进度模拟**：每个 torrent 分配 `random.uniform(1, 10)` 秒的完成周期；`list_torrents/get_torrent` 按 wall-clock 计算 `percent_done`，到期后 `is_finished=True`；scheduler 的 `sync_download_progress` 因此能观测到进度增长并把 DownloadTask 标记为 `completed`。
- **pause/resume/remove** 均支持；pause 冻结 elapsed 计时，resume 继续。
- **状态存储**：模块级 `_STATE` dict，进程重启即清空——这正是测试所需的行为。

通过统一工厂 `app.clients.downloader.get_downloader_client(downloader)` 根据 `downloader.type` 分派到 `TransmissionWrapper` 或 `MockDownloaderWrapper`；两者共享同一异步接口（`test_connection` / `add_torrent` / `list_torrents` / `get_torrent` / `get_torrent_files` / `pause_torrent` / `resume_torrent` / `remove_torrent` / `free_space`），所有 Agent / scheduler / API 调用点均无需感知具体类型。`get_torrent_files` 返回 `{name, files: [{name, size}]}`，供下载通知快照锁定 torrent 内文件清单（mock 默认单文件，测试可向 `_TorrentState.files` 注入多文件）。

Mock downloader 面向本地开发和自动化测试；生产环境应使用 `transmission` 类型。

### Metadata 生产样本离线回归

验收入口为 `tests/integration/metadata_corpus/`，由现有单节点/分布式 Compose 的集成收集执行，共享导出/回放工具保留在 `tests/metadata_corpus/`。Fast Gate 和发布前门禁也运行相同离线用例。审核报告写入 `CORPUS_REPORT_DIR` 而非 fixture，逐场景异常与语义差异随 JUnit 上传；分布式使用独立 `metadata_corpus_test` 库，不读写 HTTP app 测试库。真实 LLM 评测需显式执行，不属于默认集成运行。

`tests/metadata_corpus` 与 `scripts/metadata_corpus.py` 提供版本化作品库/torrent 测试集：原始输入、源证据、生产候选答案和独立审核答案分离，禁止把生产关联直接注入冷库。传输层冻结外部源与 LLM 响应，严格校验请求指纹/消费次数并禁止未录制联网；真实 LLM 三轮评测单独执行，外部 metadata 源仍冻结。重建走真实抓取与匹配服务，核验季作品/合集/文件指派/Channel 门禁及可选下载派发，数据库与缓存全部隔离。CI 同时检查全量可用 torrent 的冻结清单与已审核语义场景；待审核或缺证据资源不冒充通过。当前覆盖范围、录制审核流程与限制见 [测试说明](../testing/metadata-corpus.md)。

### Torrent 文件关联的抓取期收敛与遗留回填

- 文件清单确定性解析以 `torrent_inspect.analyze_torrent_files` 为唯一实现：频道抓取、下载完成后的 Magnet 补齐及 organize 历史快照回退均复用它；不得在 planner 内维护另一套季集正则。所有主视频作品形态（单集 TV、单部电影、season/multi_season/franchise/movies）均建立 assignment，LLM 仍只处理确定性层无法完成的合集歧义（`llm_refinement_needed` 门控：franchise 恒触发；report.is_batch 且未解析占比超阈值触发；**资源 `is_batch=True`（标题层已判合集）且 report 落 `unknown` 且主视频 ≥2 个也触发**——覆盖 Stage 命名目录等路径层无季集结构的场景）。scope 判定把 season 0（特典/SP 文件）排除在「季数」计数外：≥2 个非零季才判 multi_season，单季+SP 仍判 season 且 episode 范围只取真季集号（覆盖季集合保留 0，SP 文件的 file_parses 照常落 season=0 映射）；路径季集解析（`extract_season_episode_from_path`）中文件名分量的显式 `SxxEyy`（含 S00）优先于目录继承的季号，目录/文件名任意分量的英文序数 Stage 标记（`Second Stage`/`2nd Stage`）同样提供季号。存量误判（`batch_seasons` 含 0）走 `scripts/batch_sp_rescan.py`（dry-run 默认 + `--apply`，torrent 缓存离线重析重写 scope/范围/assignments，不联网、不调 LLM）。

- 新资源先缓存并确定性解析 torrent 清单，metadata 作品链接完成后执行第二次无猜测绑定：资源恰好链接一个 series/movie 时，把仍为 `source=auto` 且未绑定作品的 assignment 全部挂到该作品，并补 `resource_work_links(source=auto)`；manual/llm 行不覆盖，多作品包不进入此分支。
- **簇级作品解析（`cluster_work_binding.bind_hint_clusters`，挂在 `maybe_inspect_torrent` 富化段末尾、franchise 链接之后；另在 bangumi 系列图谱扩展后做第二次幂等运行）**：torrent 富化 pass 已按顶层目录聚类把簇标题写入 `work_title_hint` 并逐文件解析 season/episode，但 auto 行此前不绑作品；本步骤按 distinct hint 分簇（空 hint 跳过），对每个簇解析唯一目标作品后整簇绑定该簇全部未绑 auto 行。解析顺序（先命中先用，拿不准一律不绑、hint 保留待人工/LLM）：①**同合集成员**——资源已关联作品（互斥 FK/links）或已 park 到合集时，在同合集成员中按归一化标题相等匹配（标题+aliases），三个层级依次为：精确标题/别名相等（标题证据）→ hint 等于合集自身标题/aliases 的基础名放宽（剥季目录如"作品X S02"，按季号众数严格选胜，**非标题证据**）→ **季标记层**（hint 自带季/Stage 标记且剥季基础名匹配**资源自身 park 合集**的主标题——相等或互为包含；兄弟壳合集的拉丁主标题会造成包含歧义，故只看 park 合集——由标记季号选成员；目录自带的 Stage 词是标题证据）；②**本地 FTS**——作品库搜索，仅接受 ≥ 既有自动链接阈值（`AUTO_LINK_THRESHOLD`=85）且最高分唯一的命中，且须过**双守卫**：**形态兼容**（仅路径中的**显式集号模式**——SxxEyy/Exx/第N话/`[NN]`——锁死 TV 证据并禁绑 Movie，目录名孤立数字或 LLM 提示集号不算；hint/路径带显式电影标记词 movie/电影/剧场版 = 电影形态；**单文件簇在 OVA/OAD/剧场版/Movie/Film 标记目录下不被锁死 tv**——弱数字证据下的 movie 裁决可绑；Movie 候选仅在簇无集数证据时可绑）与**基础名包含**（归一化基础形——剥括号标签、数字季 token 与 `:：·/` 等分隔标点，但保留 Stage 序数词——必须相等或互为包含，"Initial D Fifth Stage" 对 "Initial D Battle Stage" 基础名 fifth≠battle 拒绝；基础形**精确相等**的候选优先于仅包含的候选）；外加**续号歧义守卫**（`_sequel_ambiguous`：剥数字后基础名相关但原文尾数不同——"Initial D Battle Stage" vs "...Battle Stage 2"——视为续集兄弟而非同一作品，仅精确原文归一化相等可绑，否则不绑 hint 保留；季号 token "Show S02" 不算续号，季号选胜路径不受影响）；FTS 空结果回退全表扫描（ngram AND 匹配跨不过冒号类分隔符，与 `match_*_by_title` 同一先例）；③**外部搜索**——经频道 metadata 源 `process_title_only`（与 franchise 成员解析同一入口），仅接受 `found` 且非 ambiguous 且形态兼容的确定性结果，随后走既有 upsert 入口（TV 带簇季号作 `season_hint`——hint 自带的季/Stage 标记优先于路径季号众数；落不了季返回 None 即跳过；身份袋 creator-wins 与人工编辑保护不变）。**包内季号 vs 作品季号调和**：证据分两档——**标题证据**（精确成员标题匹配/过守卫的 FTS 命中/外部 found）说明"这个簇就是这个作品"，作品自身 `season_number` 优先于包内路径季号：不一致的行改写 season 为作品季号后绑定（episode 是季内集号保持不变，provenance 仍 auto，记 debug 日志，返回值 `BindOutcome.remapped` 暴露 remap 计数）；**纯季号选胜**（基础名放宽层）保持保守：不一致不绑记 warning。绑定 Movie 的行清空 season（电影无季）。**reconcile**：每次运行先扫已绑定 auto 行——作品的 `season_number` 在绑定后被修正时（如 franchise 链接先把 "Final Stage" 落 s1、系列图谱随后改判 s6），已绑 auto 行跟随改判镜像作品季号（llm/manual 永不动）。llm/manual 行永不动，已绑 auto 行不重复绑（幂等重跑）。绑定后补 `resource_work_links(source=auto)`、重算 `season_ranges`、`batch_seasons` 取并集（season 系 scope）并由 `sync_resource_collection` 沉淀合集身份；全部失败静默降级为 hint-only。
- 频道详情页「手动抓取」先弹窗确认，默认不勾选「重新抓取所有条目的 metadata」并发送 `force=false`；勾选后发送 `force=true`。`force=true` 无扫描条数上限地重跑该频道全部既有资源，跳过 MetadataCache 与本地已知作品短路，重新查询 metadata 源以补齐作品缺失字段（包括由 `start_date`/`release_date` 派生的必选年份），并对所有作品形态重新执行 torrent 文件关联富化；有本地 torrent 缓存时即使原 URL 是 magnet 也可复用。普通抓取与全局 backfill 也会按较长冷却周期选取“已关联但仍缺 Channel 必填字段”的资源，继续执行作品富化、发布字段写回和 torrent 文件关联；未匹配资源仍按原有失败冷却与限额回填，避免周期任务反复全表扫描。
- 内容 LLM 对普通单集文件输出互斥的 `season + episode`；仅当一个物理视频文件实际包含连续多集（例如文件名明确为 E01-E02）时才输出 `season + episode_start + episode_end`，torrent 是整季合集本身不构成单文件范围的理由。服务层校验真实路径后将单集规范化为 assignment 的闭区间 `episode_start == episode_end` 落库，保持现有数据模型兼容。
- 向导文件 LLM 分析使用 `MetadataCache(source=batch_file_analysis:v4)` 持久缓存，key 为资源 ID、搜索标题、文件路径/大小清单及逻辑版本的 SHA-256 指纹，任一输入变化自然失效；主动重新解析用 `force=true` 覆盖缓存。缓存未命中时 web 以 `batch-analysis:<fingerprint>` 为 key 入队 `analyze_batch_files`，由 worker 完成确定性解析、LLM 调用和缓存写入；队列 result 字段承载中间状态与最多 50k 字符的累计输出，SSE 只轮询并增量转发。Redis `SET NX` active-key 在多 web/多 worker 间原子去重，关闭任一窗口不取消任务；MemoryQueue 保持 APP_ROLE=all 单进程兼容。
- 编辑向导「重新解析元数据」按钮走 `POST /resources/{id}/reparse-metadata`：先写 `confirmation_ignored_at`（临时忽略，资源立即退出 Dashboard 待确认）并 commit，再以 `reprocess-resource:{id}` 为 key 入队 `reprocess_resource_metadata`（key 活跃期去重，已有任务 → 409）。handler 以 `force_refresh=True` 调用 `_process_resource_metadata` 重跑抓取期完整元数据管线（torrent 缓存/检测、metadata 匹配链接、reconcile、簇级绑定等），并在 finally 中清除 `confirmation_ignored_at`（**成败都清**）让待确认策略重新评估——数据仍不全重新进入待办、完整匹配留在外面；不重置 `metadata_attempts`/`metadata_failure_type`（backfill retry-eligibility 门控在调度侧），普通优先级（不进 `_PRIORITY_JOB_TYPES`），刷新不创建绕过历史准入的定向请求；完成事件由普通增量按现有准入范围消费。
- 向导 LLM 输入包含服务端生成的候选作品清单：`candidate_key=series|movie:<UUID>`、work_type/work_id 与 title_cn/title_en/original_title/canonical_name 全部非空别名；输出必须复用 exact candidate_key。后端只接受输入集合内的 key，并由 key 对应候选还原作品类型/ID，拒绝模型生成或篡改的 UUID；前端优先按 candidate_key 绑定，标题归一化仅作旧结果兼容回退。最终 `season_ranges` 合并经路径与候选 ID 双重校验的 LLM 单集结果。
- 特别篇文件统一映射到媒体库规范的 Season 0：文件名明确的 `SPxx` / `Special xx` / `OVA xx` / `OAD xx` 直接解析为 `S00Exx`；发布顺序式小数标签（`11.5`、`22.5`）不存入整数 episode 字段，而在作品关联后与 Episode 表的 Season 0 行按顺序一一校准。若作品源尚无 Season 0 数据但清单中存在明确 `.5` 插播标签，则按标签顺序映射为 `S00E01..N`；已有 Season 0 数据但数量不一致时保持未解析，禁止错配。单作品自动绑定和向导 SSE 确定性结果复用同一规则。

---


季号不确定的持久化门禁：MetadataAgent 清除不受证据支持的 inferred_season 后，repository 将 season_ambiguous 传给季作品 upsert。若解析上下文/身份/主源证据仍不能定季，只建或复用合集并挂待确认；不得经历史“新作品默认 S1”或单成员标题兜底重新创建/链接季作品。已验证的季号（含合法单季回退）仍按正常路径处理，重试和缓存重放均遵循同一门禁。


通知 tick 对 completed 任务逐个使用独立事务生成冻结快照；失败写入 NotificationBuildFailure 并按 30 秒起、最多 1800 秒的指数退避重试，成功清理记录。坏任务不阻断其他任务、已有整理计划及投递。失败记录并发与清理契约见 notifications.md。


Agent 候选组事务：后台运行先提交选择事务，再逐组用独立事务保存派发/决策；一组失败不使后续组或父会话对象失效，成功统计在组事务提交后累加。本轮存在处理错误时保留原消费水位线，使增量失败资源可再次入选；已提交组走原有去重。API rules-preview 回填使用同一请求内 SAVEPOINT，任何候选内部持久化失败使整个保存事务回滚并返回 INTERNAL_SERVER_ERROR，不提交部分配置或推进水位线。下载器接受种子是事务外副作用，重试依赖其相同 infohash 幂等添加，已用真实 Transmission 验证；不声称可回滚已接受的 RPC。定向请求在队列繁忙时的持久合并与补偿另见待办 B9。


### 资源修订的持久化定向补偿

三个资源修订端点在资源修改的同一事务内，为当前频道 active Agent 写入 AgentResourceRequest，包含自动修复的兄弟资源；commit 后再尝试唤醒队列。队列忙碌去重或 broker 故障不会清除请求。启用的调度器每 5 秒分发到期请求，保留现有 agent key 去重。作业选择阶段读取请求版本并合入资源集合；成功完成按 id＋revision 确认，内部错误或异常按该版本记录 30 秒起、1800 秒封顶的指数退避。新修订重置退避，迟到旧失败不能改变新版本。纯请求补偿不推进增量水位线。

暂停/error Agent 的已有请求保留，分发仅选择 active Agent；Agent/资源删除通过 FK 级联清除请求，频道不再匹配时分发器清除失效请求。请求确认表示已按当前规则处理，过滤、待确认或已有下载去重均可以成功确认，不承诺每个请求必有新下载。


### 合集生命周期事务

手工创建季作品需同事务创建壳合集。合集删除和成员解绑通过 collection_lifecycle 重挂季作品、按完整作品目标重算资源合集、保留人工 work_links/文件指派；删除同时清理合集身份袋。电影无合集是合法状态。无法唯一归属的资源清除单一合集指针，不能任选成员所属合集。源/目标合集按固定顺序加锁后再锁成员，避免反向壳吸收死锁；所有下游写入异常整体回滚。启动的孤儿回填分批加锁并幂等，详见 per-season-works.md 与 db-migration.md。

### 并发季作品 upsert

复用已有合集的季成员解析在读取成员前对合集行 FOR UPDATE 并刷新，第二个匹配事务等待后重新读取成员，复用先到事务创建的作品。作品标题回退找到既有合集时也走同一路径，不绕过成员解析直接新建。新装/轻迁移的部分唯一索引仍是最终约束。锁按合集隔离；持锁阶段可能包含既有海报缓存未命中时的下载（既有 30 秒超时），同合集并发操作会等待。

D1 同季唯一约束下，去重若需继承重复行的合集，必须先在同一事务内删除并 flush 重复行，再给幸存行赋合集，避免 UPDATE 早于 DELETE 的瞬时冲突。Wikidata P179 回填发现目标合集同季已被其他作品占用时返回 ambiguous（dry-run 同样拒绝），不得以系列身份猜测作品相同，也不得更新目标标签；实际回填先锁已有目标合集。


去重补齐幸存作品字段时不得继承 number_of_seasons；该列和 seasons 的现有值可能仍承载真正未拆季旧数据的证据，本步骤不自动清空或重解释它们。人工编辑字段白名单不再包含 number_of_seasons；真正的旧多季作品仍走显式单季迁移流程，不能通过清空计数默认变为 S1。

### 作品重指后的 PendingDecision

同类型作品合并与剧集/电影跨类型转换先统一收集并按 ID 顺序锁受影响的 Agent，保留已处理历史行并更新其作品引用；资源与文件指派完成重指后，pending 根据当前覆盖重新分组。同覆盖合并候选，不同覆盖拆分；未变化的组保留原 ID。受影响旧 pending 保留为 expired，原始 pending 快照与替代 ID 存入事务档案，operation=work_rekey；这不是人工审核批准记录。未知或单候选组不产生可派发的 pending，不自动下载，后续资格由正常 Agent 流程及确认门禁复核。合并、rekey 和档案同事务回滚。受影响 Agent 通过 pending 的平面作品字段及其候选资源的作品链接/文件指派发现，按 100 行/资源 ID 分批查询，覆盖 links-only 多季包。跨类型转换同样重建当前覆盖键；转回剧集时没有明确季号的候选进入待核实档案，不猜季。P8 在已有决策键结构上使用同事务重建；仍需无键旧表升级衔接及并发完整验证。

决策确认最终校验阶段在 Agent、PendingDecision 锁之后按候选资源 ID 顺序取得资源行锁，并重新加载当前证据，锁持有至派发事务结束；AI 推荐准备阶段不持有这些资源锁。资源行修改在 PostgreSQL 上不能穿过此边界。此约束尚不等价于关联表/作品元数据的完整并发保护；仍需验证关联写路径与锁顺序。

最终确认还按固定表顺序（作品链接、文件指派）与各行 ID 锁定现有子记录，阻止已有指派 UPDATE/DELETE 绕过资源行锁；资源父行锁覆盖新增子记录的 FK 检查。批量覆盖重新加载须同时加载电影、剧集、合集等资格判断依赖，避免 populate_existing 丢弃元数据关系而错误拒绝合法电影包。文件指派更新边界已有双连接验证；关联 INSERT/DELETE 已分别通过双连接锁阻止及提交后放行验证；作品元数据和实际编辑/合并写路径的锁顺序仍需专项覆盖。

最终确认在资源和子关联引用稳定后，按固定模型顺序与主键锁定关联剧集、电影、音频作品及合集（共享行锁），再加载资格证据。涵盖资源平面字段及链接/指派引用；作品所属合集在作品锁定后读取。共享锁阻止资格所依赖的元数据在确认事务内更新。电影上映日期已通过双连接专项；剧集/合集及实际业务写路径锁顺序仍需扩大验证。

最终确认在 Agent/决策锁之后、候选资源锁之前取得频道与现有 AgentWork 的共享行锁，重新加载必填字段和订阅过滤规则。Agent 更新及 AgentWork 增删改 API 在读取/修改规则前取得与确认一致的 Agent NO KEY UPDATE 锁，协调订阅成员新增；不将 Agent 锁升级成 FOR UPDATE，避免阻断持久请求的外键 KEY SHARE。此协议要求应用内订阅写路径遵守父锁；直接外部 SQL 新增订阅不在协作锁保证范围。频道/现有订阅 UPDATE 和实际订阅 API 函数增删改已通过双连接边界验证，HTTP 中间件与其他写路径仍需扩大。

### 待决策创建与作品身份变更协调（V11）

PostgreSQL 创建决策在模型调用之后、Agent 行锁之前获取事务级共享 advisory 锁；作品合并/rekey 在扫描 pending 之前获取同一域的排他锁。均使用 try-lock，冲突必须回滚整个业务事务后重试，不能在已有业务锁下等待该锁。创建并行，作品身份变更暂时排斥创建；Turso 使用原生写冲突检测。获取协调权限后，创建重新加载候选并核验 canonical scope，拒绝已过期身份。后台失败不推进消费水位线；回填失败回滚外层保存。V11 已通过 PostgreSQL 并发专项及完整单元/API、隔离集成门禁，代码已合入本地 main（11ee930）。

### 作品删除与身份存活（D6）

剧集/电影删除遇到 AgentWork 或人工 link/assignment/raw-title mapping 时阻断。人工引用错误 details 按非零计数返回 manual_work_links、manual_file_assignments、manual_title_mappings。允许删除时，在同一事务中解除资源工作 FK、清理身份袋并删除作品；自动文件映射保留路径及文件证据、将目标置空，因此存在未分配文件的包保持未知覆盖度。身份登记必须检查作品存活，PG 以 KEY SHARE 保持目标到事务结束。

删除 API 在身份清理前取得作品 FOR UPDATE NOWAIT，55P03 整体回滚并返回 409 INVALID_STATE。现有资源和引用行同样以 NOWAIT 锁定后再检查人工计数；新 FK 引用由作品排他锁串行化。身份登记、新增引用与决策交错已有专项证据，完整单元/API 与隔离集成门禁已通过。

删除前先取得决策身份变更协调锁并锁定受影响 Agent，再锁作品及当前引用；解除资源/自动文件关联后，复用 rekey_agent_choices 审核当前候选。失去有效身份的 pending 失效并进入 DecisionMigration 审计，原候选和 scope 保留；审计在旧 PendingDecision 工作 FK 置空前形成。历史终态不改状态，不派发资源。PG 创建先行、删除先行、模型窗口删除及持锁派发已有专项验证；完整门禁及最终复核已通过；具体证据见 V12-WORK-DELETION.md。


### 发布进度与自动唤醒

频道发布序号由 `ChannelPublicationCounter` 行内 UPDATE 分配，与资源和事件在同一事务提交。PostgreSQL 行锁保持到事务结束，序号代表已提交前缀；不能用非事务自增序列代替。计数器锁不跨外部调用。新抓取资源写 created，metadata 主结果和历史集数修订写 metadata；跨频道修订按频道/资源 ID 排序发布。每资源保留一条 created 和至多一条最新 metadata，替换与资源变更原子提交/回滚，origin 始终是原创建序号。

Agent 的 baseline 控制历史准入，cursor 控制已确认发布前缀，两者独立且非负。事件需满足 `cursor < sequence <= through`，并且 `origin_sequence > baseline` 或资源在显式历史时间下界之后。快照包含 agent/channel/generation/through 和去重资源 IDs；成功确认采用 generation 条件更新，失败不吞掉未处理事件。`last_consumed_at` 保留兼容时间展示，不是消费游标；成功确认后取旧值与本轮资源时间最大值。

首次 NULL 时间且缺进度时以当前发布前缀初始化，避免静默历史派发。有旧时间却缺进度必须先停写迁移。普通频道切换保持时间字段，以新频道当前前缀为 baseline、cursor=0，并以旧时间作为历史准入下界；NULL 时间的切换留待首次初始化。普通规则/派发参数实质变更和订阅 CRUD 只更换现有 generation，不移动准入或游标；仅改名或无变化保存不失效。

指定时间扫描在处理前事务扩展历史准入、回退 cursor 至最早所选创建事件之前并更换 generation；崩溃或候选持久化失败后普通增量能重读。成功确认仅覆盖扫描开始的发布前缀。显式回填重置优先，旧 generation 的扫描或确认不得再次打开历史范围。已持久化的 RPC 错误任务仍走下载任务重试。

publication/window 运行在候选组开始及最终下载 RPC 前，用独立新会话检查当前频道和 generation，避免读取旧事务快照。已提交的范围变更阻止尚未开始的旧派发；不持数据库写锁跨网络调用，也不能撤销已开始的 RPC。显式定向请求沿用其独立语义，不以此宣称所有并发副作用都可撤销。

worker/all 调度器每 5 秒扫描 active Agent 的发布前缀与 cursor 差，缺进度且 NULL 时间的 Agent 也获得初始化唤醒。事务外 enqueue 普通 run_agent，复用稳定 agent key 去重；队列失败或忙碌不确认数据库进度，下轮补发。自动唤醒携带 `automatic=true`，handler 在创建运行前跳过非 active Agent，恢复后继续消费。B9 持久修订请求仍独立补偿，不把自动完成事件转成绕过历史准入的定向请求。

Turso MVCC 同频道计数器写冲突通过既有 `retry_on_lock` 在尚未提交的完整 metadata 操作边界有限退避重试，每次重新创建会话。metadata 和发布已经提交后，后续海报失败不重跑主事务，避免重复计次。重试耗尽记录失败，后续回填保留恢复机会。

部署迁移和启动门禁见 db-migration.md；验证记录与尚未完成的发布验收见 `docs/plans/p0-and-backlog/V13-CONSUMPTION-PROGRESS.md`。

FTS sidecar 并发：派生索引独立引擎使用 pool_size=1、max_overflow=0，短读写事务通过连接池串行，避免实验性 Turso FTS 多连接并发的原生崩溃。主业务数据库池与并发不变；sidecar checkout 内不得加入网络调用。并发调用者继续等待连接，不跳过检索或写入；全量索引重建仍须遵循已有业务契约。

### Redis 执行所有权与下载发起

下载 RPC 成功或失败返回后、持久化结果之前再次检查执行所有权；已失权时抛出并由调用者回滚，保留未 settled 的派发预留供接管者重试。不能撤销远端已经接受的请求，也不能消除检查到数据库提交之间的竞争窗口。

Agent 候选循环在入口、各候选开始和建议写入前检查所有权；失权异常直接终止，不转成普通候选错误。后台 handler 在创建运行记录前、处理完成后确认请求/消费进度前及正常收尾前检查；失权不执行失败请求延期，其他异常也须确认所有权后才补偿。此前已经提交的候选不回滚；被中断的 running 记录回收仍由单独待办跟踪。上述检查不构成 Redis 与数据库的原子提交。

待决策建议生成结束后，在 persist_choice 前检查所有权；候选独立事务或请求保存点退出前再次检查，以回滚写入等待期间失权的候选。后台独立 Turso 候选事务先显式 BEGIN，避免驱动尚未开启物理事务时，内部 SAVEPOINT 的 RELEASE 提前提交；这里使用延迟事务，不在网络调用前取得写锁。PostgreSQL 沿用原有事务开始语义。

资源重解析在开始及 finally 清除 confirmation_ignored_at 前检查所有权，清理事务退出前再检查。仍有所有权的成功/普通失败继续清理标记；失权保留标记供接管者完成。此约束不替代重解析内部元数据写入的保护，也未解决入队失败或永久崩溃造成的标记回收（B8）。

资源元数据独立事务在获得 semaphore、torrent 缓存返回、取得作品锁、主元数据处理返回及发布/提交前检查执行所有权；海报阶段提交前再次检查。主匹配与扩展路径中的 ExecutionOwnershipLostError 不作为普通 best-effort 错误吞掉，事务回滚后继续向调用者传播，锁重试包装同样不得吞掉。元数据已经提交后的海报失权只能回滚海报事务，不能撤销前一阶段；文件缓存及已发生网络请求亦不能由数据库回滚撤销。

新资源元数据、频道回填及全局回填等待所有已启动子任务返回后才传播异常，优先传播失权；不因第一个异常提前退出父任务并遗留兄弟任务。频道抓取在开始、RSS 返回、最终状态提交前及各 Agent 唤醒前检查所有权，回填失权不降为普通告警继续收尾。已经提交的资源和发布事件仍保留，不因后续失权撤销。

RSS 逐条入库在每条开始及 created 发布完成后、资源事务 commit 前再次检查所有权。该提交点发现失权时由调用方回滚资源和发布事件；它不能消除检查到数据库 commit 之间的竞争窗口。

批量文件分析在任务开始、进度更新、每个 LLM 流事件处理及结果缓存写入前检查所有权；空文件清单也遵守缓存写入检查。失权终止分析，不将旧执行结果发布到缓存。已发出的网络请求不能撤销，检查到缓存写入之间仍有竞争窗口。

下载进度同步在入口、每个下载器开始、list_torrents 返回及每下载器提交前检查所有权；RPC 失败也先检查再标记下载器 error。失权直接传播，不改写任务状态或下载器健康状态；前面下载器已提交的更新保留，未提交部分由会话回滚。检查与 commit 仍非原子。

下载器健康检查在入口、逐下载器探测前、探测返回或异常后及事务退出前检查所有权。失权不更新 status/last_checked_at；普通失败仅在仍有所有权时标记 error，整个未提交检查事务由调用会话回滚。

每日清理及元数据去重在入口、业务事务提交前检查所有权；内部抛出的失权不降为普通告警或成功返回。未提交删除由外层事务回滚。清理业务事务提交后、进入派发预留保留期清理之前再次检查；前一事务已经提交的结果不能撤销。

FTS outbox drain 在入口、删除事件前、sidecar 写入后及后台主库事务提交前检查所有权；失权不作为普通索引写失败吞掉，外层回滚保留 outbox。sidecar 已完成的写入无法随主库回滚，允许后续幂等重放。普通 sidecar 写失败的既有 reconcile 补偿策略保持不变。

FTS reconcile 在入口、每表处理前后及 sidecar 写入前检查所有权，后台包装同样传播失权。失权后停止后续表，前面已提交的 sidecar 写入保留；后续当前执行者可重新对账。

magnet launch 在领取资源前与领取事务提交前检查队列所有权，已失权不得创建 detached 解析任务。领取提交后的解析生命周期独立于队列任务结束；不能用已结束队列的租约作为解析存活条件。后台解析回收与状态更新的独立所有权仍需专门验证。

成功解析后的 torrent inspection 在独立事务内执行，提交前禁用自动 flush，以 resource ID、attempt UUID、done 状态为条件执行同值 UPDATE，取得行写锁并保持至提交。条件失配回滚 inspection 的整个事务，禁止旧检查覆盖重试后的新数据。文件及外部服务副作用不由数据库回滚保证，仍须分别验证。

magnet sweep 在入口、回收 SQL 前后（提交前）、逐个入队及返回前检查队列所有权；失权异常传播，不作为单资源入队错误吞掉。回收依赖当前状态及更新时间的条件 UPDATE，清空旧 attempt。超时阈值是恢复策略，并非进程死亡证明：等待 semaphore 的活任务也可能超时，旧任务后续写入必须受 attempt 条件保护。

领取资格仅由数据库条件 UPDATE 判断，移除按 resource ID 的进程内 inflight 去重，避免数据库已回收而旧内存标记持续阻止恢复。semaphore 继续限制实际解析并发；旧任务恢复时按旧 attempt 校验，不能获得新任务写权限。

magnet 成功后的 inspection 调用前显式加载 file_assignments，避免同步属性检查触发异步 ORM 懒加载错误，导致 done 状态下文件指派静默缺失。真实单文件种子恢复测试必须检查持久化指派路径，而不只检查 done 与缓存文件。

B4 候选的新领取分配 attempt UUID，传给独立解析；running/失败/重试计数/done 按资源及 attempt 条件更新，失去匹配停止。内部状态写入与解析循环要求显式 UUID，拒绝 NULL/空串/非法标识，不允许无身份写入历史行。缓存写入 `<resource_id>-<attempt_id>.torrent`，成功 CAS 后引用；拒绝发布只删除该 attempt 文件，删除异常记日志。sweep 回收和人工重试使旧标识失效。领取成功提交后，新解析任务复制当前 Context，仅清除队列所有权，保留其他上下文；父 Context 不变。该脱离仅用于已有独立持久所有者的任务，不能作为普通队列子任务绕过所有权检查的手段。领取后进程崩溃由超时 sweep 清空旧 attempt 并重新领取。

Redis handler 每次 claim 持有独立执行 token。创建下载任务前，从同一 Redis 事务读取 job/active/consumer lease，要求 job_id、running、token、consumer 和 active 均匹配；失权抛 ExecutionOwnershipLostError，Redis 读取失败也不允许继续发起。直接 API/MemoryQueue 无 Redis 执行上下文，沿用既有行为。此检查不保证校验之后或已开始的远端操作被撤销，不能代替下载器幂等和任务持久关联，也不代表其他 handler 副作用已经受到保护。

### 队列派发的持久幂等

Redis 逻辑作业 ID 在接管时保留，新作业使用完整 UUID hex。派发身份对 queue key/job_id/资源/Agent 作 SHA256；冻结参数包含下载器、目录、payload 类型及摘要。先在独立短事务中预留 DownloadDispatch 与任务 UUID，提交后再发 RPC；调用方此时不得持有数据库写锁。参数不一致拒绝复用。主业务事务在 RPC 之后锁住预留行，以预留 UUID 原子插入任务并标记 settled；重入只返回已存在的任务，不覆盖其状态。已删除的 settled 任务不能重建。手动 API 无 Redis 上下文，继续独立创建；重试 API 更新原任务。

这不是外部操作 exactly-once：下载器可接受两次请求，Transmission 按 torrent 身份去重，本地任务按派发身份去重。不同逻辑作业仍是不同身份，旧 writer、队列存储完全丢失后的新作业以及其他 handler 的副作用需要各自恢复协议。

派发预留事务从调用方绑定的 AsyncEngine 获取独立连接；若调用方绑定 AsyncConnection，则使用其 engine，不能加入外层连接事务，否则外层 rollback 会撤销预留。调用方无写锁跨 RPC 的前提仍需保持。

### 派发预留保留与清理

每日业务清理提交后，另行分页扫描超过 7 天且 DownloadTask 已不存在的预留。Redis 以一次事务读取 job hash 和 active key：同 job_id 仍 queued/running、active 仍指向旧作业或状态异常时保留；原作业终态、同 key 被不同 job_id 替代或原记录缺失时才可清理。Redis 故障立即停止本轮后续清理，MemoryQueue 无法证明 Redis 作业退休则保留。未知 job_key/job_id 的历史或直接写入记录保留。7 天是预留年龄，不是任务删除后的计时器。

数据库读取会话在 Redis 调用前关闭；删除事务再次要求任务不存在且 settled 与扫描时一致，防止与任务落库竞争。每页 500 条，以 created_at/id 游标推进，旧但仍活动的记录不会阻塞后续候选。已有任务的预留随任务保留；删除任务后的记录只有满足年龄与队列终态条件才删除。不得复用历史逻辑 job_id；清理后旧执行的结果持久化必须因预留缺失而拒绝。

手动批量/频道周期作品刷新共用的 `_refresh_works_batch` 在每部作品开始前检查队列所有权；`ExecutionOwnershipLostError` 终止整个批次，不作为单作品普通错误吞掉后继续处理。普通网络失败与超时仍保持单作品隔离。此为批次边界，不替代单作品元数据应用及内部 commit 的竞争保护。

单作品刷新入口与 `apply_work_metadata` 另检查队列所有权；异步元数据扩展/预览、海报获取后及内部 commit 前再次检查，失权抛出让事务所有者回滚。season-0 日期回填也在写入前检查。人工调用没有队列上下文时保持既有行为。此协议能阻止已检测失权后的提交，尚不能消除检查到 commit 的竞争窗口。

并发人工编辑保护候选：`apply_work_metadata` 先完成候选扩展及海报请求，再对作品执行保持 updated_at 不变的条件 UPDATE 获取写保护，重新加载当前行并计算人工字段排除与差异。PostgreSQL 在该行序列化写入，Turso 旧 MVCC 快照可能发生写冲突，由调用者结束事务后重试；网络请求不在该写保护阶段内。season-0 日期回填独立分支在计算后取得同类写保护、重读人工标记和日期；作品删除、季号不再为 0 或合集归属改变时不应用旧回填值。

后台批次按作品复用 `retry_on_lock`：每次尝试创建新会话、重读作品并检查队列所有权，全部尝试共用原有 120 秒上限。仅锁/MVCC 冲突重试，失权、普通网络失败不由此重试。候选搜索或海报请求可能随新尝试重复，数据库回滚不能撤销已发生的网络读取。

候选扩展前记录作品季号和合集，写保护后重读值若不同则拒绝旧候选。直接 apply 返回 409；后台刷新返回 found=false、scope_changed=true、applied=[]，不标为 identity_conflict。作品已删除继续按未找到处理。这只验证当前应用调用期间的归属变化，不替代跨请求 preview/apply 的版本契约。


已匹配合集的成员数量不构成季号证据：season_hint、季级身份、可信标题季标记及经校验单季证据均不能确定季号时，保留合集身份并返回未定季状态；即使合集只有一个成员（含 S0/S1/S3）或尚无成员，也不自动选择/创建 S1。明确人工目标 expected_series_id 是用户指定的季作品身份，可在验证同合集、季号和外部身份兼容后补全该目标，不依赖合集成员数量。

系列级候选没有季数/季号证据时，唯一同名季作品也不等于季身份；仅能归并到其合集。新系列同样先建合集并保留身份，不默认创建 S1。明确季号、已验证单季以及季级来源身份的既有语义保留。
