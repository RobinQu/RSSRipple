"""Movie ORM model."""

import uuid
from datetime import date, datetime

from sqlalchemy import JSON, Boolean, Date, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base
from app.utils.sql_time import UTCNow


class Movie(Base):
    __tablename__ = "movies"

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True, default=lambda: str(uuid.uuid4())
    )
    title_cn: Mapped[str | None] = mapped_column(String(512), nullable=True)
    title_en: Mapped[str | None] = mapped_column(String(512), nullable=True)
    original_title: Mapped[str | None] = mapped_column(String(512), nullable=True)
    aliases: Mapped[list | None] = mapped_column(JSON, nullable=True)
    # Normalized search haystack (title_cn + title_en + original_title +
    # aliases through ``normalize_title``), maintained by the ORM before_flush
    # hook. Indexed with pg_trgm GIN on PostgreSQL; Turso mirrors it into the
    # FTS sidecar via the fts_outbox drain.
    search_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    external_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    external_source: Mapped[str | None] = mapped_column(String(100), nullable=True)
    description: Mapped[str | None] = mapped_column(String(2048), nullable=True)
    poster_url: Mapped[str | None] = mapped_column(String(512), nullable=True)
    rating: Mapped[float | None] = mapped_column(Float, nullable=True)
    genre: Mapped[list | None] = mapped_column(JSON, nullable=True)
    status: Mapped[str | None] = mapped_column(String(100), nullable=True)
    release_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    runtime: Mapped[int | None] = mapped_column(Integer, nullable=True)
    content_type: Mapped[str | None] = mapped_column(String(50), nullable=True)
    # Tri-state anime flag (orthogonal to content_type's medium): True =
    # Japanese-style animation, False = confirmed live-action, None = not yet
    # determined. Assigned from deterministic evidence (bangumi/mal/anilist
    # identity, Wikipedia TVAnime infobox, TMDB Animation+ja) with an LLM
    # fallback — see app/services/anime_signals.py.
    is_anime: Mapped[bool | None] = mapped_column(Boolean, nullable=True)
    # Fields the user edited manually through the work detail edit form. Any
    # field listed here is never overwritten by an automatic metadata scan
    # (upsert / refresh) unless the refresh action is run with
    # ``override_manual_edits``. See metadata_service.MANUAL_EDITABLE_FIELDS.
    manually_edited_fields: Mapped[list | None] = mapped_column(JSON, nullable=True)
    canonical_name: Mapped[str | None] = mapped_column(String(512), nullable=True)
    wikipedia_url: Mapped[str | None] = mapped_column(String(2048), nullable=True)
    wikipedia_page_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    # Franchise grouping (WorkCollection). At most one collection per work.
    collection_id: Mapped[str | None] = mapped_column(
        String(36), ForeignKey("work_collections.id"), nullable=True
    )
    created_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=UTCNow(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=UTCNow(), onupdate=UTCNow(), nullable=False
    )

    # Relationships
    file_resources = relationship("FileResource", back_populates="movie")
    pending_decisions = relationship(
        "PendingDecision", back_populates="movie"
    )
    agent_works = relationship(
        "AgentWork", back_populates="movie"
    )
    raw_title_mappings = relationship(
        "ChannelRawTitleMapping", back_populates="movie"
    )
    collection = relationship("WorkCollection", back_populates="movies")
