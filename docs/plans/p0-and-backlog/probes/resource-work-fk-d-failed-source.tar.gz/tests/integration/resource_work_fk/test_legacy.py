"""An existing FileResource table must gain protection during actual migration."""
import pytest

from app.database import _apply_light_migrations
from tests.integration.resource_work_fk.test_constraint import _case


@pytest.mark.parametrize("work_fk_postgres", ["legacy"], indirect=True)
async def test_legacy_postgres_upgrade(work_fk_postgres):
    engine, _ = work_fk_postgres
    async with engine.begin() as conn:
        await _apply_light_migrations(conn)
        await _apply_light_migrations(conn)
    await _case(engine, (True, True, False), True, "insert")


@pytest.mark.parametrize("work_fk_turso", ["legacy"], indirect=True)
async def test_legacy_turso_upgrade(work_fk_turso):
    engine, _ = work_fk_turso
    async with engine.begin() as conn:
        await _apply_light_migrations(conn)
        await _apply_light_migrations(conn)
    await _case(engine, (True, True, False), True, "insert")
