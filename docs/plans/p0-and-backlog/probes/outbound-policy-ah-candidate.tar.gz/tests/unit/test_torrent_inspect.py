"""Unit tests for app.services.torrent_inspect.

Covers parse_torrent_files (multi-file / single-file / corrupt bytes),
analyze_torrent_files scope classification (single / season / multi_season /
franchise / unknown, sample filtering), extract_season_episode_from_path,
and fetch_torrent_file (200 / 404 / oversize / non-http) with httpx stubbed,
plus maybe_inspect_torrent (channel A write-back, preconditions, failures).
"""

from __future__ import annotations

import asyncio
import hashlib
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import bencodepy
import httpx
import pytest

import app.services.torrent_inspect as ti
from app.services.resource_parser import extract_season_episode_from_path
from app.services.torrent_inspect import (
    analyze_torrent_files,
    ensure_torrent_cached,
    fetch_torrent_file,
    maybe_inspect_torrent,
    parse_torrent_files,
)

MB = 1024 * 1024


def _torrent_bytes(payload: dict) -> bytes:
    return bencodepy.encode(payload)


def _multi_torrent(entries: list[tuple[list[str], int]]) -> bytes:
    """Build a multi-file torrent from (path components, length) pairs."""
    return _torrent_bytes({
        b"info": {
            b"name": b"root",
            b"files": [
                {b"length": length, b"path": [p.encode() for p in parts]}
                for parts, length in entries
            ],
            b"piece length": 16384,
            b"pieces": b"x" * 20,
        }
    })


def _single_torrent(name: str, length: int) -> bytes:
    return _torrent_bytes({
        b"info": {
            b"name": name.encode(),
            b"length": length,
            b"piece length": 16384,
            b"pieces": b"x" * 20,
        }
    })


def _f(name: str, size: int = 500 * MB) -> dict:
    return {"name": name, "size": size}


# =============================================================================
# parse_torrent_files
# =============================================================================

def test_parse_multi_file_torrent(tmp_path):
    p = tmp_path / "multi.torrent"
    p.write_bytes(_multi_torrent([
        (["Show S01", "Show S01E01.mkv"], 500 * MB),
        (["Show S01", "Show S01E02.mkv"], 600 * MB),
        (["特典", "bonus.mkv"], 10 * MB),
    ]))
    files = parse_torrent_files(str(p))
    assert files == [
        {"name": "Show S01/Show S01E01.mkv", "size": 500 * MB},
        {"name": "Show S01/Show S01E02.mkv", "size": 600 * MB},
        {"name": "特典/bonus.mkv", "size": 10 * MB},
    ]


def test_parse_single_file_torrent(tmp_path):
    p = tmp_path / "single.torrent"
    p.write_bytes(_single_torrent("Movie.2024.1080p.mkv", 2 * 1024 * MB))
    files = parse_torrent_files(str(p))
    assert files == [{"name": "Movie.2024.1080p.mkv", "size": 2 * 1024 * MB}]


def test_parse_path_utf8_preferred(tmp_path):
    payload = {
        b"info": {
            b"name": b"root",
            b"files": [{
                b"length": 500 * MB,
                b"path": [b"garbled\xffdir", b"ep01.mkv"],
                b"path.utf-8": ["作品A".encode(), b"ep01.mkv"],
            }],
            b"piece length": 16384,
            b"pieces": b"x" * 20,
        }
    }
    p = tmp_path / "utf8.torrent"
    p.write_bytes(_torrent_bytes(payload))
    files = parse_torrent_files(str(p))
    assert files == [{"name": "作品A/ep01.mkv", "size": 500 * MB}]


def test_parse_corrupt_bytes_returns_none(tmp_path):
    p = tmp_path / "bad.torrent"
    p.write_bytes(b"this is not bencode at all")
    assert parse_torrent_files(str(p)) is None


def test_parse_missing_file_returns_none(tmp_path):
    assert parse_torrent_files(str(tmp_path / "nope.torrent")) is None


def test_parse_no_info_dict_returns_none(tmp_path):
    p = tmp_path / "noinfo.torrent"
    p.write_bytes(_torrent_bytes({b"announce": b"http://tracker/announce"}))
    assert parse_torrent_files(str(p)) is None


# =============================================================================
# extract_season_episode_from_path
# =============================================================================

@pytest.mark.parametrize("path,expected", [
    ("Show S01/Show S01E01.mkv", (1, 1)),
    ("Show/S02/Show - 13.mkv", (2, 13)),
    ("Show/Season 3/Show - 01 [1080p].mkv", (3, 1)),
    ("[Group] 作品A 01-12/[Group] 作品A - 05.mkv", (None, 5)),
    ("作品X/第2季/作品X 第03話.mkv", (2, 3)),
    ("Movie.2024.1080p.WEB-DL.mkv", (None, None)),
    ("Show S01E12v2.mkv", (1, 12)),
    ("Show S01/Show [01a].mkv", (1, 1)),
    ("Show SP03.mkv", (0, 3)),
    ("Show OVA 02.mkv", (0, 2)),
    ("Hyouka. TV (2012) 22; BD_1080P.mkv", (None, 22)),
    # Batch range in the directory must NOT be read as episode 12.
    ("Show S01 01-12/Show S01E07.mkv", (1, 7)),
    # English-ordinal "Stage" season markers (Initial D naming).
    ("Initial D Second Stage/Initial D Second Stage - 01.mkv", (2, 1)),
    ("Initial D First Stage/Initial D First Stage - 03.mkv", (1, 3)),
    ("Initial D/Initial D Fourth Stage/Initial D Fourth Stage - 02.mkv", (4, 2)),
    ("Show/Show 2nd Stage/Show 2nd Stage - 05.mkv", (2, 5)),
    # "Final Stage" is deliberately not mapped to a season number.
    ("Initial D Final Stage/Initial D Final Stage - 01.mkv", (None, 1)),
])
def test_extract_season_episode_from_path(path, expected):
    assert extract_season_episode_from_path(path) == expected


# =============================================================================
# analyze_torrent_files
# =============================================================================

def test_analyze_single_movie():
    report = analyze_torrent_files([_f("Movie.2024.1080p.WEB-DL.mkv", 3 * 1024 * MB)])
    assert report.scope == "single"
    assert report.is_batch is False
    assert report.video_file_count == 1
    assert report.episode_start is None and report.episode_end is None


def test_analyze_season_sxxexx():
    files = [_f(f"Show S01/Show S01E{ep:02d}.mkv") for ep in range(1, 13)]
    report = analyze_torrent_files(files)
    assert report.scope == "season"
    assert report.is_batch is True
    assert report.episode_start == 1 and report.episode_end == 12
    assert report.seasons == [1]
    assert report.video_file_count == 12
    assert report.unparsed_ratio == 0.0


def test_analyze_multi_season_dirs():
    files = [_f(f"Show/S01/Show S01E{ep:02d}.mkv") for ep in range(1, 13)]
    files += [_f(f"Show/S02/Show S02E{ep:02d}.mkv") for ep in range(1, 13)]
    report = analyze_torrent_files(files)
    assert report.scope == "multi_season"
    assert report.is_batch is True
    assert report.episode_start is None and report.episode_end is None
    assert report.seasons == [1, 2]


def test_analyze_multi_season_stage_dirs_single_root():
    # Single root directory with Stage-named season subdirectories: the
    # top-level cluster is one work, seasons come from the Stage markers.
    files = [
        _f(f"Initial D/Initial D First Stage/Initial D First Stage - {ep:02d}.mkv")
        for ep in range(1, 27)
    ]
    files += [
        _f(f"Initial D/Initial D Second Stage/Initial D Second Stage - {ep:02d}.mkv")
        for ep in range(1, 14)
    ]
    report = analyze_torrent_files(files)
    assert report.scope == "multi_season"
    assert report.is_batch is True
    assert report.seasons == [1, 2]
    assert report.episode_start is None and report.episode_end is None


def test_analyze_stage_top_level_dirs_go_franchise():
    # Two distinct top-level Stage directories form two credible clusters,
    # so the franchise branch wins before the multi-season check — existing
    # behavior, unchanged by Stage-ordinal season recognition.
    files = [
        _f(f"Initial D First Stage/Initial D First Stage - {ep:02d}.mkv")
        for ep in range(1, 13)
    ]
    files += [
        _f(f"Initial D Second Stage/Initial D Second Stage - {ep:02d}.mkv")
        for ep in range(1, 13)
    ]
    report = analyze_torrent_files(files)
    assert report.scope == "franchise"
    assert report.is_batch is True
    assert report.work_titles == ["Initial D First Stage", "Initial D Second Stage"]
    assert report.seasons == [1, 2]


def test_analyze_flat_same_season():
    files = [_f(f"[Group] 作品A 01-12/[Group] 作品A - {ep:02d}.mkv") for ep in range(1, 13)]
    report = analyze_torrent_files(files)
    assert report.scope == "season"
    assert report.is_batch is True
    assert report.episode_start == 1 and report.episode_end == 12
    assert report.seasons == []


def test_analyze_single_season_plus_sp_is_season():
    # Season 0 (specials) is not a real season: one real season + SP extras
    # stays a season pack, and SP episode numbers never enter the range.
    files = [
        _f(f"Shigatsu S01/Shigatsu wa Kimi no Uso S01E{ep:02d}.mkv")
        for ep in range(1, 23)
    ]
    files.append(_f("Shigatsu S01/Shigatsu wa Kimi no Uso S00E01.mkv"))
    report = analyze_torrent_files(files)
    assert report.scope == "season"
    assert report.is_batch is True
    assert report.episode_start == 1 and report.episode_end == 22
    # The SP parse is preserved for downstream file assignments.
    assert report.seasons == [0, 1]
    sp = next(p for p in report.file_parses if "S00E01" in p["path"])
    assert sp["season"] == 0 and sp["episode"] == 1


def test_analyze_multi_season_with_sp_keeps_zero_in_coverage():
    files = [_f(f"Show/S01/Show S01E{ep:02d}.mkv") for ep in range(1, 13)]
    files += [_f(f"Show/S02/Show S02E{ep:02d}.mkv") for ep in range(1, 13)]
    files.append(_f("Show/Show S00E01.mkv"))
    report = analyze_torrent_files(files)
    assert report.scope == "multi_season"
    assert report.is_batch is True
    assert report.episode_start is None and report.episode_end is None
    assert report.seasons == [0, 1, 2]


def test_analyze_sp_only_pack_is_season():
    files = [_f(f"Show/Show S00E{ep:02d}.mkv") for ep in range(1, 4)]
    report = analyze_torrent_files(files)
    assert report.scope == "season"
    assert report.is_batch is True
    assert report.episode_start == 1 and report.episode_end == 3
    assert report.seasons == [0]


def test_analyze_franchise_clusters():
    files = [_f(f"作品X TV/作品X - {ep:02d}.mkv") for ep in range(1, 13)]
    files += [_f("作品X 剧场版/作品X 剧场版.mkv", 2 * 1024 * MB)]
    report = analyze_torrent_files(files)
    assert report.scope == "franchise"
    assert report.is_batch is True
    assert report.work_titles == ["作品X TV", "作品X 剧场版"]


def test_analyze_franchise_not_forced_on_uncredible_dirs():
    # Top-level dirs normalize to nothing credible (pure tech tags / numbers)
    # -> must NOT be judged franchise; falls through conservatively.
    files = [_f("1080p/ep01.mkv"), _f("720p/ep01.mkv")]
    report = analyze_torrent_files(files)
    assert report.scope == "unknown"
    assert report.is_batch is False
    assert report.work_titles == []


def test_analyze_all_subtitles_unknown():
    files = [
        _f("Show/ep01.chs.ass", 200 * 1024),
        _f("Show/ep02.chs.ass", 200 * 1024),
        _f("Show/font.zip", 5 * MB),
    ]
    report = analyze_torrent_files(files)
    assert report.scope == "unknown"
    assert report.is_batch is False
    assert report.video_file_count == 0


def test_analyze_empty_listing_unknown():
    report = analyze_torrent_files([])
    assert report.scope == "unknown"
    assert report.is_batch is False
    assert report.video_file_count == 0


def test_analyze_sample_mixed_in_still_season():
    files = [_f(f"Show S01/Show S01E{ep:02d}.mkv") for ep in range(1, 13)]
    files.append(_f("Show S01/Sample/Show S01 sample.mkv", 80 * MB))  # sample dir
    files.append(_f("Show S01/Show S01E01.preview.mkv", 10 * MB))  # too small
    files.append(_f("Show S01/特典/Show SP01.mkv", 300 * MB))  # extras dir
    report = analyze_torrent_files(files)
    assert report.scope == "season"
    assert report.is_batch is True
    assert report.episode_start == 1 and report.episode_end == 12
    assert report.video_file_count == 12


def test_analyze_unparseable_videos_unknown():
    files = [_f(f"Show/track{n}.mkv") for n in range(1, 5)]
    report = analyze_torrent_files(files)
    assert report.scope == "unknown"
    assert report.is_batch is False
    assert report.unparsed_ratio == 1.0


# =============================================================================
# fetch_torrent_file
# =============================================================================

def _stub_httpx(monkeypatch, *, status: int = 200, chunks: list[bytes] | None = None):
    class _Resp:
        status_code = status

        def __enter__(self_inner):
            return self_inner

        def __exit__(self_inner, *a):
            return False

        def iter_bytes(self_inner):
            yield from (chunks if chunks is not None else [b"d8:announce0:e"])

    class _Client:
        def __init__(self, *a, **kw):
            pass

        def __enter__(self_inner):
            return self_inner

        def __exit__(self_inner, *a):
            return False

        def stream(self_inner, method, url):
            return _Resp()

    async def _fake_to_thread(fn, *a, **kw):
        return fn(*a, **kw)

    async def _no_sleep(*a, **kw):
        return None

    monkeypatch.setattr(httpx, "Client", _Client)
    monkeypatch.setattr(asyncio, "to_thread", _fake_to_thread)
    monkeypatch.setattr(asyncio, "sleep", _no_sleep)


@pytest.mark.parametrize("phase", ["mkdir", "parse", "write"])
async def test_fetch_cache_work_keeps_event_loop_responsive(tmp_path, monkeypatch, phase):
    import threading

    real_to_thread = asyncio.to_thread
    source = Path("tests/fixtures/metadata_corpus_v1/torrents/987a72c09d5b0c2e934fa5016cc4dda6427a80dc5a4594e284a06ccf966acdb2.torrent")
    payload = source.read_bytes()
    _stub_httpx(monkeypatch, chunks=[payload])
    monkeypatch.setattr(asyncio, "to_thread", real_to_thread)
    monkeypatch.setattr(ti.settings, "torrent_cache_dir", str(tmp_path))
    loop = asyncio.get_running_loop()
    responsive = []
    target, attribute = (ti, "parse_torrent_payload") if phase == "parse" else (Path, "mkdir" if phase == "mkdir" else "write_bytes")
    original = getattr(target, attribute)

    def slow_operation(*args, **kwargs):
        heartbeat = threading.Event()
        loop.call_soon_threadsafe(heartbeat.set)
        responsive.append(heartbeat.wait(timeout=1))
        return original(*args, **kwargs)

    monkeypatch.setattr(target, attribute, slow_operation)
    output = await fetch_torrent_file("https://example.invalid/recorded.torrent", "responsive")
    assert output and Path(output).read_bytes() == payload
    assert responsive and all(responsive), "event loop could not run while cache work was blocked"


async def test_cancelled_cache_writer_cannot_overwrite_replacement(tmp_path, monkeypatch):
    import threading

    real_to_thread = asyncio.to_thread
    old = _single_torrent("Old.S01E01.mkv", 500 * MB)
    new = _single_torrent("New.S01E01.mkv", 500 * MB)
    _stub_httpx_counting(monkeypatch, [("respond", 200, [old]), ("respond", 200, [new])])
    monkeypatch.setattr(asyncio, "to_thread", real_to_thread)
    monkeypatch.setattr(ti.settings, "torrent_cache_dir", str(tmp_path))
    entered, release, finished = threading.Event(), threading.Event(), threading.Event()
    original = Path.write_bytes

    def delayed_write(path, content):
        if content == old:
            entered.set()
            try:
                assert release.wait(5), "test writer was not released"
                return original(path, content)
            finally:
                finished.set()
        return original(path, content)

    monkeypatch.setattr(Path, "write_bytes", delayed_write)
    task = asyncio.create_task(fetch_torrent_file("https://example.invalid/old", "same-resource"))
    try:
        assert await real_to_thread(entered.wait, 3)
        task.cancel()
        with pytest.raises(asyncio.CancelledError):
            await task
        replacement = await fetch_torrent_file("https://example.invalid/new", "same-resource")
    finally:
        release.set()
        await real_to_thread(finished.wait, 3)
        if not task.done():
            task.cancel()
            await asyncio.gather(task, return_exceptions=True)
    assert replacement and Path(replacement).read_bytes() == new


async def test_failed_cache_write_never_publishes_partial_file(tmp_path, monkeypatch):
    payload = _single_torrent("Show.S01E01.mkv", 500 * MB)
    _stub_httpx(monkeypatch, chunks=[payload])
    monkeypatch.setattr(ti.settings, "torrent_cache_dir", str(tmp_path))
    original = Path.write_bytes

    def partial_write(path, content):
        original(path, content[:4])
        raise OSError("injected partial write")

    monkeypatch.setattr(Path, "write_bytes", partial_write)
    assert await fetch_torrent_file("https://example.invalid/partial", "partial") is None
    assert list(tmp_path.iterdir()) == []


async def test_existing_cache_validation_keeps_event_loop_responsive(tmp_path, monkeypatch):
    import threading

    path = tmp_path / "existing.torrent"
    path.write_bytes(_single_torrent("Show.S01E01.mkv", 500 * MB))
    resource = SimpleNamespace(torrent_file=str(path), torrent_url="https://example.invalid", id="existing")
    original = ti.parse_torrent_files
    loop = asyncio.get_running_loop()
    responsive = []

    def slow_parse(path):
        heartbeat = threading.Event()
        loop.call_soon_threadsafe(heartbeat.set)
        responsive.append(heartbeat.wait(1))
        return original(path)

    monkeypatch.setattr(ti, "parse_torrent_files", slow_parse)
    assert await ensure_torrent_cached(resource) == str(path)
    assert responsive == [True], "existing cache parsing blocked the event loop"


async def test_fetch_success(tmp_path, monkeypatch):
    monkeypatch.setattr(ti.settings, "torrent_cache_dir", str(tmp_path))
    payload = _single_torrent("Show.S01E01.mkv", 500 * MB)
    _stub_httpx(monkeypatch, chunks=[payload])
    out = await fetch_torrent_file("https://x/abc.torrent", "rid-1")
    assert out == str(tmp_path / f"rid-1-{hashlib.sha256(payload).hexdigest()}.torrent")
    assert Path(out).read_bytes() == payload


async def test_fetch_invalid_bencode_is_not_written(tmp_path, monkeypatch):
    monkeypatch.setattr(ti.settings, "torrent_cache_dir", str(tmp_path))
    _stub_httpx(monkeypatch, chunks=[b"<!doctype html>not a torrent"])
    assert await fetch_torrent_file("https://x/invalid.torrent", "rid-invalid") is None
    assert list(tmp_path.iterdir()) == []


async def test_fetch_404_returns_none(tmp_path, monkeypatch):
    monkeypatch.setattr(ti.settings, "torrent_cache_dir", str(tmp_path))
    _stub_httpx(monkeypatch, status=404)
    assert await fetch_torrent_file("https://x/missing.torrent", "rid-2") is None
    assert list(tmp_path.iterdir()) == []


async def test_fetch_oversize_returns_none(tmp_path, monkeypatch):
    monkeypatch.setattr(ti.settings, "torrent_cache_dir", str(tmp_path))
    monkeypatch.setattr(ti, "_MAX_TORRENT_BYTES", 16)
    _stub_httpx(monkeypatch, chunks=[b"x" * 10, b"y" * 10])
    assert await fetch_torrent_file("https://x/big.torrent", "rid-3") is None
    assert list(tmp_path.iterdir()) == []


async def test_fetch_non_http_scheme_rejected(tmp_path, monkeypatch):
    monkeypatch.setattr(ti.settings, "torrent_cache_dir", str(tmp_path))
    assert await fetch_torrent_file("magnet:?xt=urn:btih:abc", "rid-4") is None
    assert await fetch_torrent_file("ftp://x/a.torrent", "rid-4") is None


async def test_fetch_network_error_returns_none(tmp_path, monkeypatch):
    monkeypatch.setattr(ti.settings, "torrent_cache_dir", str(tmp_path))

    class _Client:
        def __init__(self, *a, **kw):
            pass

        def __enter__(self_inner):
            return self_inner

        def __exit__(self_inner, *a):
            return False

        def stream(self_inner, method, url):
            raise httpx.ConnectError("connection refused")

    async def _fake_to_thread(fn, *a, **kw):
        return fn(*a, **kw)

    async def _no_sleep(*a, **kw):
        return None

    monkeypatch.setattr(httpx, "Client", _Client)
    monkeypatch.setattr(asyncio, "to_thread", _fake_to_thread)
    monkeypatch.setattr(asyncio, "sleep", _no_sleep)
    assert await fetch_torrent_file("https://x/a.torrent", "rid-5") is None


# fetch_torrent_file retry budget (one retry for transient failures only)

def _stub_httpx_counting(monkeypatch, behaviors):
    """Stub httpx.Client where ``behaviors`` is a list of per-attempt actions:
    ``("raise", exc)`` / ``("respond", status, chunks)``. Returns the call
    counter list (``calls[0]`` = number of download attempts)."""
    calls = [0]

    class _Resp:
        def __init__(self_inner, status, chunks):
            self_inner.status_code = status
            self_inner._chunks = chunks

        def __enter__(self_inner):
            return self_inner

        def __exit__(self_inner, *a):
            return False

        def iter_bytes(self_inner):
            yield from self_inner._chunks

    class _Client:
        def __init__(self, *a, **kw):
            pass

        def __enter__(self_inner):
            return self_inner

        def __exit__(self_inner, *a):
            return False

        def stream(self_inner, method, url):
            idx = min(calls[0], len(behaviors) - 1)
            calls[0] += 1
            action = behaviors[idx]
            if action[0] == "raise":
                raise action[1]
            _, status, chunks = action
            return _Resp(status, chunks)

    async def _fake_to_thread(fn, *a, **kw):
        return fn(*a, **kw)

    async def _no_sleep(*a, **kw):
        return None

    monkeypatch.setattr(httpx, "Client", _Client)
    monkeypatch.setattr(asyncio, "to_thread", _fake_to_thread)
    monkeypatch.setattr(asyncio, "sleep", _no_sleep)
    return calls


async def test_fetch_retries_transient_failure_then_succeeds(tmp_path, monkeypatch):
    monkeypatch.setattr(ti.settings, "torrent_cache_dir", str(tmp_path))
    payload = _single_torrent("Show.S01E01.mkv", 500 * MB)
    calls = _stub_httpx_counting(monkeypatch, [
        ("raise", httpx.ConnectError("connection refused")),
        ("respond", 200, [payload]),
    ])
    out = await fetch_torrent_file("https://x/retry.torrent", "rid-retry")
    assert out == str(tmp_path / f"rid-retry-{hashlib.sha256(payload).hexdigest()}.torrent")
    assert calls[0] == 2


async def test_fetch_transient_failure_exhausts_attempts(tmp_path, monkeypatch):
    monkeypatch.setattr(ti.settings, "torrent_cache_dir", str(tmp_path))
    calls = _stub_httpx_counting(monkeypatch, [
        ("raise", httpx.ConnectError("connection refused")),
        ("raise", httpx.ReadTimeout("timed out")),
    ])
    assert await fetch_torrent_file("https://x/down.torrent", "rid-down") is None
    assert calls[0] == 2
    assert list(tmp_path.iterdir()) == []


async def test_fetch_404_retried_once(tmp_path, monkeypatch):
    monkeypatch.setattr(ti.settings, "torrent_cache_dir", str(tmp_path))
    calls = _stub_httpx_counting(monkeypatch, [
        ("respond", 404, [b""]),
        ("respond", 404, [b""]),
    ])
    assert await fetch_torrent_file("https://x/missing.torrent", "rid-404") is None
    assert calls[0] == 2


async def test_fetch_oversize_not_retried(tmp_path, monkeypatch):
    monkeypatch.setattr(ti.settings, "torrent_cache_dir", str(tmp_path))
    monkeypatch.setattr(ti, "_MAX_TORRENT_BYTES", 16)
    calls = _stub_httpx_counting(monkeypatch, [
        ("respond", 200, [b"x" * 10, b"y" * 10]),
        ("respond", 200, [b"x" * 10, b"y" * 10]),
    ])
    assert await fetch_torrent_file("https://x/big.torrent", "rid-big2") is None
    assert calls[0] == 1


async def test_fetch_invalid_bencode_not_retried(tmp_path, monkeypatch):
    monkeypatch.setattr(ti.settings, "torrent_cache_dir", str(tmp_path))
    calls = _stub_httpx_counting(monkeypatch, [
        ("respond", 200, [b"<!doctype html>not a torrent"]),
        ("respond", 200, [b"<!doctype html>not a torrent"]),
    ])
    assert await fetch_torrent_file("https://x/html.torrent", "rid-html") is None
    assert calls[0] == 1


# =============================================================================
# maybe_inspect_torrent (channel A)
# =============================================================================

def _resource(**over):
    base = dict(
        id="rid-a",
        is_batch=False,
        torrent_url="https://x/pack.torrent",
        torrent_file=None,
        batch_scope=None,
        season=1,
        episode=5,
        episode_start=None,
        episode_end=None,
        series_id=None,
        movie_id=None,
        collection_id=None,
    )
    base.update(over)
    return SimpleNamespace(**base)


def _stub_pipeline(monkeypatch, files, path="/tmp/rid-a.torrent"):
    async def _fake_fetch(url, rid):
        return path

    monkeypatch.setattr(ti, "fetch_torrent_file", _fake_fetch)
    monkeypatch.setattr(ti, "parse_torrent_files", lambda p: files)


@pytest.mark.parametrize("operation", ["parse_torrent_files", "analyze_torrent_files"])
async def test_inspection_keeps_event_loop_responsive(tmp_path, monkeypatch, operation):
    import threading

    source = Path("tests/fixtures/metadata_corpus_v1/torrents/987a72c09d5b0c2e934fa5016cc4dda6427a80dc5a4594e284a06ccf966acdb2.torrent")
    path = tmp_path / "recorded.torrent"
    path.write_bytes(source.read_bytes())
    resource = _resource(torrent_file=str(path))
    original = getattr(ti, operation)
    loop = asyncio.get_running_loop()
    responsive = []

    def slow_operation(*args):
        heartbeat = threading.Event()
        loop.call_soon_threadsafe(heartbeat.set)
        responsive.append(heartbeat.wait(1))
        return original(*args)

    monkeypatch.setattr(ti, operation, slow_operation)
    await maybe_inspect_torrent(None, resource)
    assert responsive and all(responsive), "inspection blocked the queue event loop"
    assert resource.torrent_file == str(path)


async def test_inspect_season_pack_full_flow(monkeypatch):
    _stub_pipeline(monkeypatch, [
        _f("Show.S01E01.1080p.mkv"),
        _f("Show.S01E02.1080p.mkv"),
        _f("Show.S01E03.1080p.mkv"),
    ])
    r = _resource()
    assert await maybe_inspect_torrent(None, r) is True
    assert r.is_batch is True
    assert r.batch_scope == "season"
    assert r.episode is None
    assert r.episode_start == 1
    assert r.episode_end == 3
    assert r.torrent_file == "/tmp/rid-a.torrent"


async def test_inspect_multi_season_clears_episode_fields(monkeypatch):
    _stub_pipeline(monkeypatch, [
        _f("Show.S01E01.1080p.mkv"),
        _f("Show.S02E01.1080p.mkv"),
    ])
    r = _resource()
    assert await maybe_inspect_torrent(None, r) is True
    assert r.is_batch is True
    assert r.batch_scope == "multi_season"
    assert r.season is None
    assert r.episode is None
    assert r.episode_start is None
    assert r.episode_end is None


async def test_inspect_franchise_keeps_work_fks(monkeypatch):
    import app.services.franchise_service as fs_mod

    linked = []

    async def _fake_link(db, resource, report, channel):
        linked.append((resource, sorted(report.work_titles), channel))

    monkeypatch.setattr(fs_mod, "link_franchise_pack", _fake_link)
    _stub_pipeline(monkeypatch, [
        _f("作品X TV/作品X S01E01.mkv"),
        _f("作品X TV/作品X S01E02.mkv"),
        _f("作品X 剧场版/作品X Movie.mkv"),
    ])
    r = _resource(series_id="s-1", collection_id=None)
    channel = SimpleNamespace(id="ch-1", metadata_source="wikipedia")
    assert await maybe_inspect_torrent(None, r, channel) is True
    assert r.is_batch is True
    assert r.batch_scope == "franchise"
    assert r.episode is None
    # The pack verdict does not itself touch work FKs / collection_id —
    # link_franchise_pack (mocked away here) owns those writes.
    assert r.series_id == "s-1"
    assert r.collection_id is None
    # Wiring: the linker ran with the report and the channel.
    assert linked == [(r, ["作品X TV", "作品X 剧场版"], channel)]


async def test_inspect_franchise_link_failure_keeps_verdict(monkeypatch):
    import app.services.franchise_service as fs_mod

    async def _boom(db, resource, report, channel):
        raise RuntimeError("llm down")

    monkeypatch.setattr(fs_mod, "link_franchise_pack", _boom)
    _stub_pipeline(monkeypatch, [
        _f("作品X TV/作品X S01E01.mkv"),
        _f("作品X TV/作品X S01E02.mkv"),
        _f("作品X 剧场版/作品X Movie.mkv"),
    ])
    r = _resource()
    assert await maybe_inspect_torrent(None, r) is True
    assert r.is_batch is True
    assert r.batch_scope == "franchise"


async def test_inspect_single_keeps_verdict_and_cache(monkeypatch):
    _stub_pipeline(monkeypatch, [_f("Show.S01E05.1080p.mkv")])
    r = _resource()
    assert await maybe_inspect_torrent(None, r) is False
    assert r.is_batch is False
    assert r.batch_scope is None
    assert r.episode == 5
    assert r.torrent_file == "/tmp/rid-a.torrent"


async def test_inspect_single_writes_episode_from_01a_filename(monkeypatch):
    _stub_pipeline(monkeypatch, [_f("Show S01/Show [01a].mkv")])
    r = _resource(series_id="series-1", season=None, episode=None)
    assert await maybe_inspect_torrent(None, r) is False
    assert r.season == 1
    assert r.episode == 1
    assert r.episode_confidence == "raw"


async def test_inspect_magnet_skipped(monkeypatch):
    async def _boom(url, rid):  # pragma: no cover - must not be called
        raise AssertionError("fetch_torrent_file called for magnet")

    monkeypatch.setattr(ti, "fetch_torrent_file", _boom)
    r = _resource(torrent_url="magnet:?xt=urn:btih:abc")
    assert await maybe_inspect_torrent(None, r) is False
    assert r.torrent_file is None
    assert r.is_batch is False


async def test_inspect_already_batch_skipped(monkeypatch):
    async def _boom(url, rid):  # pragma: no cover - must not be called
        raise AssertionError("fetch_torrent_file called for batch resource")

    monkeypatch.setattr(ti, "fetch_torrent_file", _boom)
    # 信息完整（scope 已细分、season 包集数范围齐全）的合集不重跑。
    r = _resource(is_batch=True, batch_scope="season", episode_start=1, episode_end=3)
    assert await maybe_inspect_torrent(None, r) is False
    assert r.batch_scope == "season"


async def test_inspect_enriches_unscoped_batch(monkeypatch):
    """标题正则判出的合集（batch_scope NULL）用 torrent 清单补齐 scope
    与集数范围。"""
    _stub_pipeline(monkeypatch, [
        _f("[ANi] 勇者之渣 - 01 [1080P][Baha].mkv"),
        _f("[ANi] 勇者之渣 - 02 [1080P][Baha].mkv"),
        _f("[ANi] 勇者之渣 - 03 [1080P][Baha].mkv"),
    ])
    r = _resource(is_batch=True, batch_scope=None, episode=None, season=None)
    assert await maybe_inspect_torrent(None, r) is True
    assert r.is_batch is True
    assert r.batch_scope == "season"
    assert r.episode_start == 1
    assert r.episode_end == 3


async def test_inspect_enriches_season_batch_missing_range(monkeypatch):
    """scope=season 但缺集数范围的合集同样补齐范围。"""
    _stub_pipeline(monkeypatch, [
        _f("Show.S01E01.1080p.mkv"),
        _f("Show.S01E02.1080p.mkv"),
    ])
    r = _resource(is_batch=True, batch_scope="season", episode=None)
    assert await maybe_inspect_torrent(None, r) is True
    assert r.episode_start == 1
    assert r.episode_end == 2


class _FakeDb:
    """Minimal db double: only ``get`` is used by the season backfill path."""

    def __init__(self, series=None, *, raises=False):
        self._series = series
        self._raises = raises

    async def get(self, model, pk):
        if self._raises:
            raise RuntimeError("db down")
        return self._series


def _series_ns(**kw):
    base = dict(number_of_seasons=None, seasons=None,
                external_source="", external_id="")
    base.update(kw)
    return SimpleNamespace(**base)


async def test_inspect_season_branch_defaults_single_season(monkeypatch):
    """season 分支：无季标记合集 linked 到可验证单季作品 → season=1。"""
    _stub_pipeline(monkeypatch, [
        _f("Show - 01 [1080p].mkv"),
        _f("Show - 02 [1080p].mkv"),
    ])
    db = _FakeDb(_series_ns(number_of_seasons=1,
                            seasons=[{"season_number": 1, "episode_count": 12}]))
    r = _resource(series_id="s-1", season=None, episode=None)
    assert await maybe_inspect_torrent(db, r) is True
    assert r.batch_scope == "season"
    assert r.season == 1


async def test_inspect_season_branch_multi_season_stays_none(monkeypatch):
    """多季作品绝不猜季号：season 保持 None（走 batch coverage 门禁）。"""
    _stub_pipeline(monkeypatch, [
        _f("Show - 01 [1080p].mkv"),
        _f("Show - 02 [1080p].mkv"),
    ])
    db = _FakeDb(_series_ns(number_of_seasons=3))
    r = _resource(series_id="s-1", season=None, episode=None)
    assert await maybe_inspect_torrent(db, r) is True
    assert r.batch_scope == "season"
    assert r.season is None


async def test_inspect_season_branch_bangumi_single_entry(monkeypatch):
    """Bangumi 条目级单季证据（external_source=bangumi）同样补 season=1。"""
    _stub_pipeline(monkeypatch, [
        _f("Show - 01 [1080p].mkv"),
        _f("Show - 02 [1080p].mkv"),
    ])
    db = _FakeDb(_series_ns(external_source="bangumi", external_id="bangumi:123"))
    r = _resource(series_id="s-1", season=None, episode=None)
    assert await maybe_inspect_torrent(db, r) is True
    assert r.season == 1


async def test_inspect_season_branch_db_failure_tolerated(monkeypatch):
    """series 查询失败不阻断检测：batch 判定照常，season 保持 None。"""
    _stub_pipeline(monkeypatch, [
        _f("Show - 01 [1080p].mkv"),
        _f("Show - 02 [1080p].mkv"),
    ])
    db = _FakeDb(raises=True)
    r = _resource(series_id="s-1", season=None, episode=None)
    assert await maybe_inspect_torrent(db, r) is True
    assert r.batch_scope == "season"
    assert r.season is None


async def test_inspect_batch_single_listing_keeps_verdict(monkeypatch):
    """已判合集但清单只见到单文件（single/unknown）→ 不降级既有判定。"""
    _stub_pipeline(monkeypatch, [_f("Show.S01E05.1080p.mkv")])
    r = _resource(is_batch=True, batch_scope=None, episode=None)
    assert await maybe_inspect_torrent(None, r) is False
    assert r.is_batch is True
    assert r.batch_scope is None
    assert r.torrent_file == "/tmp/rid-a.torrent"


async def test_inspect_download_failure_silent(monkeypatch):
    async def _none(url, rid):
        return None

    monkeypatch.setattr(ti, "fetch_torrent_file", _none)
    r = _resource()
    assert await maybe_inspect_torrent(None, r) is False
    assert r.is_batch is False
    assert r.torrent_file is None


async def test_inspect_parse_failure_silent(monkeypatch):
    _stub_pipeline(monkeypatch, None)
    r = _resource()
    assert await maybe_inspect_torrent(None, r) is False
    assert r.is_batch is False
    # The cached file path survives a parse failure.
    assert r.torrent_file == "/tmp/rid-a.torrent"


# =============================================================================
# ensure_torrent_cached + cache reuse in maybe_inspect_torrent
# =============================================================================

async def test_ensure_caches_when_missing(monkeypatch):
    async def _fake_fetch(url, rid):
        return "/tmp/rid-a.torrent"

    monkeypatch.setattr(ti, "fetch_torrent_file", _fake_fetch)
    r = _resource()
    assert await ensure_torrent_cached(r) == "/tmp/rid-a.torrent"
    assert r.torrent_file == "/tmp/rid-a.torrent"


async def test_ensure_skips_fetch_when_cache_exists(tmp_path, monkeypatch):
    cached = tmp_path / "rid-a.torrent"
    cached.write_bytes(b"d4:infod4:name4:spam6:lengthi1eee")

    async def _boom(url, rid):  # pragma: no cover - must not be called
        raise AssertionError("fetch_torrent_file called with a live cache")

    monkeypatch.setattr(ti, "fetch_torrent_file", _boom)
    r = _resource(torrent_file=str(cached))
    assert await ensure_torrent_cached(r) == str(cached)
    assert r.torrent_file == str(cached)


async def test_ensure_refetches_when_cache_file_deleted(tmp_path, monkeypatch):
    missing = str(tmp_path / "gone.torrent")

    async def _fake_fetch(url, rid):
        return "/tmp/rid-a.torrent"

    monkeypatch.setattr(ti, "fetch_torrent_file", _fake_fetch)
    r = _resource(torrent_file=missing)
    assert await ensure_torrent_cached(r) == "/tmp/rid-a.torrent"
    assert r.torrent_file == "/tmp/rid-a.torrent"


async def test_ensure_skips_magnet(monkeypatch):
    async def _boom(url, rid):  # pragma: no cover - must not be called
        raise AssertionError("fetch_torrent_file called for magnet")

    monkeypatch.setattr(ti, "fetch_torrent_file", _boom)
    r = _resource(torrent_url="magnet:?xt=urn:btih:abc")
    assert await ensure_torrent_cached(r) is None
    assert r.torrent_file is None


async def test_ensure_fetch_failure_silent(monkeypatch):
    async def _none(url, rid):
        return None

    monkeypatch.setattr(ti, "fetch_torrent_file", _none)
    r = _resource()
    assert await ensure_torrent_cached(r) is None
    assert r.torrent_file is None


async def test_inspect_reuses_existing_cache(tmp_path, monkeypatch):
    """maybe_inspect_torrent must not re-download when the fetch pipeline's
    ensure_torrent_cached already cached the .torrent."""
    cached = tmp_path / "rid-a.torrent"
    cached.write_bytes(b"not-really-parsed")

    async def _boom(url, rid):  # pragma: no cover - must not be called
        raise AssertionError("fetch_torrent_file called with a live cache")

    monkeypatch.setattr(ti, "fetch_torrent_file", _boom)
    monkeypatch.setattr(ti, "parse_torrent_files", lambda p: [
        _f("Show.S01E01.1080p.mkv"),
        _f("Show.S01E02.1080p.mkv"),
    ])
    r = _resource(torrent_file=str(cached))
    assert await maybe_inspect_torrent(None, r) is True
    assert r.is_batch is True
    assert r.batch_scope == "season"
    assert r.torrent_file == str(cached)


# =============================================================================
# fetch_torrent_file edge branches
# =============================================================================

async def test_fetch_no_cache_dir_returns_none(monkeypatch):
    monkeypatch.setattr(ti.settings, "torrent_cache_dir", "")
    assert await fetch_torrent_file("https://x/a.torrent", "rid-none") is None


async def test_fetch_cache_dir_not_writable_returns_none(tmp_path, monkeypatch):
    monkeypatch.setattr(ti.settings, "torrent_cache_dir", str(tmp_path))

    class _BadDir(Path):
        def mkdir(self, *a, **kw):
            raise OSError("permission denied")

    monkeypatch.setattr(ti, "Path", _BadDir)
    _stub_httpx(monkeypatch, chunks=[b"d8:announce0:e"])
    assert await fetch_torrent_file("https://x/a.torrent", "rid-nodir") is None


async def test_fetch_write_failure_returns_none(tmp_path, monkeypatch):
    monkeypatch.setattr(ti.settings, "torrent_cache_dir", str(tmp_path))
    payload = _single_torrent("Show.S01E01.mkv", 500 * MB)
    _stub_httpx(monkeypatch, chunks=[payload])

    def _boom_write(self, data):
        raise OSError("disk full")

    monkeypatch.setattr(ti.Path, "write_bytes", _boom_write)
    assert await fetch_torrent_file("https://x/write.torrent", "rid-write") is None
    assert list(tmp_path.iterdir()) == []


# =============================================================================
# parse_torrent_payload structural rejects
# =============================================================================

def test_parse_non_dict_payload_returns_none(tmp_path):
    p = tmp_path / "nondict.torrent"
    p.write_bytes(bencodepy.encode(b"spam"))
    assert parse_torrent_files(str(p)) is None


def test_parse_files_entry_not_dict_returns_none(tmp_path):
    p = tmp_path / "junk.torrent"
    p.write_bytes(_torrent_bytes({
        b"info": {b"name": b"root", b"files": [b"junk"],
                  b"piece length": 16384, b"pieces": b"x" * 20},
    }))
    assert parse_torrent_files(str(p)) is None


def test_parse_files_entry_bad_shape_returns_none(tmp_path):
    p = tmp_path / "bad.torrent"
    p.write_bytes(_torrent_bytes({
        b"info": {b"name": b"root",
                  b"files": [{b"length": b"100", b"path": [b"a.mkv"]}],
                  b"piece length": 16384, b"pieces": b"x" * 20},
    }))
    assert parse_torrent_files(str(p)) is None


def test_parse_single_file_missing_length_returns_none(tmp_path):
    p = tmp_path / "nolength.torrent"
    p.write_bytes(_torrent_bytes({b"info": {b"name": b"x.mkv"}}))
    assert parse_torrent_files(str(p)) is None


def test_decode_text_passes_str_through():
    assert ti._decode_text("作品A") == "作品A"
    assert ti._decode_text(b"\xff") == "\ufffd"


# =============================================================================
# read_torrent_root_name
# =============================================================================

def test_read_torrent_root_name_decode_failure(tmp_path):
    p = tmp_path / "bad.torrent"
    p.write_bytes(b"not bencode")
    assert ti.read_torrent_root_name(str(p)) is None


def test_read_torrent_root_name_non_dict_payload(tmp_path):
    p = tmp_path / "nondict.torrent"
    p.write_bytes(bencodepy.encode(b"spam"))
    assert ti.read_torrent_root_name(str(p)) is None


def test_read_torrent_root_name_single_file_returns_none(tmp_path):
    p = tmp_path / "single.torrent"
    p.write_bytes(_single_torrent("Movie.mkv", 100))
    assert ti.read_torrent_root_name(str(p)) is None


def test_read_torrent_root_name_multi_file(tmp_path):
    p = tmp_path / "multi.torrent"
    p.write_bytes(_multi_torrent([(["Show S01", "a.mkv"], 100)]))
    assert ti.read_torrent_root_name(str(p)) == "root"


# =============================================================================
# _is_main_video defensive branch
# =============================================================================

def test_is_main_video_empty_path_components():
    assert ti._is_main_video({"name": "///", "size": 500 * MB}) is False


# =============================================================================
# ensure_torrent_cached poison-cache handling
# =============================================================================

async def test_ensure_removes_poison_cache_then_fetches(tmp_path, monkeypatch):
    """A cache file that exists but fails to parse (HTML error page persisted
    by an old implementation) is unlinked before a fresh fetch."""
    poison = tmp_path / "poison.torrent"
    poison.write_bytes(b"<!doctype html><html></html>")

    async def _fake_fetch(url, rid):
        return "/tmp/rid-a.torrent"

    monkeypatch.setattr(ti, "fetch_torrent_file", _fake_fetch)
    r = _resource(torrent_file=str(poison))
    assert await ensure_torrent_cached(r) == "/tmp/rid-a.torrent"
    assert r.torrent_file == "/tmp/rid-a.torrent"
    assert not poison.exists()


async def test_ensure_unlink_failure_still_refetches(tmp_path, monkeypatch):
    """An unlink failure on the poison cache degrades silently — the fetch
    proceeds and the fresh path is written back."""
    poison = tmp_path / "poison.torrent"
    poison.write_bytes(b"<!doctype html><html></html>")

    def _boom_unlink(self, *a, **kw):
        raise OSError("permission denied")

    monkeypatch.setattr(ti.Path, "unlink", _boom_unlink)

    async def _fake_fetch(url, rid):
        return "/tmp/rid-a.torrent"

    monkeypatch.setattr(ti, "fetch_torrent_file", _fake_fetch)
    r = _resource(torrent_file=str(poison))
    assert await ensure_torrent_cached(r) == "/tmp/rid-a.torrent"
    assert r.torrent_file == "/tmp/rid-a.torrent"


async def test_ensure_fetch_exception_silent(monkeypatch):
    async def _boom(url, rid):
        raise RuntimeError("network down")

    monkeypatch.setattr(ti, "fetch_torrent_file", _boom)
    r = _resource()
    assert await ensure_torrent_cached(r) is None
    assert r.torrent_file is None


# =============================================================================
# maybe_inspect_torrent: complete-batch skip, stale-cache, enrichment, crash
# =============================================================================

async def test_inspect_complete_batch_with_assignments_skipped(db_session, sample_channel):
    """A fully-scoped batch whose file assignments already exist is left alone
    (verdict_complete + non-empty file_assignments → short-circuit)."""
    import uuid

    from app.models.file_resource import FileResource
    from app.models.resource_file_assignment import ResourceFileAssignment

    r = FileResource(
        id=str(uuid.uuid4()), channel_id=sample_channel.id, guid=str(uuid.uuid4()),
        title_raw="Show", torrent_url="https://x/pack.torrent",
        is_batch=True, batch_scope="season", episode_start=1, episode_end=3,
    )
    a = ResourceFileAssignment(
        resource_id=r.id, file_path="Show.S01E01.mkv", source="auto",
    )
    db_session.add_all([r, a])
    await db_session.commit()
    assert await maybe_inspect_torrent(db_session, r) is False


async def test_inspect_unlinks_stale_poison_cache(tmp_path, monkeypatch):
    """A stale unparseable cache file never blocks a later valid fetch."""
    poison = tmp_path / "poison.torrent"
    poison.write_bytes(b"<!doctype html><html></html>")
    good = tmp_path / "good.torrent"
    good.write_bytes(b"not-really-parsed")

    async def _fake_fetch(url, rid):
        return str(good)

    def _fake_parse(path):
        if str(path) == str(poison):
            return None
        return [_f("Show.S01E01.1080p.mkv"), _f("Show.S01E02.1080p.mkv")]

    monkeypatch.setattr(ti, "fetch_torrent_file", _fake_fetch)
    monkeypatch.setattr(ti, "parse_torrent_files", _fake_parse)
    r = _resource(torrent_file=str(poison))
    assert await maybe_inspect_torrent(None, r) is True
    assert r.batch_scope == "season"
    assert r.torrent_file == str(good)
    assert not poison.exists()


async def test_inspect_unlink_failure_tolerated(tmp_path, monkeypatch):
    """An unlink failure on a poison cache degrades silently — the fresh fetch
    still happens and the batch verdict still lands."""
    poison = tmp_path / "poison.torrent"
    poison.write_bytes(b"<!doctype html><html></html>")
    good = tmp_path / "good.torrent"
    good.write_bytes(b"not-really-parsed")

    def _boom_unlink(self, *a, **kw):
        raise OSError("permission denied")

    monkeypatch.setattr(ti.Path, "unlink", _boom_unlink)

    async def _fake_fetch(url, rid):
        return str(good)

    def _fake_parse(path):
        if str(path) == str(poison):
            return None
        return [_f("Show.S01E01.1080p.mkv"), _f("Show.S01E02.1080p.mkv")]

    monkeypatch.setattr(ti, "fetch_torrent_file", _fake_fetch)
    monkeypatch.setattr(ti, "parse_torrent_files", _fake_parse)
    r = _resource(torrent_file=str(poison))
    assert await maybe_inspect_torrent(None, r) is True
    assert r.batch_scope == "season"
    assert r.torrent_file == str(good)


# ---------------------------------------------------------------------------
# Enrichment pass (apply_auto_assignments / season_ranges / gated LLM refine)
# ---------------------------------------------------------------------------

def _assign_resource(**over):
    """Like ``_resource`` but exposes the enrichment surface (file_assignments
    list, subtitle fields, search titles, season_ranges)."""
    r = _resource(**over)
    r.file_assignments = []
    r.subtitle_group = None
    r.subtitle_groups = None
    r.subtitle_groups_source = None
    r.season_ranges = None
    r.search_title = "Show"
    r.title_cn = None
    r.title_raw = "Show"
    r.episode_confidence = None
    return r


class _EnrichDb:
    """Minimal db double whose refresh is a no-op (SimpleNamespace resource)."""

    async def refresh(self, obj, attrs=None):
        return None

    async def get(self, model, pk):
        return None


async def test_inspect_season_enrichment_writes_assignments(monkeypatch):
    """Every main video file gets a durable auto assignment row + ranges."""
    _stub_pipeline(monkeypatch, [
        _f("Show.S01E01.1080p.mkv"),
        _f("Show.S01E02.1080p.mkv"),
    ])
    r = _assign_resource()
    assert await maybe_inspect_torrent(_EnrichDb(), r) is True
    assert r.is_batch is True
    assert r.batch_scope == "season"
    assert len(r.file_assignments) == 2
    assert r.season_ranges == [
        {"season": 1, "episode_start": 1, "episode_end": 2}
    ]


async def test_inspect_enrichment_survives_refresh_failure(monkeypatch):
    """A db.refresh hiccup in the enrichment pass degrades silently — the
    deterministic assignment write-back still happens."""
    _stub_pipeline(monkeypatch, [
        _f("Show.S01E01.1080p.mkv"),
        _f("Show.S01E02.1080p.mkv"),
    ])
    r = _assign_resource()

    class _BoomDb:
        async def refresh(self, obj, attrs=None):
            raise RuntimeError("pending row")

    assert await maybe_inspect_torrent(_BoomDb(), r) is True
    assert r.is_batch is True
    assert r.batch_scope == "season"
    assert len(r.file_assignments) == 2


async def test_inspect_franchise_llm_failure_degrades_and_links(monkeypatch):
    """A crashing LLM refinement must not lose the batch verdict — the
    deterministic franchise linking then still runs."""
    monkeypatch.setattr(ti.settings, "llm_api_key", "sk-test")
    import app.services.batch_content_analysis as bca_mod

    refine = AsyncMock(side_effect=RuntimeError("llm down"))
    monkeypatch.setattr(bca_mod, "refine_batch_content", refine)
    link = AsyncMock()
    monkeypatch.setattr(
        "app.services.franchise_service.link_franchise_pack", link
    )
    _stub_pipeline(monkeypatch, [
        _f("作品X TV/作品X S01E01.mkv"),
        _f("作品X TV/作品X S01E02.mkv"),
        _f("作品X 剧场版/作品X Movie.mkv"),
    ])
    r = _assign_resource()
    assert await maybe_inspect_torrent(_EnrichDb(), r) is True
    assert r.is_batch is True
    assert r.batch_scope == "franchise"
    link.assert_awaited_once()


async def test_inspect_unexpected_fetch_error_returns_false(monkeypatch):
    """Any unexpected exception inside the inspection body is swallowed and
    reported as a no-op (False)."""

    async def _boom(url, rid):
        raise RuntimeError("network gone")

    monkeypatch.setattr(ti, "fetch_torrent_file", _boom)
    r = _resource()
    assert await maybe_inspect_torrent(None, r) is False
    assert r.torrent_file is None


# ---------------------------------------------------------------------------
# Frieren BD-box regression: "S01 + S02" pack whose listing uses season
# directories with bare-number filenames ("Frieren S01/01 [VOSTFR].mkv").
# ---------------------------------------------------------------------------


def _frieren_listing() -> list[dict]:
    mb = 500 * 1024 * 1024
    files = [
        {"name": f"Frieren S01/{ep:02d} [VOSTFR] [BDRip 1080p].mkv", "size": mb}
        for ep in range(1, 29)
    ]
    files += [
        {"name": f"Frieren S02/{ep:02d} [VOSTFR] [BDRip 1080p].mkv", "size": mb}
        for ep in range(1, 13)
    ]
    return files


def test_frieren_bd_pack_multi_season_with_ranges():
    report = ti.analyze_torrent_files(_frieren_listing())
    assert report.scope == "multi_season"
    assert report.is_batch is True
    assert report.seasons == [1, 2]
    # Per-season ranges come free from the same parses — no LLM needed.
    assert {"season": 1, "episode_start": 1, "episode_end": 28} in report.season_ranges
    assert {"season": 2, "episode_start": 1, "episode_end": 12} in report.season_ranges
    # Both season dirs normalize to ONE work cluster (same title).
    assert len(report.clusters) == 1
    assert len(report.file_parses) == 40
    sample = report.file_parses[0]
    assert sample["season"] == 1 and sample["episode"] == 1


def test_extract_path_season_from_dir_and_bare_number_filename():
    from app.services.resource_parser import extract_season_episode_from_path

    assert extract_season_episode_from_path(
        "Frieren S01/01 [VOSTFR] [BDRip 1080p].mkv"
    ) == (1, 1)
    assert extract_season_episode_from_path("Frieren S02/12.mkv") == (2, 12)
    # Tech numbers deeper in the name never become episodes.
    assert extract_season_episode_from_path("BDRip 1080p.mkv") == (None, None)
    assert extract_season_episode_from_path("Movie 2001.mkv") == (None, None)


async def test_post_metadata_pass_binds_auto_assignments_to_single_series(
    db_session, sample_channel,
):
    """Torrent rows are created before metadata; the post-link pass closes it."""
    import uuid

    from app.models.file_resource import FileResource
    from app.models.resource_file_assignment import ResourceFileAssignment
    from app.models.series import TVSeries
    from app.services.batch_content_analysis import bind_single_work_assignments

    series = TVSeries(id=str(uuid.uuid4()), title_cn="葬送的芙莉莲")
    resource = FileResource(
        id=str(uuid.uuid4()), channel_id=sample_channel.id, guid=str(uuid.uuid4()),
        title_raw="Frieren S01+S02", torrent_url="https://x/f.torrent",
        is_batch=True, batch_scope="multi_season", series_id=series.id,
    )
    assignment = ResourceFileAssignment(
        resource_id=resource.id, file_path="S01/Frieren.S01E01.mkv",
        season=1, episode_start=1, episode_end=1, source="auto",
    )
    db_session.add_all([series, resource, assignment])
    await db_session.commit()

    assert await bind_single_work_assignments(db_session, resource) == 1
    await db_session.commit()
    await db_session.refresh(assignment)
    assert assignment.series_id == series.id
    assert assignment.movie_id is None


async def test_post_metadata_pass_backfills_season_on_bound_auto_assignment(
    db_session, sample_channel,
):
    """A previously bound auto row still receives the resource season."""
    import uuid

    from app.models.file_resource import FileResource
    from app.models.resource_file_assignment import ResourceFileAssignment
    from app.models.series import TVSeries
    from app.services.batch_content_analysis import bind_single_work_assignments

    series = TVSeries(id=str(uuid.uuid4()), title_cn="测试剧集")
    resource = FileResource(
        id=str(uuid.uuid4()), channel_id=sample_channel.id, guid=str(uuid.uuid4()),
        title_raw="测试剧集 - 08", torrent_url="https://x/test.torrent",
        season=1, is_batch=False, series_id=series.id,
    )
    assignment = ResourceFileAssignment(
        resource_id=resource.id, series_id=series.id,
        file_path="测试剧集 - 08.mkv", season=None,
        episode_start=8, episode_end=8, source="auto",
    )
    db_session.add_all([series, resource, assignment])
    await db_session.commit()

    assert await bind_single_work_assignments(db_session, resource) == 0
    await db_session.commit()
    await db_session.refresh(assignment)
    assert assignment.season == 1


async def test_fractional_release_episode_maps_to_specials_season(
    db_session, sample_channel,
):
    import uuid

    from app.models.file_resource import FileResource
    from app.models.resource_file_assignment import ResourceFileAssignment
    from app.models.series import TVSeries
    from app.services.batch_content_analysis import bind_single_work_assignments

    series = TVSeries(id=str(uuid.uuid4()), title_cn="冰菓")
    resource = FileResource(
        id=str(uuid.uuid4()), channel_id=sample_channel.id, guid=str(uuid.uuid4()),
        title_raw="冰菓 TV+OVA", torrent_url="https://x/hyouka.torrent",
        is_batch=True, batch_scope="season", series_id=series.id,
    )
    assignment = ResourceFileAssignment(
        resource_id=resource.id,
        file_path="TV 2012/Hyouka. TV (2012) 11.5; BD_1080P.mkv",
        source="auto",
    )
    db_session.add_all([series, resource, assignment])
    await db_session.commit()

    assert await bind_single_work_assignments(db_session, resource) == 1
    await db_session.commit()
    await db_session.refresh(assignment)
    assert (assignment.season, assignment.episode_start, assignment.episode_end) == (0, 1, 1)


def test_normalize_fields_subtitle_group_and_bare_resolution_fallbacks():
    from app.services.resource_parser import (
        extract_subtitle_group_from_filename,
        normalize_parsed_fields,
    )

    out = normalize_parsed_fields(
        "[Xspitfire911] 葬送的芙莉莲/Sousou No Frieren S01 + S02 BDRIP 1080p X265 10bit VOSTFR",
        {},
    )
    assert out["subtitle_group"] == "Xspitfire911"
    assert out["resolution"] == "1080p"
    assert out["source"] == "BDRip" or out["source"] == "BDRIP"
    # Tech values preserve the casing found in the title ("X265").
    assert (out["video_codec"] or "").lower() == "x265"
    # Pure-number leading brackets are years, not groups.
    year_out = normalize_parsed_fields("[2020] Some Movie.mkv", {})
    assert year_out.get("subtitle_group") != "2020"
    assert extract_subtitle_group_from_filename(
        "I.Became.a.Legend.S01E09.1080p.CR.WEB-DL.AAC2.0.H.264-VARYG.mkv"
    ) == "VARYG"
    assert extract_subtitle_group_from_filename("Some.Show.S01E01-x265.mkv") is None


def test_apply_auto_assignments_and_season_ranges():
    from types import SimpleNamespace

    import app.services.batch_content_analysis as bca

    class FakeCollection(list):
        pass

    resource = SimpleNamespace(
        id="r1", file_assignments=FakeCollection(), season_ranges=None,
        batch_scope=None, subtitle_group=None,
    )
    report = ti.analyze_torrent_files(_frieren_listing())
    bca.apply_auto_assignments(resource, report)

    assignments = list(resource.file_assignments)
    assert len(assignments) == 40
    first = assignments[0]
    assert first.file_path.startswith("Frieren S01/")
    assert first.season == 1 and first.episode_start == 1
    assert first.source == "auto"
    assert first.work_title_hint == "Frieren"

    ranges = bca.compute_season_ranges(resource)
    assert {"season": 1, "episode_start": 1, "episode_end": 28} in ranges
    assert {"season": 2, "episode_start": 1, "episode_end": 12} in ranges


def test_apply_auto_assignments_fills_unambiguous_filename_subtitle_group():
    from types import SimpleNamespace

    import app.services.batch_content_analysis as bca

    report = ti.analyze_torrent_files([{
        "name": (
            "I.Became.a.Legend.after.My.10.Year.Long.Last.Stand.S01E09."
            "1080p.CR.WEB-DL.AAC2.0.H.264-VARYG.mkv"
        ),
        "size": 1_400_000_000,
    }])
    resource = SimpleNamespace(
        id="r-varyg", file_assignments=[], subtitle_group=None,
    )

    bca.apply_auto_assignments(resource, report)

    assert resource.subtitle_group == "VARYG"


def test_llm_single_episode_and_multi_episode_range_are_normalized():
    import app.services.batch_content_analysis as bca

    data = {
        "works": [{
            "title": "Frieren",
            "content_type": "tv",
            "files": [
                {"path": "S01E01.mkv", "season": 1, "episode": 1,
                 "episode_start": None, "episode_end": None},
                {"path": "S01E02-E03.mkv", "season": 1, "episode": None,
                 "episode_start": 2, "episode_end": 3},
                {"path": "broken.mkv", "season": 1, "episode": None,
                 "episode_start": 4, "episode_end": None},
            ],
        }],
    }

    works = bca._valid_paths(
        data, {"S01E01.mkv", "S01E02-E03.mkv", "broken.mkv"},
    )
    files = works[0]["files"]
    assert (files[0]["episode_start"], files[0]["episode_end"]) == (1, 1)
    assert (files[1]["episode_start"], files[1]["episode_end"]) == (2, 3)
    assert (files[2]["episode_start"], files[2]["episode_end"]) == (None, None)


def test_llm_candidate_key_is_server_validated():
    import app.services.batch_content_analysis as bca

    candidates = [{
        "candidate_key": "series:known", "work_type": "series", "work_id": "known",
        "titles": ["〈古典部〉シリーズ", "Hyouka"],
    }]
    valid = bca._valid_paths({"works": [{
        "candidate_key": "series:known", "title": "Hyouka", "content_type": "tv",
        "files": [{"path": "01.mkv", "season": 1, "episode": 1}],
    }]}, {"01.mkv"}, candidates)
    assert valid[0]["candidate_key"] == "series:known"
    assert valid[0]["content_type"] == "tv"

    invented = bca._valid_paths({"works": [{
        "candidate_key": "series:invented", "title": "Hyouka", "content_type": "tv",
        "files": [{"path": "01.mkv", "season": 1, "episode": 1}],
    }]}, {"01.mkv"}, candidates)
    assert invented == []


# =============================================================================
# C2 — mixed franchise packs still build their collection after LLM movie binding
# =============================================================================


async def test_inspect_mixed_pack_still_links_franchise_after_llm_movies(monkeypatch):
    """C2: LLM refinement binding movies must NOT skip link_franchise_pack
    for a MIXED pack (TV clusters remain)."""
    import app.services.batch_content_analysis as bca
    import app.services.franchise_service as fs_mod

    linked = []

    async def _fake_link(db, resource, report, channel):
        linked.append(resource)

    async def _fake_refine(db, resource, report, channel):
        return True  # LLM bound movie rows

    monkeypatch.setattr(fs_mod, "link_franchise_pack", _fake_link)
    monkeypatch.setattr(bca, "llm_refinement_needed", lambda *a, **k: True)
    monkeypatch.setattr(bca, "refine_batch_content", _fake_refine)
    _stub_pipeline(monkeypatch, [
        _f("作品X TV/作品X S01E01.mkv"),
        _f("作品X TV/作品X S01E02.mkv"),
        _f("作品X 剧场版/作品X Movie.mkv"),
    ])
    r = _resource(file_assignments=[])
    channel = SimpleNamespace(id="ch-1", metadata_source="wikipedia")
    assert await maybe_inspect_torrent(None, r, channel) is True
    assert r.batch_scope == "franchise"
    assert linked == [r]


async def test_inspect_pure_movie_pack_still_skips_franchise_link(monkeypatch):
    """C2: a pure-movie pack (scope upgraded to "movies" by refinement)
    keeps the no-collection behavior."""
    import app.services.batch_content_analysis as bca
    import app.services.franchise_service as fs_mod

    linked = []

    async def _fake_link(db, resource, report, channel):
        linked.append(resource)

    async def _fake_refine(db, resource, report, channel):
        resource.batch_scope = "movies"  # refine's own pure-movie upgrade
        return True

    monkeypatch.setattr(fs_mod, "link_franchise_pack", _fake_link)
    monkeypatch.setattr(bca, "llm_refinement_needed", lambda *a, **k: True)
    monkeypatch.setattr(bca, "refine_batch_content", _fake_refine)
    _stub_pipeline(monkeypatch, [
        _f("作品X Movie A/作品X Movie A.mkv"),
        _f("作品X Movie B/作品X Movie B.mkv"),
    ])
    r = _resource(file_assignments=[])
    assert await maybe_inspect_torrent(None, r, SimpleNamespace(id="ch-1")) is True
    assert r.batch_scope == "movies"
    assert linked == []
