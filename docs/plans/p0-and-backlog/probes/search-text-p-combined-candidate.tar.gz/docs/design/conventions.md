# 其他约定

- **资源出站 HTTP**：外部资源派生的 torrent/poster 默认仅访问公网 HTTP(S)，实际建连时校验并固定 DNS 地址，重定向每跳重验，不使用环境代理绕过此边界。RSS URL 与磁力缓存镜像是管理员指定的初始 origin，可访问其内网服务；该授权仅覆盖相同 scheme/host/port，不继承给其他私网重定向目标。RSS 不再接受文件路径或 file URI，离线夹具须通过本地 HTTP 服务回放。Basic auth 仅用于管理员初始端点，同源重定向保留、跨源不转发；镜像响应仍必须通过 infohash 校验。

- **出站私网例外**：`OUTBOUND_PRIVATE_ORIGINS` 为 JSON 字符串数组，默认 `[]`；只接受完整 HTTP(S) origin，例如 `["https://assets.internal:8443"]`，禁止通配、用户信息、路径、查询或片段。显式默认端口归一化并去重。例外只匹配 scheme/host/port；不同端口和重定向目标须各自获授权。该部署配置影响受控资源及 LLM 客户端，不能作为不可信请求参数开放。
- **受控连接兼容性**：RSS、镜像、torrent/poster、Wiki REST summary 与 OpenAI/OpenRouter/LangChain 客户端禁用环境代理，避免代理侧解析绕过目的地检查；保留系统 CA 及 OpenSSL 的 `SSL_CERT_FILE`/`SSL_CERT_DIR`。同步/异步 DNS 共用最多 4 个解析线程与 8 个未完成查询；超时返回后系统查询仍占槽直至结束，不累积无界线程。HTTPX/httpcore 固定为已验证的 0.28.1/1.0.9，升级需重验 transport 适配、DNS、重定向与 TLS 矩阵。
- **LLM 与 RPC 端点**：管理员配置的 LLM 初始 origin 允许私网访问，普通和流式 SDK 请求使用相同目的地策略。短生命周期 SDK 使用上下文释放连接；MetadataAgent 模型使用零空闲连接池，允许配置重置前的在途请求结束。Transmission 只允许同源重定向，保留 409 session-id 协商；HTTP 跳 HTTPS 时须直接配置最终 HTTPS 地址。

- **RPC/LLM 目的地**：Transmission RPC 保留配置 origin 内重定向和 409 session-id 协商，拒绝跨 origin 转交 RPC（包括 HTTP→HTTPS，需直接配置最终 HTTPS 地址），避免向新服务转发 RPC 数据。RSS 分析的 OpenAI 普通/流式调用使用相同受控异步 HTTP 层，管理员 LLM 初始 origin 可为内网，后续跳转不扩大私网授权；调用完成或失败均关闭 SDK 客户端。

- **时间格式**：API 中所有时间均为 ISO 8601 UTC 字符串（如 `2025-01-01T12:00:00Z`）。 数据库存储沿用 naive UTC。统一响应/SSE 编码在 datetime 仍有类型时转成 UTC 并输出 Z，保留微秒；date 保持 YYYY-MM-DD，null 保持空值。任意业务字符串与既有冻结快照不猜测、不批量改写。通知重试/重新生成的 since、Agent 手动运行的 scan_since 与 RSS 发布时间含偏移时先转换 UTC 再去掉 tzinfo；无偏移输入按 UTC 解释。若 UTC 归一化超出 datetime 可表示范围，请求校验返回 422；RSS 按现有无效日期策略回退，不裁剪成边界值。
- **下载目录格式**：
  - `DownloaderInstance.download_dir` 必填，必须是 Transmission 下载服务器 OS 可识别的绝对路径；路径语义以 Transmission daemon 为准，而不是 RSSRipple 后端进程所在主机为准。
  - 支持 POSIX absolute path、Windows drive absolute path、daemon 支持的 UNC path；后端校验时需要按路径风格识别根目录。
  - `Agent.download_subdir` 可空；非空时必须是相对路径，禁止以 `/`、`\`、`~`、Windows drive prefix（如 `C:\`）、UNC prefix（如 `\\server\share`）开头，禁止 `..` 段和控制字符。
  - 子目录 API 表达推荐使用 `/` 分隔；后端根据 Downloader 根目录风格拼接，标准化后必须保证最终路径仍在 `DownloaderInstance.download_dir` 下。
  - `DownloadTask.download_dir` 保存创建任务时解析出的最终绝对路径；任务重试沿用该字段。
  - **卷绑定（R1）**：daemon 视角与本进程视角的路径差异由 `DownloaderInstance.volume_id` + `volume_subpath`（→ `StorageVolume.mount_path`，见 file-organization.md「统一路径解析：逻辑存储卷」）结构化消解，使用处经 `app/services/volume_service.resolve_downloader_path` 动态解析；两者皆 null = 两视角一致（恒等）。P1 的 `DownloaderInstance.path_map` 自由文本前缀字典已废弃（列保留为惰性孤儿，代码不再读取）。
  - 前端下载器表单的默认下载目录预填值为 `/downloads/complete`（新建表单初始值；编辑表单在已存值为空时回填；mock 类型除外，用 `/tmp/mock-downloads`）。
- **Transmission 目录 RPC 使用**：RSSRipple 不调用 `session_set(download_dir=...)` 修改 Transmission 全局默认目录；所有自动下载都通过 `torrent_add(..., download_dir=DownloadTask.download_dir)` 设置单个任务目录。
- **配置项**（环境变量，完整列表）：
  - `DATABASE_URL`：SQLAlchemy 数据库 URL（默认 `sqlite+aioturso:///data/rss_ripple_turso.db`）。支持两种后端：
    - `sqlite+aioturso:///`（默认）：嵌入式 Turso 引擎（SQLite 文件格式兼容）。启用 MVCC 并发写：`journal_mode='mvcc'` 为文件级持久属性（由 `create_tables` 或 `scripts/migrate_to_turso.py` 设置），连接级通过 URL 自动附加 `isolation_level=CONCURRENT`（隐式事务发 `BEGIN CONCURRENT`）。写-写冲突报 `Write-write conflict`，由统一的锁/冲突重试设施处理。旧 SQLite 库用 `uv run python scripts/migrate_to_turso.py --source <old.db> --target <new.db>` 迁移（备份复制 → 删除 FTS5 对象 → 开启 MVCC → 校验）。**单进程锁定**：同一 Turso 文件同时只允许一个进程打开（其实验性 `multiprocess_wal` 与 MVCC 不兼容），因此 app 与 eval 等并容器必须各用各的库文件；需要多实例共享数据库时用 PostgreSQL。**全文检索**：双后端统一基于作品表的 `search_text` 列（`title_cn`+`title_en`+`original_title`+`aliases` 过 `normalize_title` 的归一化拼接，由 ORM `before_flush` 钩子同事务维护，启动时空值回填）。Turso 走原生 FTS（`USING fts` 索引，Tantivy/ngram）且与 MVCC 互斥，因此影子表放独立边车数据库（`<主库名>_fts.db`，WAL 模式，`experimental_features=index_method`），索引仅缓存规范化标题、可随时从基表重建（`app/services/fts.py`），启动时若为空自动回填；同步机制：ORM 钩子在作品行同一事务写入 `fts_outbox`（upsert/delete）→ `search_*_fts` **读前以独立事务 drain 已提交 outbox**（失败不提交或回滚搜索调用方事务；幂等全量写，保证"提交即可搜到"的 read-your-writes 一致性，手动 link 后立即搜索成立）→ 每 30 秒 `_drain_fts_outbox` 任务定向投递边车（批量化兜底，覆盖非 API/脚本写入）→ 每小时 `_reconcile_fts` 全量对账兜底（绕过 outbox 的路径；drain/对账两个周期任务仅 Turso 后端注册，PostgreSQL 无边车不调度）。ngram 对单字符查询不产出 token，`search_*_fts` 对归一化后 <2 字符的查询回退 Python 扫描。
    - `postgresql+asyncpg://`：PostgreSQL（分布式部署，**现为项目默认 `docker-compose.yml`**，进程拓扑为 1 web + 3 worker，见下方 `APP_ROLE`；Turso 单节点版在 `docker-compose.standalone.yml`，单进程 `APP_ROLE=all`）。无边车；搜索直接走 `search_text` 列 + `pg_trgm` GIN 索引的子串匹配（`create_tables` 建 `CREATE EXTENSION IF NOT EXISTS pg_trgm` 与 `ix_<table>_search_text_trgm`，各步 `_best_effort` 容错：无扩展权限时回退 Python 扫描）。`_search_pg_like` **复刻 Turso ngram 分词语义**：归一化查询按空白切分，单 token（CJK/单词/单字）走 `LIKE '%tok%'` 连续子串匹配（等价 Turso 单 token 的 bigram-AND 与单字 Python 扫描回退），多 token 对 ≥2 字符 token 取 `LIKE` 的 OR（等价 Turso 的跨词 OR、`min_token_size`=2 丢弃单字 token）；LIKE 通配符（`%`/`_`/`\`）已转义避免误匹配。与 Turso 的差异：Turso 对含 `:`/`'`/`[`/`(`/`^`/`"` 等查询会抛 FTS 解析错误返回空（PostgreSQL 正确处理），且 Turso 的 bigram 可能在英文上产生零散 bigram 假阳性（如 `tensei` 命中 `kensei`，PostgreSQL 更精确）。存量 Turso → PostgreSQL 迁移走 `uv run python scripts/migrate_to_postgres.py --source … --target …`（按 FK 依赖序逐表复制、保留 UUID/时间戳，JSON 文本→JSONB 自动转换，跳过 `fts_outbox`），对比校验走 `scripts/verify_search_parity.py`。完整迁移矩阵、Docker 部署迁移步骤与数据安全不变量见 [db-migration.md](db-migration.md)。
  - `QUEUE_BACKEND`：队列后端，`"memory"`（默认）或 `"redis"`。
  - `REDIS_URL`：可选 Redis 地址，`QUEUE_BACKEND=redis` 时必填。
  - `APP_ROLE`：进程角色，`all`（默认，单进程全功能）/ `web`（只 HTTP + 入队）/ `worker`（调度器 + 队列消费，无 HTTP，入口 `python -m app.worker`）。分布式默认栈 `docker-compose.yml` 为 1 web + 3 worker；standalone 与本地开发保持默认 `all`。
  - `LLM_API_KEY` / `LLM_BASE_URL` / `LLM_MODEL`：OpenAI 兼容 LLM，用于 feed 分析、统一 MetadataAgent、PendingDecision 建议。
  - `WIGOLO_BASE_URL`（默认 `http://flash-aio:3333`）/ `WIGOLO_API_TOKEN`：自托管 wigolo 搜索守护进程——主源未命中时有序网络搜索回退的唯一对接；非回环绑定的 daemon 需配置 Bearer token。
  - `TMDB_API_KEY`：TMDB 数据源（可选）。
  - `BANGUMI_API_KEY`：Bangumi 数据源与 is_anime 第一层验证（可选；token 即启用，无独立开关，亦可在设置页覆盖配置）。
  - `BANGUMI_API_BASE`：Bangumi API 基础地址（默认 `https://api.bgm.tv/v0`）；可指向自建镜像或集成测试的 mock 服务。
  - `WEB_FALLBACK_ENABLED` / `TMDB_ENABLED` / `WIKIPEDIA_ENABLED`：来源启用开关；`WEB_FALLBACK_ENABLED` 只控制受可信站点约束的 Wigolo 网络搜索回退。
  - `ORGANIZE_LOCK_DIR`：整理所有权锁目录，默认 `data/organize-locks`；Web 和所有 worker 必须共享原目录及文件锁 inode。默认单宿主 Compose 的 app-data 卷可用；禁止运行中清理、复制或替换，跨宿主/未经验证的远程 flock 不受支持。目录身份与 DB 注册不符时拒绝操作。
  - `POSTER_CACHE_DIR`：海报缓存目录，挂载到 `/posters`（默认 `./data/posters`）。
  - `TORRENT_CACHE_DIR`：通道 A 下载缓存的 .torrent 文件目录（默认 `./data/torrents`）。B4 候选 HTTP 新缓存使用 `<resource_id>-<sha256(content)>.torrent`，同目录唯一临时文件完整写入后原子发布；magnet 使用独立 attempt 路径。旧路径仍可读取。写盘前必须完成 bencode/info 清单校验，已有缓存读取前同样校验，HTML/损坏等无效缓存会删除并允许重新获取；`FileResource.torrent_file` 记有效路径，任务创建时本地推送字节。
  - `MAGNET_RESOLVE_ENABLED`（默认 `true`）/ `MAGNET_RESOLVE_TIMEOUT_SECONDS`（默认 `900`）/ `MAGNET_RESOLVE_CONCURRENCY`（默认 `4`）/ `MAGNET_RESOLVE_MAX_ATTEMPTS`（默认 `1`，首次失败后的自动重试次数，手动重试不限）：magnet 元数据解析（libtorrent 仅取元数据重建 .torrent 进同一缓存目录，状态落 `FileResource.magnet_resolve_*` 列）。`MAGNET_RESOLVE_DEFAULT_TRACKERS`（JSON 字符串列表）：注入每次解析尝试的默认公共 tracker（TPB 等抓取的 magnet 无 `tr=` 参数，否则只靠 DHT）；默认清单以 `http://tracker.opentrackr.org:1337/announce` 打头（tier 0 优先尝试）——DHT 与 udp:// tracker 均需 UDP 出网（防火墙常封），http 形式走 TCP，UDP 被封锁的部署也能解析。`MAGNET_RESOLVE_CACHE_MIRRORS`（JSON 字符串列表，默认 `["https://itorrents.org/torrent/{infohash}.torrent"]`，空列表关闭）：infohash 缓存镜像快速路径——按 `{infohash}` 模板（小写 40 位十六进制 v1 SHA-1）HTTPS GET 缓存的 .torrent，秒级解析；**镜像对未知 hash 会 200 返回无关 torrent，响应使用前一律重算 v1 infohash 比对**。
  - `DEFAULT_FETCH_INTERVAL`：频道默认抓取间隔（秒，默认 `1800`）。
  - `TRANSMISSION_TIMEOUT`：Transmission RPC 超时。
  - `MAX_RETRY_COUNT`：失败下载最大重试次数（默认 `3`）。
  - `TASK_EXPIRE_DAYS`：已完成任务自动清理天数（默认 `30`）。
  - `DEV_MODE`：为 `true` 时内部错误响应含堆栈（默认 `false`）。
  - `NOTIFY_ENABLED`：下载完成通知总开关/熔断（默认 `true`）。webhook 按 Agent 在 UI 多注册（Agent 详情 → 通知记录 Tab）；投递为纯出站（无回调 token，无消费者回调端点），单次 POST 超时 180s（代码常量）。
  - `NOTIFY_MAX_ATTEMPTS`（默认 `5`）/ `NOTIFY_RETRY_BASE_SECONDS`（默认 `30`）：webhook delivery 退避策略，`base * 2^attempt` 封顶 30 分钟，超限该 delivery 转 `failed`（界面可重试）。
  - `NOTIFY_RETENTION_DAYS`：通知（及其 delivery，级联删除）的保留天数（默认 `30`）。
  - 内置文件整理子系统（organize）**无环境变量开关**：常开，存在 enabled 规则即激活。语义见 file-organization.md；逻辑卷/媒体服务器/库根/规则/模板全部入库（StorageVolume/MediaServerInstance/Library/OrganizeRule），不走环境变量。媒体服务器**无全局配置**：旧版 `PLEX_URL`/`PLEX_TOKEN` 已移除，存量环境变量由启动轻迁移转为一条 `MediaServerInstance`（type=plex）。
  - `AUTH_ENABLED`：应用认证总开关（默认 `true`）。开启时 `/api/v1/*` 与 `/posters/*` 需携带凭证，`/api/v1/auth/*`、`/health`（容器健康检查探针）与 SPA/静态资源开放。
  - `API_KEY`：可选静态引导 API key（运维恢复与集成测试用；与 `api_keys` 表中的 key 同等效力）。
- **认证凭证约定**：Web 端 TOTP 登录（秘钥 `auth_totp_secret` 首次启动自动生成并持久化于 `app_settings`，启动日志不输出秘钥或 provisioning URI，运维通过下述终端命令主动绑定认证器）；登录成功签发 HttpOnly Cookie `rssripple_auth`（值格式 `{expiry_ts}.{hmac_sha256}`，以 `app_settings` 的 `auth_cookie_secret` 签名，30 天有效，SameSite=Lax）。程序端用全局 API key（`Authorization: Bearer` 或 `X-API-Key` 头；`api_keys` 表仅存 SHA-256 摘要，`rr_` 明文仅创建时返回一次）。

### 认证器绑定

应用至少成功启动一次后，在应用虚拟环境的可信交互终端显式执行 `python -m app.scripts.auth_enrollment --show`。默认 PostgreSQL Compose 可执行 `docker compose exec app uv run --no-project python -m app.scripts.auth_enrollment --show`，通过与容器服务相同的 uv 启动方式选择已安装依赖。命令使用应用相同的 DATABASE_URL，只读取已有 TOTP 密钥；不执行 DDL、不创建/轮换密钥、不使现有 Cookie 失效。未初始化、数据库不可访问或输出不是终端时返回非零，标准输出为空；省略 `--show` 也拒绝显示。数据库异常只给固定提示，避免泄露连接凭证。

Turso 文件由单一进程独占：先 `docker compose -f docker-compose.standalone.yml stop app`，再 `docker compose -f docker-compose.standalone.yml run --rm --no-deps app uv run --no-project python -m app.scripts.auth_enrollment --show`，最后 `docker compose -f docker-compose.standalone.yml start app`。本地开发同样先停止 Uvicorn，再用相同环境执行 `uv run python -m app.scripts.auth_enrollment --show`，之后重启应用。不要用第二个进程打开运行中的 Turso 文件。

URI 包含管理员长期密钥，只用于手动导入认证器，不转发到日志系统或共享终端录制。此改动停止今后的自动日志暴露，不自动轮换旧密钥或清除历史日志；已有泄露需由运维另行处理。
  - `DEBUG` / `LOG_LEVEL`（默认 `INFO`）：调试开关与日志级别。
  - Wikipedia Search 通过免费 `wikipedia` Python 库实现，无需额外 API key。
- **海报服务**：FastAPI 挂载 StaticFiles 到 `/posters`，物理目录为 `POSTER_CACHE_DIR`。缓存文件名 `{sha256(url)[:16]}.{ext}`，扩展名由下载内容的魔数嗅探决定（jpg/png/webp/gif/svg，`download_and_cache_poster` 内 `_sniff_image_ext`），**不取 URL 后缀**——URL 后缀不可靠（如 Wikimedia 在无扩展路径下返回 SVG），内容与扩展名不符会被浏览器按静态 MIME 拒绝渲染；无法识别的内容不缓存、返回 None。
- **日志**：结构化 JSON 日志，含 `request_id`、`channel_id`、`agent_id`、`task_id` 等上下文字段。
- **幂等性**：Channel 抓取以 guid 去重；手动触发的 run/fetch 以分布式锁保证同一资源不会重复入队；Transmission add_torrent 以 torrent 哈希幂等（RPC 本身支持）。

---

Turso 兼容层遇到写锁/写写冲突时淘汰该物理连接，避免 SAVEPOINT 失败后的旧读取快照进入连接池；原异常仍传播，由事务边界 rollback 和既有策略决定重试，不自动重放任意语句。

运行配置刷新：load_runtime_config 在完整读取 app_settings 成功后才以无 await 的连续更新替换进程内配置，数据库等待或读取失败期间保留上一份有效值；禁止先清空覆盖项再等待数据库，否则并发请求会短暂退回环境默认模型/凭据。该约束不等同于跨进程实时同步，也不解决旧事务快照的顺序问题。

### OTP 限流与代理来源

OTP 额度由数据库共享并跨 web 进程持久化，适用于 PostgreSQL 分布式及 Turso 单进程部署。来源使用 ASGI request.client.host；应用不解析请求自带 X-Forwarded-For。反向代理部署必须把服务器 forwarded-allow-ips 限定为可信代理地址，禁止允许任意客户端；若服务器不接受代理来源，代理后的请求会共享来源额度。全局 30 次/60 秒是轮换来源的后盾，每来源 5 次/60 秒。全局上限可被主动请求耗尽，属于单管理员登录的可用性权衡；已登录会话和 API key 不消耗此额度。验证码、密钥不写入额度表。

Turso 按其单进程独占契约，在同一引擎内串行额度短事务，避免认证突发相互争写全局桶；此锁不是内存限流计数器。额度、窗口与重启后的拒绝状态仍由数据库保存，PostgreSQL 的跨进程预算不依赖本地锁。

### 浏览器跨域来源

`CORS_ALLOWED_ORIGINS` 为 JSON 精确 HTTP(S) origin 列表，默认 `[]`，同源 SPA 不需配置。例如 `["https://ui.example.com"]` 允许该前端读取 API 响应。禁止通配、null、凭证、非根路径、query/fragment 和控制字符；默认端口规范化，配置非法则启动失败。它与 `OUTBOUND_PRIVATE_ORIGINS` 的服务端出站例外无关。

允许来源的预检不要求登录，实际请求仍验证 Cookie/API key。CORS 包裹完整认证、重试和错误处理栈，包含 401 及未捕获 500。未允许来源不返回 Allow-Origin；这不是阻止请求执行的 CSRF 校验。登录 Cookie 仍为 SameSite=Lax，配置跨域白名单不会自动使跨站 Cookie 可用。

### 浏览器状态变更来源防护

对 `/api/v1/` 的非 GET/HEAD/OPTIONS 请求，在认证和业务副作用前核验来源：Origin 必须为当前请求同源或 `CORS_ALLOWED_ORIGINS` 精确白名单；拒绝 null、非法或重复 Origin。没有 Origin 时核验 Referer 的 origin；两者皆无时拒绝 Sec-Fetch-Site 明确 cross-site/same-site。完全没有浏览器来源信息的程序端调用保持兼容；来源可信不能代替认证。显式 API-key 头不会绕过不可信来源限制，避免伪造空头使 Cookie 保护失效。

拒绝返回 403 `FORBIDDEN`、统一响应结构，不执行登录/退出或业务写入，不发送清 Cookie 头。CORS 仍决定浏览器是否可读该响应；不可信来源一般只能观察 fetch 失败。反向代理需正确传递并由受信代理配置还原外部 scheme/Host；不得把任意外部 Forwarded 头直接当可信 origin。

来源防护对 Origin 和备用 Referer 均要求单值，重复来源头按 403 拒绝。

### 海报缓存的完整写入与恢复

海报缓存的文件名与内容嗅探策略保持不变。下载、目录/文件读写和缓存校验都在线程中执行。新文件先写同目录独占暂存文件并 flush/fsync，再原子替换最终图片；同时发布隐藏的完整性收据 `.{filename}.json`（version=1、字节数及 SHA-256，不保存原始 URL 或凭证）。只有收据与打开文件的长度/哈希一致才算缓存命中。此校验证明收到的 HTTP 响应字节被完整保存，不代表完整图片解码或内容安全审核。

没有收据的旧缓存、收据损坏/缺失或文件长度/哈希不符都需要重新下载；新内容成功发布前保留旧文件。网络/磁盘失败返回 None，不能把残缺文件作为新成功返回。图片与收据间退出只会导致下一次缓存未命中，最终图片路径不会暴露本次半写内容。已有 `/posters/...` 本地 URL 仍按原契约直接返回；没有远端 URL 的历史本地记录需要通过元数据刷新重新获得来源，不宣称本次升级能从 URL 哈希还原来源。

普通失败只清理本次创建的暂存文件；真实进程崩溃可能遗留隐藏 `.part`，恢复时不通过通配符删除未知写入者文件。这些暂存文件不会成为缓存命中。并发发布可能使图片/收据短暂不一致，校验失败按未命中处理，不能降低为仅检查存在。

暂存使用 O_CREAT|O_EXCL 独占创建，新文件权限遵循进程 umask；替换既有普通文件时保留其权限，不让原子发布意外扩大访问范围或导致 web/worker 间可读性回归。图片和收据都遵守该规则。

Turso 驱动固定为 `pyturso==0.8.2`。由旧驱动升级时，原生 FTS 派生索引采用实际查询探测及事务重建；业务主库数据不参与索引重建，非格式错误和重建失败不得忽略。详见 [数据库迁移](db-migration.md#turso-原生-fts-索引格式升级)。
