"""Channel API routes."""

import json
import logging
from collections import Counter

from fastapi import APIRouter, Depends, Header, Query
from fastapi.responses import JSONResponse, StreamingResponse
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.clients.rss_parser import get_raw_entries, validate_rss_url
from app.database import get_db
from app.models.channel import Channel
from app.schemas.channel import (
    ChannelCreate,
    ChannelResponse,
    ChannelUpdate,
    PreviewFeedRequest,
    SummarizeFiltersRequest,
    ValidateURLRequest,
)
from app.schemas.common import api_json, paginated_response, success_response
from app.services.feed_analyzer import analyze_feed, analyze_feed_stream

logger = logging.getLogger(__name__)

router = APIRouter()


def _not_found(message: str = "Channel not found"):
    return JSONResponse(
        status_code=404,
        content={"success": False, "data": None, "error": {"code": "NOT_FOUND", "message": message}, "meta": {}},
    )


def _already_running(existing_job: dict | None = None):
    return JSONResponse(
        status_code=409,
        content={
            "success": False,
            "data": existing_job,
            "error": {"code": "ALREADY_RUNNING", "message": "A job is already running for this channel"},
            "meta": {},
        },
    )


def _valid_field_mapping(mapping: dict | None) -> bool:
    if not isinstance(mapping, dict):
        return False
    field_mappings = mapping.get("field_mappings")
    if isinstance(field_mappings, dict):
        return len(field_mappings) > 0
    return any(isinstance(v, dict) and v.get("source") for v in mapping.values())


@router.get("/channels")
async def list_channels(
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
):
    from app.models.agent import Agent
    from app.models.file_resource import FileResource
    offset = (page - 1) * page_size
    total_q = await db.execute(select(func.count()).select_from(Channel))
    total = total_q.scalar_one()
    result = await db.execute(
        select(Channel).order_by(Channel.created_at.desc()).offset(offset).limit(page_size)
    )
    channels = result.scalars().all()
    channel_ids = [channel.id for channel in channels]
    agent_counts = {}
    resource_counts = {}
    if channel_ids:
        agent_counts = dict((await db.execute(
            select(Agent.channel_id, func.count()).where(Agent.channel_id.in_(channel_ids))
            .group_by(Agent.channel_id)
        )).all())
        resource_counts = dict((await db.execute(
            select(FileResource.channel_id, func.count()).where(FileResource.channel_id.in_(channel_ids))
            .group_by(FileResource.channel_id)
        )).all())
    items = []
    for c in channels:
        d = ChannelResponse.model_validate(c).model_dump()
        d["agent_count"] = agent_counts.get(c.id, 0)
        d["resource_count"] = resource_counts.get(c.id, 0)
        items.append(d)
    return paginated_response(items, total=total, page=page, page_size=page_size)


@router.post("/channels", status_code=201)
async def create_channel(
    body: ChannelCreate,
    db: AsyncSession = Depends(get_db),
    x_form_token: str | None = Header(default=None),
):
    if not _valid_field_mapping(body.field_mapping):
        return JSONResponse(status_code=422, content={
            "success": False,
            "data": None,
            "error": {"code": "VALIDATION_ERROR", "message": "field_mapping is required"},
            "meta": {},
        })

    if x_form_token is not None:
        from app.services.submission_guard import submission_guard
        if not await submission_guard.consume(x_form_token):
            return JSONResponse(status_code=409, content={
                "success": False, "data": None,
                "error": {"code": "DUPLICATE_SUBMISSION", "message": "This form was already submitted."},
                "meta": {},
            })

    try:
        is_valid, feed_msg, item_count, downloadable_count = await validate_rss_url(body.url)
    except Exception:
        logger.error("validate_rss_url failed for url=%s", body.url, exc_info=True)
        raise

    if not is_valid:
        return JSONResponse(status_code=422, content={
            "success": False, "data": None,
            "error": {"code": "INVALID_FEED", "message": feed_msg}, "meta": {},
        })

    channel = Channel(**body.model_dump())
    db.add(channel)
    await db.flush()
    await db.refresh(channel)

    # Commit before another process can consume the initial fetch. Periodic
    # jobs are reconciled from this committed state by each worker.
    await db.commit()
    await db.refresh(channel)

    # Auto-trigger an initial fetch so the new channel starts pulling data
    # immediately instead of waiting for the first scheduler tick. Fire-and-
    # forget: a failure here must not fail the create. Skip auto-trigger when
    # the scheduler is disabled (e.g. integration tests) so tests have explicit
    # control over fetch timing.
    from app.config import settings

    fetch_triggered = False
    if settings.scheduler_enabled and channel.status != "inactive":
        try:
            from app.services.task_queue import task_queue
            job = await task_queue.enqueue(
                "fetch_channel", f"channel:{channel.id}", {"channel_id": channel.id, "scheduled": True}
            )
            fetch_triggered = job is not None
        except Exception:
            logger.warning(
                "Failed to enqueue initial fetch for channel %s", channel.id, exc_info=True
            )

    return success_response(
        ChannelResponse.model_validate(channel).model_dump(),
        meta={
            "feed_items": item_count,
            "downloadable": downloadable_count,
            "fetch_triggered": fetch_triggered,
        },
    )


@router.get("/channels/form-token")
async def get_form_token():
    from app.services.submission_guard import submission_guard
    return success_response({"token": await submission_guard.issue()})


@router.get("/channels/metadata-sources")
async def list_metadata_sources():
    """Return the metadata source catalog for the channel form.

    Channel config is restricted to the two-source architecture
    (wikipedia/tmdb). Each source carries ``enabled``/``configured``/
    ``available`` flags; the form should offer only ``available`` sources.
    """
    from app.services.metadata_agent import (
        DEFAULT_METADATA_SOURCE,
        get_metadata_source_catalog,
    )
    return success_response({
        "sources": get_metadata_source_catalog(channel_only=True),
        "default": DEFAULT_METADATA_SOURCE,
    })


@router.get("/channels/required-field-catalog")
async def list_required_field_catalog():
    """Return the required-metadata-field catalog for the channel form dialog.

    Each entry: ``{key, section, group, dsl_fields, lock, locked,
    applies_to}``. The channel's ``required_metadata_fields`` stores a list of
    these keys; ``dsl_fields`` are the Filter DSL fields the key covers for
    agent filters (resource-level fields are always allowed). ``lock`` is the
    code-enforced requirement scope (``always`` / a row shape such as
    ``tv_single``); ``locked`` is true whenever a scope exists — locked keys
    are always present in a channel's list and can never be removed (the list
    itself is add-only after channel creation). ``applies_to`` lists the row
    shapes the field is relevant for (null = every shape). Sections order the
    dialog: work-type grouping first (base/tv/pack), then cross-cutting
    release/work categories.
    """
    from app.services.required_fields import (
        LOCKED_REQUIRED_FIELDS,
        REQUIRED_FIELD_CATALOG,
        REQUIRED_FIELD_SECTIONS,
    )

    return success_response({
        "sections": list(REQUIRED_FIELD_SECTIONS),
        "fields": [
            {
                "key": key,
                "section": entry["section"],
                "group": entry["group"],
                "dsl_fields": entry["dsl_fields"],
                "lock": entry["lock"],
                "locked": key in LOCKED_REQUIRED_FIELDS,
                "applies_to": list(entry["applies_to"]) if entry.get("applies_to") else None,
            }
            for key, entry in REQUIRED_FIELD_CATALOG.items()
        ],
    })


@router.get("/channels/{channel_id}")
async def get_channel(channel_id: str, db: AsyncSession = Depends(get_db)):
    from sqlalchemy.orm import selectinload

    from app.models.file_resource import FileResource
    from app.schemas.file_resource import FileResourceResponse
    channel = await db.get(Channel, channel_id)
    if not channel:
        return _not_found()
    base = ChannelResponse.model_validate(channel).model_dump()
    # Recent 20 resources preview
    res = await db.execute(
        select(FileResource)
        .where(FileResource.channel_id == channel_id)
        .options(
            selectinload(FileResource.series),
            selectinload(FileResource.movie),
            selectinload(FileResource.audio_work),
            selectinload(FileResource.collection),
        )
        .order_by(FileResource.published_at.desc())
        .limit(20)
    )
    recent = res.scalars().all()
    base["recent_resources"] = [
        FileResourceResponse.model_validate(r).model_dump() for r in recent
    ]
    return success_response(base)


@router.put("/channels/{channel_id}")
async def update_channel(
    channel_id: str,
    body: ChannelUpdate,
    db: AsyncSession = Depends(get_db),
    x_form_token: str | None = Header(default=None),
):
    if x_form_token is not None:
        from app.services.submission_guard import submission_guard
        if not await submission_guard.consume(x_form_token):
            return JSONResponse(status_code=409, content={
                "success": False, "data": None,
                "error": {"code": "DUPLICATE_SUBMISSION", "message": "This form was already submitted."},
                "meta": {},
            })
    channel = await db.get(Channel, channel_id)
    if not channel:
        return _not_found()
    old_metadata_source = channel.metadata_source
    update_data = body.model_dump(exclude_unset=True)
    if "field_mapping" in update_data and not _valid_field_mapping(update_data.get("field_mapping")):
        return JSONResponse(status_code=422, content={
            "success": False,
            "data": None,
            "error": {"code": "VALIDATION_ERROR", "message": "field_mapping is required"},
            "meta": {},
        })
    # default_is_anime is immutable after channel creation.
    if (
        "default_is_anime" in update_data
        and update_data["default_is_anime"] != channel.default_is_anime
    ):
        return JSONResponse(status_code=422, content={
            "success": False,
            "data": None,
            "error": {"code": "VALIDATION_ERROR",
                      "message": "default_is_anime cannot be changed after channel creation"},
            "meta": {},
        })
    # required_metadata_fields is add-only after creation: an update may add
    # new keys but never drop previously-saved ones (the locked baseline is
    # always present and can never be cleared either).
    if "required_metadata_fields" in update_data:
        old_keys = set(channel.required_metadata_fields or [])
        new_keys = set(update_data["required_metadata_fields"] or [])
        removed = sorted(old_keys - new_keys)
        if removed:
            return JSONResponse(status_code=422, content={
                "success": False,
                "data": None,
                "error": {"code": "VALIDATION_ERROR",
                          "message": (
                              "required_metadata_fields is add-only after channel creation; "
                              f"cannot remove: {', '.join(removed)}"
                          )},
                "meta": {},
            })
    for key, value in update_data.items():
        setattr(channel, key, value)
    await db.flush()

    # If the metadata source changed, clear the old source's not_found/transient
    # cooldowns on this channel's unmatched resources so the backfill reprocesses
    # them under the new source instead of waiting out NOT_FOUND_RETRY_DAYS.
    if channel.metadata_source != old_metadata_source:
        from app.services.fetch_service import reset_channel_metadata_for_source_change
        await reset_channel_metadata_for_source_change(db, channel_id)

    await db.refresh(channel)

    return success_response(ChannelResponse.model_validate(channel).model_dump())


@router.delete("/channels/{channel_id}")
async def delete_channel(channel_id: str, db: AsyncSession = Depends(get_db)):
    channel = await db.get(Channel, channel_id)
    if not channel:
        return _not_found()
    await db.delete(channel)
    return success_response({"deleted": True})


@router.post("/channels/{channel_id}/fetch")
async def fetch_channel(channel_id: str, force: bool = False, db: AsyncSession = Depends(get_db)):
    channel = await db.get(Channel, channel_id)
    if not channel:
        return _not_found()
    from app.services.task_queue import task_queue
    key = f"channel:{channel_id}"
    existing = await task_queue.status(key)
    if existing is not None and existing.get("job_type") == "fetch_channel":
        if existing.get("status") in ("queued", "running"):
            # A fetch is already in flight. Return the existing job so callers
            # can poll its status instead of getting a 409 conflict.
            return success_response(existing)
        # Existing job has finished; clear it so a fresh enqueue can start.
        await task_queue.clear(key)
    job = await task_queue.enqueue("fetch_channel", key, {"channel_id": channel_id, "force": force})
    if job is None:
        existing = await task_queue.status(key)
        return _already_running(existing)
    return success_response(job)


@router.get("/channels/{channel_id}/fetch-status")
async def get_fetch_status(channel_id: str, db: AsyncSession = Depends(get_db)):
    channel = await db.get(Channel, channel_id)
    if not channel:
        return _not_found()
    from app.services.task_queue import task_queue
    return success_response(await task_queue.status(f"channel:{channel_id}"))


@router.post("/channels/{channel_id}/cleanup-unresolved")
async def cleanup_unresolved(channel_id: str, db: AsyncSession = Depends(get_db)):
    """Manually trigger stale-unresolved-resource cleanup for a channel.

    Runs regardless of the channel's auto-cleanup toggle - that toggle only
    gates the *automatic* daily cleanup. Returns the number of deleted resources.
    """
    channel = await db.get(Channel, channel_id)
    if not channel:
        return _not_found()
    from app.services.resource_cleanup import cleanup_channel_unresolved_resources
    deleted = await cleanup_channel_unresolved_resources(db, channel_id, force=True)
    return success_response({"deleted": deleted})


@router.post("/channels/{channel_id}/analyze")
async def analyze_channel_feed(channel_id: str, db: AsyncSession = Depends(get_db)):
    channel = await db.get(Channel, channel_id)
    if not channel:
        return _not_found()
    try:
        entries = await get_raw_entries(channel.url, limit=5)
    except Exception as e:
        return JSONResponse(status_code=400, content={
            "success": False, "data": None, "error": {"code": "FETCH_ERROR", "message": str(e)}, "meta": {},
        })
    if not entries:
        return JSONResponse(status_code=400, content={
            "success": False, "data": None, "error": {"code": "EMPTY_FEED", "message": "No entries found"}, "meta": {},
        })
    return success_response(await analyze_feed(entries))


@router.post("/channels/validate-url")
async def validate_url(body: ValidateURLRequest):
    is_valid, message, item_count, downloadable_count = await validate_rss_url(body.url)
    return success_response({
        "valid": is_valid, "message": message,
        "item_count": item_count, "downloadable_count": downloadable_count,
    })


@router.post("/channels/preview-feed")
async def preview_feed(body: PreviewFeedRequest):
    try:
        entries = await get_raw_entries(body.url, limit=20)
    except Exception as e:
        return JSONResponse(status_code=400, content={
            "success": False, "data": None, "error": {"code": "FETCH_ERROR", "message": str(e)}, "meta": {},
        })
    parsed = []
    if body.field_mapping and entries:
        from app.services.resource_parser import parse_entry
        for entry in entries:
            parsed.append(parse_entry(entry, body.field_mapping))
    return success_response({"entries": entries, "parsed": parsed})


async def _stream_events(gen):
    async for event in gen:
        yield f"data: {json.dumps(api_json(event))}\n\n"


@router.post("/channels/analyze-url-stream")
async def analyze_url_stream(body: ValidateURLRequest):
    async def _gen():
        # Flush headers immediately so the client sees a live connection
        # while the (potentially slow) RSS fetch and LLM generation run.
        yield {"type": "status", "message": "fetching feed"}
        try:
            entries = await get_raw_entries(body.url, limit=5)
        except Exception as e:
            yield {"type": "error", "message": str(e)}
            return
        if not entries:
            yield {"type": "error", "message": "No entries found"}
            return
        async for event in analyze_feed_stream(entries):
            yield event

    return StreamingResponse(
        _stream_events(_gen()),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive", "X-Accel-Buffering": "no"},
    )


@router.post("/channels/{channel_id}/analyze-stream")
async def analyze_channel_stream(channel_id: str, db: AsyncSession = Depends(get_db)):
    channel = await db.get(Channel, channel_id)
    if not channel:
        return _not_found()

    async def _gen():
        # Flush headers immediately so the client sees a live connection
        # while the (potentially slow) RSS fetch and LLM generation run.
        yield {"type": "status", "message": "fetching feed"}
        try:
            entries = await get_raw_entries(channel.url, limit=5)
        except Exception as e:
            logger.error("analyze-stream feed fetch failed for %s: %s", channel.url, e)
            yield {"type": "error", "message": str(e)}
            return
        if not entries:
            yield {"type": "error", "message": "No entries found"}
            return
        async for event in analyze_feed_stream(entries):
            yield event

    return StreamingResponse(
        _stream_events(_gen()),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive", "X-Accel-Buffering": "no"},
    )


@router.post("/channels/{channel_id}/summarize-filters")
async def summarize_filters(channel_id: str, body: SummarizeFiltersRequest, db: AsyncSession = Depends(get_db)):
    """Summarize selected resources into an Agent-shaped rule proposal.

    Returns the works to subscribe (from the resources' linked series/movie),
    a GLOBAL filter from fields shared across ALL selected resources, and
    per-work override filters from fields that differ between works but are
    uniform within one work. The frontend modal lets the user tweak each
    piece before creating/applying an agent.
    """
    from app.models.file_resource import FileResource

    empty = {
        "works": [],
        "global_filter_config": None,
        "unlinked_count": 0,
        "explanation": "",
    }
    if not body.resource_ids:
        return success_response(empty)
    from sqlalchemy.orm import selectinload

    result = await db.execute(
        select(FileResource)
        .where(
            FileResource.channel_id == channel_id,
            FileResource.id.in_(body.resource_ids),
        )
        .options(selectinload(FileResource.series), selectinload(FileResource.movie))
    )
    resources = result.scalars().all()
    if not resources:
        return success_response(empty)

    exact_fields = [
        "subtitle_groups",
        "resolution",
        "video_codec",
        "audio_codec",
        "container",
        "subtitle_type",
        "source",
    ]
    from app.services.subtitle_groups import subtitle_groups_for_resource

    def _common_conditions(group) -> tuple[list[dict], list[str]]:
        """Fields where one value covers >=80% of the group."""
        conds, parts = [], []
        n = len(group)
        for field in exact_fields:
            values = [
                (subtitle_groups_for_resource(r) if field == "subtitle_groups" else getattr(r, field, None))
                for r in group
                if (subtitle_groups_for_resource(r) if field == "subtitle_groups" else getattr(r, field, None))
            ]
            if not values:
                continue
            if field == "subtitle_groups":
                member_counts = Counter(
                    str(member).strip().casefold()
                    for row in values for member in row
                    if str(member).strip()
                )
                common = [member for member, count in member_counts.items() if count / n >= 0.8]
                if common:
                    conds.append({"field": field, "operator": "contains", "value": common[0]})
                    parts.append(f"{field} contains {common[0]}")
                continue
            most_common, count = Counter(values).most_common(1)[0]
            if count / n >= 0.8:
                conds.append({"field": field, "operator": "eq", "value": most_common})
                parts.append(f"{field}={most_common}")
        return conds, parts

    # Common features across ALL selected resources -> global filter.
    global_conds, global_parts = _common_conditions(resources)
    global_fields = {c["field"] for c in global_conds}

    # Group by linked work -> subscription entries; features uniform within
    # one work but not globally common -> that work's filter_overrides.
    groups: dict[tuple[str, str], list] = {}
    unlinked = 0
    for r in resources:
        if r.series_id:
            groups.setdefault(("tv", r.series_id), []).append(r)
        elif r.movie_id:
            groups.setdefault(("movie", r.movie_id), []).append(r)
        else:
            unlinked += 1

    works = []
    for (ctype, work_id), group in sorted(groups.items(), key=lambda kv: -len(kv[1])):
        entity = group[0].series if ctype == "tv" else group[0].movie
        override_conds, override_parts = [], []
        n = len(group)
        for field in exact_fields:
            if field in global_fields:
                continue
            values = [
                (subtitle_groups_for_resource(r) if field == "subtitle_groups" else getattr(r, field, None))
                for r in group
                if (subtitle_groups_for_resource(r) if field == "subtitle_groups" else getattr(r, field, None))
            ]
            if not values:
                continue
            if field == "subtitle_groups":
                member_counts = Counter(
                    str(member).strip().casefold()
                    for row in values for member in row
                    if str(member).strip()
                )
                common = [member for member, count in member_counts.items() if count / n >= 0.8]
                if common:
                    override_conds.append({"field": field, "operator": "contains", "value": common[0]})
                    override_parts.append(f"{field} contains {common[0]}")
                continue
            most_common, count = Counter(values).most_common(1)[0]
            if count / n >= 0.8:
                override_conds.append({"field": field, "operator": "eq", "value": most_common})
                override_parts.append(f"{field}={most_common}")
        works.append({
            "content_type": ctype,
            "series_id": work_id if ctype == "tv" else None,
            "movie_id": work_id if ctype == "movie" else None,
            "title": (entity.title_cn or entity.title_en or entity.original_title) if entity else None,
            "poster_url": entity.poster_url if entity else None,
            "resource_count": n,
            "filter_overrides": (
                {"combinator": "and", "conditions": override_conds} if override_conds else None
            ),
            "override_explanation": "; ".join(override_parts),
        })

    explanation_parts = list(global_parts)
    if unlinked:
        explanation_parts.append(f"unlinked={unlinked}")
    return success_response({
        "works": works,
        "global_filter_config": (
            {"combinator": "and", "conditions": global_conds} if global_conds else None
        ),
        "unlinked_count": unlinked,
        "explanation": "; ".join(explanation_parts),
    })
