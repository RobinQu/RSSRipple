"""Dashboard API routes."""

import asyncio

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func, not_, or_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import joinedload, raiseload, selectinload

from app.clients.downloader import get_downloader_client
from app.config import settings
from app.database import get_db
from app.models.agent import Agent
from app.models.agent_work import AgentWork
from app.models.channel import Channel
from app.models.download_task import DownloadTask
from app.models.downloader import DownloaderInstance
from app.models.file_resource import FileResource
from app.models.movie import Movie
from app.models.organize_audit import OrganizeAuditEntry
from app.models.organize_plan import OrganizePlan
from app.models.pending_decision import PendingDecision
from app.models.resource_work_link import ResourceWorkLink
from app.models.series import TVSeries
from app.schemas.common import success_response
from app.schemas.dashboard import DashboardTodoIgnoreRequest
from app.schemas.file_resource import FileResourceResponse
from app.services.decision_service import maybe_reset_agent_run_status
from app.services.resource_confirmation import (
    LEGACY_CONFIRMATION_REASON_PREFIXES,
    ResourceConfirmation,
    inspect_resource_confirmation,
)
from app.utils.time import utcnow

router = APIRouter()

_CONFIRMATION_SCAN_BATCH_SIZE = 200


def _serialize_confirmation(
    resource: FileResource, confirmation: ResourceConfirmation,
) -> dict:
    # Resources whose flat work FKs are cleared still resolve to library
    # works: parked-on-collection rows keep ``collection_id``, links-carried
    # packs carry works on the link table. Surface the best link target so
    # the UI can make the work title clickable in every linked shape.
    work_title: str | None = None
    work_ref: dict | None = None
    if resource.series_id:
        work_ref = {"kind": "series", "id": resource.series_id}
        if resource.series:
            work_title = resource.series.title_cn or resource.series.title_en
    elif resource.movie_id:
        work_ref = {"kind": "movie", "id": resource.movie_id}
        if resource.movie:
            work_title = resource.movie.title_cn or resource.movie.title_en
    elif resource.collection_id:
        work_ref = {"kind": "collection", "id": resource.collection_id}
        if resource.collection is not None:
            work_title = (
                resource.collection.title_cn or resource.collection.title_en
            )
    else:
        for link in resource.work_links or []:
            entity = (
                link.series if link.series_id
                else link.movie if link.movie_id
                else None
            )
            if entity is None:
                continue
            work_ref = {
                "kind": "series" if link.series_id else "movie",
                "id": link.series_id or link.movie_id,
            }
            work_title = (
                entity.title_cn or entity.title_en or entity.original_title
            )
            break
    return {
        "resource": FileResourceResponse.model_validate(resource).model_dump(),
        "channel_name": resource.channel.name if resource.channel else None,
        "work_title": work_title,
        "work_ref": work_ref,
        "kinds": list(confirmation.kinds),
        "missing_fields": list(confirmation.missing_fields),
    }


async def _page_pending_decisions(
    db: AsyncSession, page: int, page_size: int,
) -> tuple[list[dict], int]:
    filters = (
        PendingDecision.status == "pending",
        not_(
            or_(
                *(
                    PendingDecision.reason.startswith(prefix)
                    for prefix in LEGACY_CONFIRMATION_REASON_PREFIXES
                )
            )
        ),
    )
    # Candidate cardinality is stored in a JSON column whose length function
    # differs between PostgreSQL and Turso. Select the small decision summary
    # set once and apply the canonical >=2 gate in Python for dialect parity.
    summaries = (await db.execute(
        select(PendingDecision.id, PendingDecision.candidates)
        .where(*filters)
        .order_by(PendingDecision.created_at.desc(), PendingDecision.id.desc())
    )).all()
    eligible_ids = [row.id for row in summaries if len(row.candidates or []) >= 2]
    total = len(eligible_ids)
    page_ids = eligible_ids[(page - 1) * page_size:page * page_size]
    if not page_ids:
        return [], total

    decisions = (await db.execute(
        select(PendingDecision)
        .where(PendingDecision.id.in_(page_ids))
        .options(
            selectinload(PendingDecision.series),
            selectinload(PendingDecision.movie),
            selectinload(PendingDecision.agent),
        )
    )).scalars().all()
    decisions_by_id = {decision.id: decision for decision in decisions}
    ordered_decisions = [
        decisions_by_id[decision_id]
        for decision_id in page_ids
        if decision_id in decisions_by_id
    ]

    candidate_ids = {
        resource_id
        for decision in ordered_decisions
        for resource_id in (decision.candidates or [])
    }
    candidate_rows = (await db.execute(
        select(FileResource)
        .where(FileResource.id.in_(candidate_ids))
        .options(
            selectinload(FileResource.series),
            selectinload(FileResource.movie),
            selectinload(FileResource.audio_work),
            selectinload(FileResource.collection),
        )
    )).scalars().all()
    candidates_by_id = {resource.id: resource for resource in candidate_rows}

    items: list[dict] = []
    for decision in ordered_decisions:
        candidates = [
            candidates_by_id[resource_id]
            for resource_id in (decision.candidates or [])
            if resource_id in candidates_by_id
        ]
        items.append({
            "id": decision.id,
            "agent_id": decision.agent_id,
            "agent_name": decision.agent.name if decision.agent else None,
            "series_id": decision.series_id,
            "movie_id": decision.movie_id,
            "episode": decision.episode,
            "season": decision.season,
            "reason": decision.reason,
            "llm_suggestion": decision.llm_suggestion,
            "candidates": [candidate.id for candidate in candidates],
            "candidate_resources": [
                FileResourceResponse.model_validate(candidate).model_dump()
                for candidate in candidates
            ],
            "title": (
                (decision.series.title_cn or decision.series.title_en)
                if decision.series_id and decision.series
                else (decision.movie.title_cn or decision.movie.title_en)
                if decision.movie_id and decision.movie
                else "Unknown"
            ),
            "created_at": decision.created_at,
        })
    return items, total


async def _page_pending_confirmations(
    db: AsyncSession, page: int, page_size: int,
) -> tuple[list[dict], int]:
    """Page policy-derived confirmations while returning an exact total."""
    load_options = (
        # Channel/Agent models contain several default selectin relationships.
        # A wildcard guard prevents those unrelated graphs from being loaded
        # once per scan batch; every relation used by the confirmation policy
        # is opted in explicitly below.
        raiseload("*"),
        joinedload(FileResource.channel),
        joinedload(FileResource.series).joinedload(TVSeries.collection),
        joinedload(FileResource.movie).joinedload(Movie.collection),
        joinedload(FileResource.audio_work),
        joinedload(FileResource.collection),
        # Links-carried packs (terminal multi-season) clear the flat work FKs;
        # the confirmation policy reads works off the link table instead.
        selectinload(FileResource.work_links).selectinload(ResourceWorkLink.series),
        selectinload(FileResource.work_links).selectinload(ResourceWorkLink.movie),
        selectinload(FileResource.file_assignments),
    )
    page_start = (page - 1) * page_size
    page_end = page_start + page_size
    matched = 0
    items: list[dict] = []
    # The confirmation policy spans resource, channel and work fields, so it
    # intentionally stays in the shared policy helper instead of duplicating
    # a fragile dialect-specific SQL predicate. Read only the ordered ids up
    # front, then hydrate resources in bounded batches; this avoids OFFSET's
    # quadratic full-table scan while keeping ORM relationship memory bounded.
    from app.models.resource_reparse_request import ResourceReparseRequest

    pending_reparse = select(ResourceReparseRequest.id).where(
        ResourceReparseRequest.resource_id == FileResource.id,
        ResourceReparseRequest.error_message.is_(None),
    ).exists()
    ordered_ids = (await db.execute(
        select(FileResource.id)
        .where(FileResource.confirmation_ignored_at.is_(None), ~pending_reparse)
        .order_by(FileResource.created_at.desc(), FileResource.id.desc())
    )).scalars().all()
    for batch_start in range(0, len(ordered_ids), _CONFIRMATION_SCAN_BATCH_SIZE):
        batch_ids = ordered_ids[
            batch_start:batch_start + _CONFIRMATION_SCAN_BATCH_SIZE
        ]
        batch_rows = (await db.execute(
            select(FileResource)
            .where(FileResource.id.in_(batch_ids))
            .options(*load_options)
        )).scalars().all()
        rows_by_id = {resource.id: resource for resource in batch_rows}
        for resource_id in batch_ids:
            resource = rows_by_id.get(resource_id)
            if resource is None:
                continue  # deleted concurrently after the id snapshot
            required_fields = (
                resource.channel.required_metadata_fields
                if resource.channel else None
            )
            confirmation = inspect_resource_confirmation(resource, required_fields)
            if not confirmation.required:
                continue
            if page_start <= matched < page_end:
                items.append(_serialize_confirmation(resource, confirmation))
            matched += 1
    return items, matched


async def _page_pending_plans(
    db: AsyncSession, page: int, page_size: int,
) -> tuple[list[dict], int]:
    from app.api.v1.organize import _PLAN_LOAD_OPTIONS, _plan_list_item

    total = int((await db.execute(
        select(func.count()).select_from(OrganizePlan).where(
            OrganizePlan.status == "pending"
        )
    )).scalar_one() or 0)
    plans = (await db.execute(
        select(OrganizePlan)
        .where(OrganizePlan.status == "pending")
        .order_by(OrganizePlan.created_at.desc(), OrganizePlan.id.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
        .options(*_PLAN_LOAD_OPTIONS)
    )).scalars().all()
    return [_plan_list_item(plan) for plan in plans], total


@router.post("/dashboard/todos/ignore")
async def ignore_dashboard_todos(
    body: DashboardTodoIgnoreRequest,
    db: AsyncSession = Depends(get_db),
):
    """Persistently dismiss one or many dashboard todos of the same kind."""
    ids = list(dict.fromkeys(body.ids))
    ignored = 0
    affected_agents: set[str] = set()
    if body.kind == "decision":
        rows = (await db.execute(
            select(PendingDecision).where(
                PendingDecision.id.in_(ids),
                PendingDecision.status == "pending",
            )
        )).scalars().all()
        for row in rows:
            if (
                len(row.candidates or []) < 2
                or (row.reason or "").startswith(LEGACY_CONFIRMATION_REASON_PREFIXES)
            ):
                continue
            row.status = "skipped"
            row.decided_at = utcnow()
            affected_agents.add(row.agent_id)
            ignored += 1
        if affected_agents:
            await db.flush()
            for agent_id in affected_agents:
                await maybe_reset_agent_run_status(db, agent_id)
    elif body.kind == "confirmation":
        rows = (await db.execute(
            select(FileResource).where(FileResource.id.in_(ids))
        )).scalars().all()
        now = utcnow()
        for row in rows:
            if row.confirmation_ignored_at is None:
                row.confirmation_ignored_at = now
                ignored += 1
    else:
        rows = (await db.execute(
            select(OrganizePlan).where(
                OrganizePlan.id.in_(ids),
                OrganizePlan.status.in_(("pending", "failed")),
            )
        )).scalars().all()
        for row in rows:
            from_status = row.status
            row.status = "cancelled"
            db.add(OrganizeAuditEntry(
                plan_id=row.id,
                action="cancelled",
                detail={"from_status": from_status, "source": "dashboard_ignore"},
            ))
            ignored += 1
    await db.commit()
    return success_response({
        "requested": len(ids),
        "ignored": ignored,
        "unchanged": len(ids) - ignored,
    })


async def _top_agent_summaries(db: AsyncSession) -> list[dict]:
    active_statuses = ("pending", "queued", "downloading")
    task_counts = (
        select(
            DownloadTask.agent_id.label("agent_id"),
            func.count().label("active_task_count"),
        )
        .where(DownloadTask.status.in_(active_statuses))
        .group_by(DownloadTask.agent_id)
        .subquery()
    )
    rows = (await db.execute(
        select(Agent, func.coalesce(task_counts.c.active_task_count, 0))
        .outerjoin(task_counts, task_counts.c.agent_id == Agent.id)
        .where(Agent.status == "active")
        .order_by(
            func.coalesce(task_counts.c.active_task_count, 0).desc(),
            Agent.created_at.desc(),
        )
        .limit(4)
        .options(
            raiseload("*"),
            joinedload(Agent.channel),
            joinedload(Agent.downloader),
            selectinload(Agent.works).joinedload(AgentWork.series),
            selectinload(Agent.works).joinedload(AgentWork.movie),
        )
    )).all()
    summaries: list[dict] = []
    for agent, active_task_count in rows:
        works = []
        for work in agent.works:
            works.append({
                "id": work.id,
                "filter_overrides": work.filter_overrides,
                "display_name_override": work.display_name_override,
                "series": ({
                    "id": work.series.id,
                    "title_cn": work.series.title_cn,
                    "title_en": work.series.title_en,
                    "original_title": work.series.original_title,
                    "poster_url": work.series.poster_url,
                } if work.series else None),
                "movie": ({
                    "id": work.movie.id,
                    "title_cn": work.movie.title_cn,
                    "title_en": work.movie.title_en,
                    "original_title": work.movie.original_title,
                    "poster_url": work.movie.poster_url,
                } if work.movie else None),
            })
        summaries.append({
            "id": agent.id,
            "name": agent.name,
            "channel_id": agent.channel_id,
            "channel_name": agent.channel.name if agent.channel else None,
            "downloader_name": agent.downloader.name if agent.downloader else None,
            "scope_channel_wide": agent.scope_channel_wide,
            "filter_config": agent.filter_config,
            "active_task_count": int(active_task_count or 0),
            "works": works,
        })
    return summaries


async def _dashboard_overview(
    db: AsyncSession,
    decision_page: int,
    confirmation_page: int,
    plan_page: int,
    page_size: int,
) -> dict:
    active_agents_q = await db.execute(
        select(func.count()).select_from(Agent).where(Agent.status == "active")
    )
    active_agents = active_agents_q.scalar_one() or 0

    active_channels_q = await db.execute(
        select(func.count()).select_from(Channel).where(Channel.status == "active")
    )
    active_channels = active_channels_q.scalar_one() or 0

    pending_decisions, pending_decisions_total = await _page_pending_decisions(
        db, decision_page, page_size
    )
    pending_confirmations, pending_confirmations_total = (
        await _page_pending_confirmations(db, confirmation_page, page_size)
    )
    pending_plans, pending_plans_total = await _page_pending_plans(
        db, plan_page, page_size
    )
    return {
        "active_agents": active_agents,
        "active_channels": active_channels,
        "top_agents": await _top_agent_summaries(db),
        "pending_decisions": pending_decisions,
        "pending_decisions_total": pending_decisions_total,
        "pending_confirmations": pending_confirmations,
        "pending_confirmations_total": pending_confirmations_total,
        "pending_plans": pending_plans,
        "pending_plans_total": pending_plans_total,
    }


async def _dashboard_downloads(db: AsyncSession) -> dict:

    # Active download tasks
    active_statuses = ["pending", "queued", "downloading"]
    tasks_q = await db.execute(
        select(DownloadTask)
        .where(DownloadTask.status.in_(active_statuses))
        .options(
            raiseload("*"),
            joinedload(DownloadTask.agent).joinedload(Agent.channel),
            joinedload(DownloadTask.file_resource).joinedload(FileResource.series),
            joinedload(DownloadTask.file_resource).joinedload(FileResource.movie),
        )
    )
    tasks = tasks_q.scalars().all()

    groups: dict[tuple, dict] = {}
    unknown_key = ("unknown", None)
    groups[unknown_key] = {
        "type": "unknown", "id": None, "title": "未识别", "poster_url": None, "tasks": [],
    }

    for task in tasks:
        resource = task.file_resource
        agent = task.agent
        task_entry = {
            "task_id": task.id,
            "resource_title": resource.title_raw if resource else "",
            "progress": task.progress,
            "agent_id": agent.id if agent else None,
            "agent_name": agent.name if agent else None,
            "channel_id": agent.channel_id if agent else None,
            "channel_name": agent.channel.name if agent and agent.channel else None,
            "download_speed": task.download_speed or 0,
        }
        if resource and resource.series_id and resource.series:
            key = ("series", resource.series_id)
            if key not in groups:
                s = resource.series
                groups[key] = {
                    "type": "series", "id": resource.series_id,
                    "title": s.title_cn or s.title_en or s.original_title or "Unknown",
                    "poster_url": s.poster_url,
                    "tasks": [],
                }
            groups[key]["tasks"].append(task_entry)
        elif resource and resource.movie_id and resource.movie:
            key = ("movie", resource.movie_id)
            if key not in groups:
                m = resource.movie
                groups[key] = {
                    "type": "movie", "id": resource.movie_id,
                    "title": m.title_cn or m.title_en or m.original_title or "Unknown",
                    "poster_url": m.poster_url,
                    "tasks": [],
                }
            groups[key]["tasks"].append(task_entry)
        else:
            groups[unknown_key]["tasks"].append(task_entry)

    # Only include unknown if it has tasks
    active_download_groups = [g for g in groups.values() if g["tasks"] or g["type"] != "unknown"]

    # Untracked torrents: unfinished in a downloader but without a matching
    # non-terminal DownloadTask (e.g. added directly in Transmission).
    # Transfer state does not matter — a stopped/paused unfinished torrent is
    # still an unmanaged download the user should see. The raw torrent status
    # rides along so the UI can tell "stopped" rows apart from live ones.
    untracked_tasks: list[dict] = []
    tracked_q = await db.execute(
        select(DownloadTask.downloader_id, DownloadTask.transmission_torrent_id).where(
            DownloadTask.status.in_(["pending", "queued", "downloading", "paused"]),
            DownloadTask.transmission_torrent_id.isnot(None),
        )
    )
    tracked: dict[str, set[int]] = {}
    for dl_id, tid in tracked_q.all():
        tracked.setdefault(dl_id, set()).add(tid)

    downloaders = (await db.execute(select(DownloaderInstance))).scalars().all()

    async def _list_torrents(downloader: DownloaderInstance) -> list[dict]:
        try:
            wrapper = get_downloader_client(downloader)
            return await asyncio.wait_for(
                wrapper.list_torrents(),
                timeout=min(settings.transmission_timeout, 2),
            )
        except Exception:
            # An unreachable downloader must not break the dashboard.
            return []

    torrent_lists = await asyncio.gather(*(_list_torrents(d) for d in downloaders))

    # Prefer the live daemon rate for tracked tasks.  The scheduler persists
    # speeds periodically, but the dashboard is also polled independently and
    # should not wait for the next scheduler tick to reflect current traffic.
    task_ids_by_torrent = {
        (task.downloader_id, task.transmission_torrent_id): task.id
        for task in tasks
        if task.transmission_torrent_id is not None
    }
    live_speeds: dict[str, int] = {}
    for downloader, torrents in zip(downloaders, torrent_lists, strict=True):
        for torrent in torrents:
            task_id = task_ids_by_torrent.get((downloader.id, torrent.get("id")))
            if task_id is not None:
                live_speeds[task_id] = int(torrent.get("rate_download") or 0)
    for group in groups.values():
        for task_entry in group["tasks"]:
            if task_entry["task_id"] in live_speeds:
                task_entry["download_speed"] = live_speeds[task_entry["task_id"]]

    for downloader, torrents in zip(downloaders, torrent_lists, strict=True):
        tracked_ids = tracked.get(downloader.id, set())
        for torrent in torrents:
            # "Finished" must be derived, not trusted: Transmission reports
            # isFinished=false for *stopped* torrents even at 100%, so a
            # fully downloaded stopped torrent would otherwise leak in.
            done = torrent.get("is_finished") or (torrent.get("percent_done") or 0) >= 1
            if not done and torrent.get("id") not in tracked_ids:
                untracked_tasks.append({
                    # Synthetic id — there is no DownloadTask row for these.
                    "task_id": f"untracked-{downloader.id}-{torrent['id']}",
                    "resource_title": torrent.get("name", ""),
                    "progress": torrent.get("percent_done", 0.0),
                    "agent_id": None,
                    "agent_name": None,
                    "channel_id": None,
                    "channel_name": None,
                    "downloader_id": downloader.id,
                    "downloader_name": downloader.name,
                    "download_speed": int(torrent.get("rate_download") or 0),
                    # Raw Transmission status enum (downloading/stopped/…).
                    "status": torrent.get("status"),
                })

    if untracked_tasks:
        active_download_groups.append({
            "type": "untracked",
            "id": None,
            "title": "未跟踪",
            "poster_url": None,
            "tasks": untracked_tasks,
        })

    # The headline "downloading" count tracks only in-flight work — stopped
    # untracked torrents are listed for visibility but are not transferring.
    active_untracked = sum(
        1
        for entry in untracked_tasks
        if entry["status"] in ("downloading", "download pending")
    )

    return {
        "active_download_count": len(tasks) + active_untracked,
        "active_download_groups": active_download_groups,
    }


@router.get("/dashboard/overview")
async def get_dashboard_overview(
    decision_page: int = Query(1, ge=1),
    confirmation_page: int = Query(1, ge=1),
    plan_page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
):
    return success_response(await _dashboard_overview(
        db, decision_page, confirmation_page, plan_page, page_size
    ))


@router.get("/dashboard/downloads")
async def get_dashboard_downloads(db: AsyncSession = Depends(get_db)):
    return success_response(await _dashboard_downloads(db))


@router.get("/dashboard")
async def get_dashboard(
    decision_page: int = Query(1, ge=1),
    confirmation_page: int = Query(1, ge=1),
    plan_page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
):
    """Backward-compatible aggregate; the SPA polls split endpoints."""
    overview = await _dashboard_overview(
        db, decision_page, confirmation_page, plan_page, page_size
    )
    downloads = await _dashboard_downloads(db)
    return success_response({**overview, **downloads})
