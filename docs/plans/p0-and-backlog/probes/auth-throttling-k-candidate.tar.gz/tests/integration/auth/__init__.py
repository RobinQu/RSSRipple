"""Authentication integration gates."""
