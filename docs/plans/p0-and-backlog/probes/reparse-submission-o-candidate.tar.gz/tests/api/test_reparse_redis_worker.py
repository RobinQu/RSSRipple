"""Real Redis producer/consumer ownership and API persistence; metadata is synthetic."""

import asyncio
import os
from unittest.mock import AsyncMock

import pytest
from sqlalchemy import select

from app.job_handlers import _handle_reprocess_resource_metadata
from app.models.file_resource import FileResource
from app.models.resource_reparse_request import ResourceReparseRequest
from app.services.task_queue import RedisQueue, current_job_identity, require_execution_ownership
from tests.api.test_resources import _make_resource


@pytest.mark.parametrize("outcome", ["success", "response_lost", "metadata_error"])
async def test_real_redis_worker_acknowledges_only_its_durable_request(
    client, sample_channel, db_session_factory, monkeypatch, outcome, record_property,
):
    # The API fixture shortens long sleeps; real Redis leases need real time.
    from tests.api.conftest import _real_sleep

    monkeypatch.setattr(asyncio, "sleep", _real_sleep)
    url = os.environ.get("REPARSE_TEST_REDIS_URL")
    if not url:
        pytest.skip("Dedicated Redis required for reparse worker probe")
    assert url.startswith("redis://127.0.0.1:32864/"), "Dedicated probe Redis only"
    monkeypatch.setattr("app.database.async_session_factory", db_session_factory)
    monkeypatch.setattr("app.job_handlers._refresh_runtime_config", AsyncMock())
    rid = await _make_resource(db_session_factory, sample_channel.id)
    producer, worker = RedisQueue(redis_url=url), RedisQueue(redis_url=url)
    entered, release = asyncio.Event(), asyncio.Event()
    identities = []

    async def metadata_pipeline(resource_id, channel_id, semaphore, **kwargs):
        assert resource_id == rid
        assert channel_id == sample_channel.id
        assert kwargs["force_refresh"] is True
        await require_execution_ownership()  # Actual Redis token/active/lease check.
        identities.append(current_job_identity())
        entered.set()
        await release.wait()
        await require_execution_ownership()
        if outcome == "metadata_error":
            raise ValueError("Synthetic metadata provider error")

    monkeypatch.setattr("app.services.fetch_service._process_resource_metadata", metadata_pipeline)
    monkeypatch.setattr("app.services.task_queue.task_queue", producer)
    worker.register("reprocess_resource_metadata", _handle_reprocess_resource_metadata)
    await producer.start(consume=False)
    await worker.start()
    original_enqueue = producer.enqueue

    async def enqueue_then_lose_response(*args, **kwargs):
        accepted = await original_enqueue(*args, **kwargs)
        assert accepted is not None
        raise ConnectionError("Injected response loss AFTER real Redis acceptance")

    if outcome == "response_lost":
        monkeypatch.setattr(producer, "enqueue", enqueue_then_lose_response)
    try:
        response = await client.post(f"/api/v1/resources/{rid}/reparse-metadata")
        assert response.status_code == 200
        await asyncio.wait_for(entered.wait(), timeout=10)
        state = await producer.status(f"reprocess-resource:{rid}")
        assert state["status"] == "running"
        assert identities == [(f"reprocess-resource:{rid}", state["job_id"])]
        async with db_session_factory() as db:
            pending = await db.scalar(select(ResourceReparseRequest).where(ResourceReparseRequest.resource_id == rid))
            request_id = pending.id
        # A real user action while the actual consumer is running must survive.
        ignored = await client.post("/api/v1/dashboard/todos/ignore", json={"kind": "confirmation", "ids": [rid]})
        assert ignored.status_code == 200
        release.set()
        async with asyncio.timeout(10):
            while True:
                state = await producer.status(f"reprocess-resource:{rid}")
                if state["status"] in {"done", "failed"}:
                    break
                await asyncio.sleep(0.02)
        assert state["status"] == ("failed" if outcome == "metadata_error" else "done")
        async with db_session_factory() as db:
            assert await db.get(ResourceReparseRequest, request_id) is None
            assert (await db.get(FileResource, rid)).confirmation_ignored_at is not None
        record_property("actual_redis_execution_ownership", True)
        record_property("metadata_provider", "synthetic blocked coroutine")
        record_property("response_loss", "injected after real enqueue" if outcome == "response_lost" else "none")
        record_property("queue_terminal_status", state["status"])
    finally:
        release.set()
        await worker.stop()
        await producer.stop()
