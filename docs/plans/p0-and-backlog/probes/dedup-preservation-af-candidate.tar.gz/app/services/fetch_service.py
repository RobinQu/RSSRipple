"""Fetch service: RSS fetch → parse → store → metadata pipeline."""

import asyncio
import logging
from datetime import timedelta

from sqlalchemy import and_, or_, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.clients.rss_parser import (
    _entry_to_dict,
    _extract_download_urls,
    _extract_published_at,
    _parse_feed_sync,
)
from app.models.channel import Channel
from app.models.file_resource import FileResource
from app.services.metadata_service import extract_search_title, fetch_and_link_metadata
from app.services.resource_confirmation import inspect_resource_confirmation
from app.services.resource_parser import normalize_parsed_fields, parse_entry, strip_season_from_title
from app.services.text_normalizer import normalize_title
from app.utils.time import utcnow

logger = logging.getLogger(__name__)

# ── Metadata backfill knobs ──
# Existing FileResources are skipped by the GUID dedup above, so without a
# backfill phase a transient metadata failure (timeout / LLM-format error) or
# a source that later improves would never get a second chance. Each fetch
# re-runs up to ``MAX_BACKFILL_PER_FETCH`` retry-eligible unmatched resources.
MAX_BACKFILL_PER_FETCH = 30
# How many unmatched rows to load for eligibility filtering. Ordered
# oldest-attempt-first, so the most-eligible rows come first; scanning a bit
# beyond the cap absorbs ordering ties without loading the whole backlog.
MAX_BACKFILL_SCAN = 100
# Transient failures retry with exponential backoff: 1h, 2h, 4h, … capped.
TRANSIENT_BACKOFF_BASE_HOURS = 1
TRANSIENT_BACKOFF_MAX_HOURS = 24
# A definitive "no match" is retried this long after the last attempt, in case
# the external source has improved its coverage. Kept short-ish because a
# "not_found" can also be an LLM finalization miss (the agent identified the
# work but finalized found=false); a shorter TTL gives those another chance
# sooner without hammering genuinely-nonexistent works too hard.
NOT_FOUND_RETRY_DAYS = 7
# Linked resources with an incomplete Channel contract are retried on a
# slower cadence.  They have already succeeded at work matching, so they must
# not be treated as ordinary unmatched rows (or re-run on every five-minute
# scheduler tick).
LINKED_ENRICHMENT_RETRY_HOURS = 6

# Standalone global backfill (runs independent of fetch_channel so metadata
# repair is not starved by slow feed fetches). Bounded per run; the scheduler
# re-enqueues it on a short interval and the task-queue dedup gates it to run
# back-to-back, so it effectively processes continuously while work remains.
MAX_GLOBAL_BACKFILL_PER_RUN = 50
MAX_GLOBAL_BACKFILL_SCAN = 300

# Max in-flight metadata jobs within one fetch cycle / global backfill run.
# Metadata is LLM + external-search bound (tens of seconds each), so a modest
# cap multiplies throughput without overwhelming the LLM endpoint or the
# external search APIs. Each task runs in its own short-lived DB session.
MAX_METADATA_CONCURRENCY = 4

# ── Per-work metadata serialization ──
# The semaphore bounds total in-flight work, but several resources of the
# SAME not-yet-persisted work can still run concurrently: each misses the
# series/movie lookup (its siblings haven't committed yet), asks the agent,
# and inserts its own duplicate TVSeries/Movie row. Serialize the metadata +
# commit section per normalized search title so the first task's commit is
# visible to the next task's lookup. Cross-process duplicates (PostgreSQL
# replicas) remain possible; the daily dedup job is the backstop for those.
_WORK_METADATA_LOCKS: dict[str, asyncio.Lock] = {}


def _work_metadata_lock(key: str) -> asyncio.Lock:
    lock = _WORK_METADATA_LOCKS.get(key)
    if lock is None:
        lock = _WORK_METADATA_LOCKS[key] = asyncio.Lock()
    return lock


def _simple_title_clean(raw: str) -> str | None:
    """Minimal title cleanup used as the search_title fallback when the
    metadata agent fails.

    Strips the leading [subtitle group], takes the segment before a `` / ``
    alt-title separator (the primary work name), drops the episode tail, and
    strips a trailing season suffix so the work title matches its base form.
    """
    if not raw:
        return None
    import re
    cleaned = re.sub(r"^\[[^\]]*\]\s*", "", raw)
    cleaned = re.split(r"\s*/\s*", cleaned, maxsplit=1)[0]
    cleaned = re.sub(r"\s*-\s*\d+\b.*$", "", cleaned)
    cleaned = strip_season_from_title(cleaned)
    return cleaned.strip() or raw.strip()

# Columns that are set explicitly in the FileResource(...) constructor.
_EXPLICIT_RESOURCE_COLS = frozenset({
    "id", "channel_id", "guid", "title_raw",
    "torrent_url", "detail_url", "published_at", "parsed_at",
    "created_at",
})


def _is_retry_eligible(resource: FileResource, now) -> bool:
    """Whether an unmatched resource should be re-run on this fetch.

    Policy (matches the design in the metadata-retry spec):
      * never tried (``metadata_attempts == 0``) → eligible;
      * ``non_work`` (correctly identified as music/ASMR/OP) → never;
      * ``transient`` (timeout/connection/LLM-format) → after exponential
        backoff, capped at ``TRANSIENT_BACKOFF_MAX_HOURS``;
      * ``not_found`` (source had no match) → after ``NOT_FOUND_RETRY_DAYS``;
      * unknown failure type or missing timestamp → eligible (re-evaluate).
    """
    attempts = int(getattr(resource, "metadata_attempts", 0) or 0)
    if attempts == 0:
        return True
    ftype = getattr(resource, "metadata_failure_type", None)
    if ftype == "non_work":
        return False
    last = getattr(resource, "last_metadata_attempt_at", None)
    if last is None:
        return True
    age = now - last
    if ftype == "transient":
        backoff_hours = min(
            TRANSIENT_BACKOFF_BASE_HOURS * (2 ** (attempts - 1)),
            TRANSIENT_BACKOFF_MAX_HOURS,
        )
        return age >= timedelta(hours=backoff_hours)
    if ftype == "not_found":
        return age >= timedelta(days=NOT_FOUND_RETRY_DAYS)
    return True


def _is_linked_enrichment_eligible(resource: FileResource, now) -> bool:
    """Whether a linked resource still has Channel metadata to enrich."""
    if not (
        getattr(resource, "series_id", None)
        or getattr(resource, "movie_id", None)
        or getattr(resource, "audio_work_id", None)
        or getattr(resource, "collection_id", None)
    ):
        return False
    channel = getattr(resource, "channel", None)
    if channel is None:
        return False
    confirmation = inspect_resource_confirmation(
        resource, getattr(channel, "required_metadata_fields", None)
    )
    if not confirmation.required:
        return False
    last = getattr(resource, "last_metadata_attempt_at", None)
    return last is None or now - last >= timedelta(hours=LINKED_ENRICHMENT_RETRY_HOURS)


async def reset_channel_metadata_for_source_change(
    db: AsyncSession, channel_id: str
) -> int:
    """Reset a channel's unmatched not_found/transient resources so the backfill
    reprocesses them immediately.

    Called when a channel's ``metadata_source`` changes: a not_found recorded
    under an old source should not block a resource for the full
    ``NOT_FOUND_RETRY_DAYS`` cooldown now that the channel uses a different
    source (e.g. wikipedia). Clearing ``metadata_failure_type`` /
    ``last_metadata_attempt_at`` / ``metadata_attempts`` makes the resource
    retry-eligible (``attempts == 0``) on the next backfill run, which then
    re-links it under the new source.
    """
    result = await db.execute(
        select(FileResource).where(
            FileResource.channel_id == channel_id,
            FileResource.series_id.is_(None),
            FileResource.movie_id.is_(None),
            FileResource.audio_work_id.is_(None),
            FileResource.metadata_failure_type.in_(("not_found", "transient")),
        )
    )
    reset = 0
    for r in result.scalars().all():
        r.metadata_failure_type = None
        r.last_metadata_attempt_at = None
        r.metadata_attempts = 0
        reset += 1
    return reset


async def _gather_metadata(*operations) -> None:
    """Drain started resource tasks before propagating a batch failure."""
    from app.services.task_queue import ExecutionOwnershipLostError

    results = await asyncio.gather(*operations, return_exceptions=True)
    # Ownership loss must not be hidden behind an unrelated resource error.
    for result in results:
        if isinstance(result, ExecutionOwnershipLostError):
            raise result
    for result in results:
        if isinstance(result, BaseException):
            raise result


async def _process_resource_metadata(
    resource_id: str,
    channel_id: str,
    semaphore: asyncio.Semaphore,
    *,
    force_refresh: bool = False,
) -> None:
    """Retry an uncommitted metadata transaction with a fresh session."""
    from app.database import retry_on_lock
    from app.services.task_queue import ExecutionOwnershipLostError

    try:
        await retry_on_lock(
            lambda: _process_resource_metadata_once(
                resource_id, channel_id, semaphore, force_refresh=force_refresh
            )
        )
    except ExecutionOwnershipLostError:
        raise
    except Exception as exc:
        logger.warning("[metadata-task] retries exhausted for %s: %s", resource_id, exc)


async def _process_resource_metadata_once(
    resource_id: str,
    channel_id: str,
    semaphore: asyncio.Semaphore,
    *,
    force_refresh: bool = False,
) -> None:
    """Run metadata + poster download for one FileResource in its own session.

    Used by both the new-resource path and the backfill path so each
    resource's slow LLM/search work runs concurrently under ``semaphore``
    and in an isolated short-lived DB session - the caller's shared fetch
    session is never held across the agent loop (which spans many LLM +
    external search calls and can take tens of seconds), avoiding the
    "database is locked" / unresponsive-edit symptom that motivated
    committing the resource row before metadata in the first place.
    """
    from app.database import _is_retryable_lock_error, async_session_factory
    from app.models.movie import Movie
    from app.models.series import TVSeries
    from app.services.metadata_agent import get_agent
    from app.services.metadata_service import download_and_cache_poster
    from app.services.task_queue import ExecutionOwnershipLostError, require_execution_ownership
    from app.services.torrent_inspect import ensure_torrent_cached, maybe_inspect_torrent

    async with semaphore:
        await require_execution_ownership()
        async with async_session_factory() as task_db:
            metadata_committed = False
            try:
                result = await task_db.execute(
                    select(FileResource)
                    .options(selectinload(FileResource.file_assignments))
                    .where(FileResource.id == resource_id)
                )
                resource = result.scalar_one_or_none()
                channel = await task_db.get(Channel, channel_id)
                if resource is None or channel is None:
                    return
                # Cache the .torrent for every resource (http(s) direct links
                # only) so later file-listing lookups never re-download.
                await ensure_torrent_cached(resource)
                await require_execution_ownership()
                # magnet: links have no .torrent to fetch — kick off background
                # metadata resolution (libtorrent, metadata-only) so the torrent
                # cache / Channel A inspection can work later. Never blocks fetch.
                if (resource.torrent_url or "").startswith("magnet:"):
                    try:
                        from app.services import magnet_resolve

                        await magnet_resolve.enqueue_resolution(resource.id)
                    except Exception:  # noqa: BLE001 — best-effort, never block fetch
                        logger.debug(
                            "[magnet] enqueue failed for %s", resource.id, exc_info=True
                        )
                # Channel A torrent inspection: deterministic .torrent
                # file-listing analysis may reclassify the resource as a
                # batch the title regexes missed. Runs before metadata
                # matching; batches still need work linking, so matching
                # continues regardless of the verdict. No commit here — the
                # metadata-phase commit below persists any changes.
                await maybe_inspect_torrent(task_db, resource, channel)
                work_key = normalize_title(resource.search_title or extract_search_title(resource))
                async with _work_metadata_lock(work_key):
                    await require_execution_ownership()
                    if task_db.bind.dialect.name == "sqlite":
                        # Turso starts its physical transaction on DML, not
                        # SELECT. Without it, releasing the first SAVEPOINT
                        # commits changes that an ownership-loss rollback must
                        # still be able to undo. Match no rows and take no row
                        # locks; keep the driver's configured isolation level.
                        from sqlalchemy import text

                        await task_db.execute(text(
                            "UPDATE file_resources SET id = id WHERE 1 = 0"
                        ))
                    if channel.metadata_agent_enabled:
                        try:
                            async with task_db.begin_nested():
                                await get_agent().process(
                                    resource, channel, task_db, force_refresh=force_refresh
                                )
                        except ExecutionOwnershipLostError:
                            raise
                        except Exception as e:
                            if _is_retryable_lock_error(e):
                                raise
                            # SAVEPOINT rollback expires rows changed by a failed
                            # write-back; reload before continuing the outer task.
                            await task_db.refresh(resource)
                            logger.warning("MetadataAgent failed for %s: %s", resource_id, e)
                            base_title = _simple_title_clean(resource.title_raw)
                            if base_title:
                                resource.search_title = base_title
                    else:
                        try:
                            async with task_db.begin_nested():
                                await fetch_and_link_metadata(task_db, resource, channel)
                        except ExecutionOwnershipLostError:
                            raise
                        except Exception as e:
                            if _is_retryable_lock_error(e):
                                raise
                            await task_db.refresh(resource)
                            logger.warning("Metadata linking failed for %s: %s", resource_id, e)
                    await require_execution_ownership()
                    # Final shape guard shared by every metadata route. Cache
                    # hits and known-work title shortcuts bypass the repository
                    # write-back branch and may otherwise restore a flat FK
                    # after torrent inspection linked a franchise collection.
                    from app.services.franchise_service import (
                        enforce_franchise_resource_invariant,
                    )
                    if enforce_franchise_resource_invariant(resource):
                        logger.info(
                            "[metadata-task] cleared flat work FK restored on "
                            "franchise resource %s",
                            resource.id,
                        )
                    # Every metadata path converges here.  Run the DB-backed
                    # sibling-history policy after linking as a final safety
                    # net, including cached and force-refresh agent paths.
                    if resource.series_id and not resource.is_batch:
                        from app.models.series import TVSeries
                        from app.services.episode_history import (
                            apply_episode_history_reconcile,
                            apply_season_history_default,
                        )
                        from app.services.metadata_episode_reconcile import (
                            seasons_map_for_work,
                        )

                        series_row = await task_db.get(TVSeries, resource.series_id)
                        if series_row is not None:
                            await apply_episode_history_reconcile(
                                task_db,
                                resource,
                                seasons_map=seasons_map_for_work(series_row),
                            )
                            await apply_season_history_default(task_db, resource)
                    # Torrent inspection precedes metadata matching, so its
                    # deterministic rows may still be work-less.  Once this
                    # pass has linked exactly one work, bind those rows now.
                    from app.services.batch_content_analysis import (
                        bind_single_work_assignments,
                    )
                    await bind_single_work_assignments(task_db, resource)
                    # Bangumi series-graph expansion (B1): a franchise /
                    # multi_season pack linked to a Bangumi base entry unfolds
                    # its sibling seasons / movies / specials via the
                    # related-subjects endpoint. Best-effort and expansion-only
                    # — failures keep the original link verdict.
                    if resource.is_batch and resource.batch_scope in (
                        "franchise", "multi_season",
                    ):
                        try:
                            from app.services.bangumi_relations import (
                                expand_bangumi_series_graph,
                            )

                            await expand_bangumi_series_graph(task_db, resource)
                        except ExecutionOwnershipLostError:
                            raise
                        except Exception as e:  # noqa: BLE001 — never a downgrade
                            logger.warning(
                                "[bangumi-graph] expansion failed for %s: %s",
                                resource_id, e, exc_info=True,
                            )
                        # Cluster binding second pass: torrent inspection runs
                        # BEFORE metadata linking, so works created or
                        # season-relocated by the series graph above were not
                        # visible to it. The pass is idempotent — unbound
                        # clusters resolve against the expanded members, and
                        # already-bound auto rows mirror any season relocation
                        # (e.g. "Final Stage" created as s1 by franchise
                        # linking, then relocated to s6 by the graph).
                        try:
                            from app.services.cluster_work_binding import (
                                bind_hint_clusters,
                            )

                            await bind_hint_clusters(task_db, resource, channel)
                        except ExecutionOwnershipLostError:
                            raise
                        except Exception as e:  # noqa: BLE001 — enrichment only
                            logger.warning(
                                "[cluster-bind] post-graph pass failed for %s: %s",
                                resource_id, e,
                            )
                        # C4: member resolution (web fallback, English titles)
                        # and the series graph (Japanese titles) can each
                        # create a row for the SAME film. Deterministic
                        # same-resource same-date movie dedup — no date
                        # evidence, no merge.
                        try:
                            from app.services.franchise_service import (
                                dedupe_resource_movies,
                            )

                            async with task_db.begin_nested():
                                await dedupe_resource_movies(
                                    task_db, resource, channel=channel
                                )
                        except ExecutionOwnershipLostError:
                            raise
                        except Exception as e:  # noqa: BLE001 — enrichment only
                            if _is_retryable_lock_error(e):
                                raise
                            await task_db.refresh(resource)
                            logger.warning(
                                "[franchise] movie dedup failed for %s: %s",
                                resource_id, e,
                            )
                    from app.services.resource_publication import publish_resource

                    await require_execution_ownership()
                    await publish_resource(task_db, resource.id, kind="metadata")
                    # Commit inside the lock: the next same-work task's lookup
                    # must see this task's series/movie row.
                    await require_execution_ownership()
                    await task_db.commit()
                    metadata_committed = True

                # Poster download for newly-linked entities (kept in the same
                # task session so a network call never blocks other writers).
                if resource.series_id:
                    series = await task_db.get(TVSeries, resource.series_id)
                    if series and series.poster_url and series.poster_url.startswith("http"):
                        local = await download_and_cache_poster(series.poster_url)
                        if local:
                            series.poster_url = local
                elif resource.movie_id:
                    movie = await task_db.get(Movie, resource.movie_id)
                    if movie and movie.poster_url and movie.poster_url.startswith("http"):
                        local = await download_and_cache_poster(movie.poster_url)
                        if local:
                            movie.poster_url = local
                await require_execution_ownership()
                await task_db.commit()
            except Exception as e:
                logger.warning("[metadata-task] failed for %s: %s", resource_id, e)
                try:
                    await task_db.rollback()
                except Exception:
                    pass
                if isinstance(e, ExecutionOwnershipLostError):
                    raise
                if not metadata_committed and _is_retryable_lock_error(e):
                    raise


async def _backfill_unmatched_resources(
    channel: Channel,
    db: AsyncSession,
    semaphore: asyncio.Semaphore,
    *,
    force: bool = False,
    exclude_ids: set[str] | None = None,
) -> int:
    """Re-run metadata for existing resources of a channel.

    Returns the number of resources re-processed. By default bounded by
    ``MAX_BACKFILL_PER_FETCH`` and gated by ``_is_retry_eligible`` (the
    not_found/transient cooldowns) so automatic fetches don't hammer stale
    failures. With ``force=True`` (the explicit manual re-fetch option), every
    existing resource in the channel is reprocessed without a scan cap. This
    refreshes metadata from the live source and reruns torrent-file enrichment
    for linked and unlinked, batch and non-batch resources alike. Runs
    concurrently under ``semaphore`` (shared with the new-resource phase so
    one fetch cycle bounds total in-flight metadata work).
    """
    now = utcnow()
    criteria = FileResource.channel_id == channel.id
    if force:
        criteria = FileResource.channel_id == channel.id
    if exclude_ids:
        criteria = and_(criteria, FileResource.id.not_in(exclude_ids))
    query = (
        select(FileResource)
        .where(criteria)
        .options(
            selectinload(FileResource.channel),
            selectinload(FileResource.series),
            selectinload(FileResource.movie),
            selectinload(FileResource.audio_work),
            selectinload(FileResource.collection),
        )
        .order_by(
            FileResource.last_metadata_attempt_at.asc().nullsfirst(),
            FileResource.created_at.asc(),
        )
    )
    if not force:
        query = query.limit(MAX_BACKFILL_SCAN)
    result = await db.execute(query)
    candidates = result.scalars().all()
    from app.services.resource_coverage import load_batch_coverage

    await load_batch_coverage(db, candidates)

    # Decide eligibility from the snapshot loaded above, then process the
    # eligible set concurrently. Per-task sessions update each resource
    # independently; the next fetch re-queries fresh state.
    cap = None if force else MAX_BACKFILL_PER_FETCH
    eligible_ids: list[str] = []
    for resource in candidates:
        if cap is not None and len(eligible_ids) >= cap:
            break
        unlinked = not (
            resource.series_id
            or resource.movie_id
            or resource.audio_work_id
            or resource.collection_id
        )
        if force or (
            unlinked and _is_retry_eligible(resource, now)
        ) or _is_linked_enrichment_eligible(resource, now):
            eligible_ids.append(resource.id)

    if eligible_ids:
        # Close the shared fetch session's transaction (releasing its read
        # locks) before the LLM-heavy per-resource gather below: each task
        # uses its own session, so holding this one open across minutes of
        # external calls only stalls concurrent writers and startup DDL
        # (PostgreSQL queues lock requests behind a waiting ALTER).
        await db.commit()
        await _gather_metadata(
            *(
                _process_resource_metadata(rid, channel.id, semaphore, force_refresh=True)
                for rid in eligible_ids
            )
        )
    return len(eligible_ids)


async def backfill_unmatched_resources_global(db: AsyncSession, limit: int = MAX_GLOBAL_BACKFILL_PER_RUN) -> int:
    """Re-run metadata for retry-eligible unmatched resources across ALL channels.

    Unlike ``_backfill_unmatched_resources`` (per-channel, piggybacked on each
    fetch), this is driven by a standalone scheduler job so metadata repair
    keeps progressing even when fetch jobs are slow or the feed is quiet. It
    shares ``_is_retry_eligible`` with the per-channel backfill, so the
    transient/not_found cooldowns prevent the two from double-processing the
    same resource within a backoff window.

    Unmatched resources still require an enabled metadata agent. Linked
    resources with an incomplete Channel contract are also considered so
    torrent enrichment and release-field write-back can finish without
    requiring a manual re-fetch.
    """
    now = utcnow()
    result = await db.execute(
        select(FileResource)
        .join(Channel, FileResource.channel_id == Channel.id)
        .options(
            selectinload(FileResource.channel),
            selectinload(FileResource.series),
            selectinload(FileResource.movie),
            selectinload(FileResource.audio_work),
            selectinload(FileResource.collection),
        )
        .where(
            or_(
                Channel.metadata_agent_enabled.is_(True),
                FileResource.series_id.isnot(None),
                FileResource.movie_id.isnot(None),
                FileResource.audio_work_id.isnot(None),
                FileResource.collection_id.isnot(None),
            ),
        )
        .order_by(
            FileResource.last_metadata_attempt_at.asc().nullsfirst(),
            FileResource.created_at.asc(),
        )
        .limit(MAX_GLOBAL_BACKFILL_SCAN)
    )
    candidates = result.scalars().all()
    from app.services.resource_coverage import load_batch_coverage

    await load_batch_coverage(db, candidates)
    if not candidates:
        return 0

    # Decide eligibility from the loaded snapshot, then process the eligible
    # set concurrently. Each task loads its resource + channel by PK in its
    # own session (cheap vs the agent loop), so the channel prefetch the old
    # sequential version needed is no longer necessary.
    eligible: list[tuple[str, str]] = []  # (resource_id, channel_id)
    for resource in candidates:
        if len(eligible) >= limit:
            break
        unlinked = not (
            resource.series_id
            or resource.movie_id
            or resource.audio_work_id
            or resource.collection_id
        )
        if (
            unlinked
            and resource.channel
            and resource.channel.metadata_agent_enabled
            and _is_retry_eligible(resource, now)
        ) or _is_linked_enrichment_eligible(resource, now):
            eligible.append((resource.id, resource.channel_id))

    if eligible:
        # Same reasoning as _backfill_unmatched_resources: release this
        # session's locks before the long metadata gather; per-task sessions
        # persist all results.
        await db.commit()
        semaphore = asyncio.Semaphore(MAX_METADATA_CONCURRENCY)
        await _gather_metadata(
            *(
                _process_resource_metadata(rid, cid, semaphore, force_refresh=True)
                for rid, cid in eligible
            )
        )
    return len(eligible)


async def reconcile_stale_raw_episodes(
    db: AsyncSession, limit: int = 500, *, return_resource_ids: bool = False
) -> int | list[str]:
    """Re-run history/arithmetic reconciliation for linked resources.

    A resource linked while its work had no usable per-season counts keeps
    ``episode_confidence NULL/"raw"`` with a possibly-absolute episode number
    forever (reconcile only runs on link paths). Once the work's counts are
    later filled (per-season ``number_of_episodes`` at creation/refresh, or a
    legacy row's inert ``seasons`` column via backfill scripts), this sweep
    converts the stale numbers via the shared
    :func:`apply_episode_reconcile` — same semantics as every link path.

    Manual rows are immutable.  History-backed reconciliation may also repair
    ``ambiguous`` rows and previously-clamped ``reconciled`` rows.  The legacy
    arithmetic pass remains limited to raw/NULL values whose episode exceeds
    the linked season count.  Returns the changed count by default; callers
    that need the affected resource ids may request them. Changes and publication
    events commit together; automatic consumers retain historical exclusions.
    """
    from app.models.series import TVSeries
    from app.services.episode_history import apply_episode_history_reconcile
    from app.services.metadata_episode_reconcile import (
        _RECONCILE_TOLERANCE,
        apply_episode_reconcile,
        seasons_map_for_work,
    )
    from app.services.task_queue import require_execution_ownership

    await require_execution_ownership()
    resources = (
        await db.execute(
            select(FileResource)
            .where(
                FileResource.series_id.isnot(None),
                FileResource.is_batch.is_(False),
                FileResource.episode.isnot(None),
                FileResource.episode_confidence.is_distinct_from("manual"),
            )
            .order_by(FileResource.episode.desc())
            .limit(limit)
        )
    ).scalars().all()
    if not resources:
        return [] if return_resource_ids else 0
    series_rows = (
        await db.execute(
            select(TVSeries).where(
                TVSeries.id.in_({r.series_id for r in resources})
            )
        )
    ).scalars().all()
    maps = {s.id: seasons_map_for_work(s) for s in series_rows}
    history_ranges: dict[tuple[str, str], tuple[int, int]] = {}
    for resource in resources:
        absolute = resource.absolute_episode or resource.episode
        key = (resource.series_id, resource.channel_id)
        lower, upper = history_ranges.get(key, (absolute, absolute))
        history_ranges[key] = (min(lower, max(1, absolute - 2)), max(upper, absolute))
    history_scope = or_(*(
        and_(
            FileResource.series_id == series_id,
            FileResource.channel_id == channel_id,
            FileResource.absolute_episode >= lower,
            FileResource.absolute_episode < upper,
        )
        for (series_id, channel_id), (lower, upper) in history_ranges.items()
    ))
    history_rows = (
        await db.execute(
            select(FileResource)
            .where(
                history_scope,
                FileResource.is_batch.is_(False),
                FileResource.absolute_episode.isnot(None),
                FileResource.season.isnot(None),
                FileResource.episode.isnot(None),
                FileResource.episode_confidence.in_(["manual", "reconciled"]),
            )
            .order_by(FileResource.absolute_episode.desc(), FileResource.created_at.desc())
        )
    ).scalars().all()
    changed_ids: list[str] = []
    for r in resources:
        smap = maps.get(r.series_id) or {}
        if await apply_episode_history_reconcile(
            db, r, seasons_map=smap, history_rows=history_rows
        ):
            changed_ids.append(r.id)
            continue
        if r.episode_confidence not in (None, "raw"):
            continue
        season_count = smap.get(r.season)
        if season_count is None or r.episode <= season_count + _RECONCILE_TOLERANCE:
            continue  # no basis, or already looks per-season (nothing to do)
        if apply_episode_reconcile(r, smap):
            changed_ids.append(r.id)
    if changed_ids:
        from app.services.resource_publication import publish_resource

        changed = set(changed_ids)
        # Acquire channel counters in a consistent order across concurrent sweeps.
        for row in sorted(resources, key=lambda row: (row.channel_id, row.id)):
            if row.id in changed:
                await require_execution_ownership()
                await publish_resource(db, row.id, kind="metadata")
        await require_execution_ownership()
        await db.commit()
    return changed_ids if return_resource_ids else len(changed_ids)



async def fetch_channel_resources(channel: Channel, db: AsyncSession, *, force: bool = False) -> dict:
    """Fetch RSS feed for a channel, parse entries, store new FileResources,
    link metadata, and enqueue agent runs for active agents.

    Returns dict with counts + list of new resource IDs.

    ``force`` bypasses the not_found/transient cooldowns in the backfill phase
    (so a manual fetch reprocesses unresolved items instead of skipping them).
    """
    from app.services.task_queue import ExecutionOwnershipLostError, require_execution_ownership

    await require_execution_ownership()
    channel.last_fetch_status = "running"
    channel.last_fetch_error = None
    await db.commit()

    # 1. Fetch RSS (30s timeout). A feed outage no longer aborts the job: the
    # backfill (step 3) still re-runs retry-eligible unmatched resources so
    # repair progresses even when the feed is temporarily unreachable.
    feed = None
    feed_error: str | None = None
    try:
        feed = await asyncio.wait_for(
            asyncio.to_thread(_parse_feed_sync, channel.url),
            timeout=30,
        )
    except Exception as e:
        logger.warning("[fetch:%s] feed fetch failed: %s", channel.id, e)
        feed_error = str(e)[:2000]

    await require_execution_ownership()
    if feed is not None and feed.bozo and not feed.entries:
        exc = getattr(feed, "bozo_exception", None)
        feed_error = f"Failed to fetch RSS feed '{channel.url}': {exc or 'unknown error'}"
        logger.warning("[fetch:%s] %s", channel.id, feed_error)
        feed = None

    if feed_error is not None:
        channel.status = "error"
        channel.last_fetch_status = "failed"
        channel.last_fetch_error = feed_error
        await db.commit()

    entries = feed.entries if feed is not None else []
    logger.debug("[fetch:%s] Feed read: %d entries", channel.id, len(entries))
    # Note: an empty feed no longer short-circuits — the backfill phase below
    # still re-runs retry-eligible unmatched resources, so a transiently empty
    # feed still makes repair progress. The new-entry loop is simply a no-op.

    # 2. Existing GUIDs for dedup
    result = await db.execute(
        select(FileResource.guid).where(FileResource.channel_id == channel.id)
    )
    existing_guids = {row[0] for row in result.all()}

    column_names = {c.name for c in FileResource.__table__.columns}
    new_count = 0
    new_resource_ids: list[str] = []

    for entry in entries:
        await require_execution_ownership()
        guid = getattr(entry, "id", None) or entry.get("link") or entry.get("title", "")
        if not guid or guid in existing_guids:
            continue

        title = entry.get("title", "")
        logger.debug("[fetch:%s] New entry: guid=%s title=%r", channel.id, guid, title[:120])

        entry_dict = _entry_to_dict(entry)

        # Parse via field_mapping
        parsed: dict = {}
        if channel.field_mapping:
            try:
                parsed = parse_entry(entry_dict, channel.field_mapping, entry.get("description"))
                parsed = {k: v for k, v in parsed.items() if v is not None}
            except Exception as e:
                logger.debug("[fetch:%s] Field mapping failed: guid=%s error=%s", channel.id, guid, e)
                parsed = {}
        # Conservative post-parse repair: fix bracket leaks in title_cn/title_en
        # (multi-bracket titles like "[Group][Station]Work / Alt - EP") and fill
        # tech fields the LLM-regexes miss (1920x1080, bare WEB, AACx2). No-op
        # for resources the field_mapping already parsed cleanly.
        parsed = normalize_parsed_fields(title, parsed)
        # New mappings may emit the plural field directly.  Keep the legacy
        # scalar column populated as a compatibility/raw representation while
        # the canonical list is used by downstream services.
        from app.services.subtitle_groups import join_legacy_subtitle_group
        if parsed.get("subtitle_groups") and not parsed.get("subtitle_group"):
            parsed["subtitle_group"] = join_legacy_subtitle_group(parsed["subtitle_groups"])
        if parsed.get("subtitle_group"):
            from app.services.subtitle_groups import resolve_subtitle_groups
            groups, group_source = await resolve_subtitle_groups(db, parsed["subtitle_group"])
            parsed["subtitle_groups"] = groups
            parsed["subtitle_groups_source"] = group_source
        parsed = {k: v for k, v in parsed.items() if v is not None}

        # Pop explicit fields
        fm_torrent_url = parsed.pop("torrent_url", None) or None
        fm_detail_url = parsed.pop("detail_url", None) or None
        fm_published_at = parsed.pop("published_at", None) or None
        fm_title_cn = parsed.pop("title_cn", None) or None
        fm_title_en = parsed.pop("title_en", None) or None

        torrent_url_auto, _ = _extract_download_urls(entry)
        # Prefer auto-detected download URL (enclosures/magnets) over field-mapped,
        # because field_mapping may point to a non-download URL (e.g. detail page <link>).
        torrent_url = torrent_url_auto or fm_torrent_url
        if not torrent_url:
            logger.warning("Skipping entry '%s': no torrent/magnet URL found", guid)
            continue

        detail_url = fm_detail_url or entry.get("link")
        published_at_val = fm_published_at or _extract_published_at(entry)

        resource = FileResource(
            channel_id=channel.id,
            guid=guid,
            title_raw=title,
            torrent_url=torrent_url,
            detail_url=detail_url,
            published_at=published_at_val,
            parsed_at=utcnow(),
            title_cn=fm_title_cn,
            title_en=fm_title_en,
            **{k: v for k, v in parsed.items() if k in column_names and k not in _EXPLICIT_RESOURCE_COLS},
        )
        # Pre-parser: heuristic batch detection from the raw title. Runs before
        # the LLM so downstream logic (filtering, dedup) still sees ``is_batch``
        # even when the metadata agent is disabled or fails. The LLM may later
        # refine these values in ``UnifiedMetadataAgent._apply_to_resource``.
        from app.services.resource_parser import (
            detect_absolute_episode,
            detect_batch,
            detect_season_span,
            detect_subtitle_langs,
            extract_compilation_work_title,
        )
        pre_is_batch, pre_start, pre_end = detect_batch(title)
        if pre_is_batch:
            resource.is_batch = True
            # Title-regex hits default to a single-season pack; torrent
            # analysis (maybe_inspect_torrent) may later refine this to
            # multi_season/franchise, which only it can produce.
            resource.batch_scope = "season"
            # A batch resource must not carry a stray single ``episode``
            # (field_mapping may have parsed a year/resolution/title number
            # as one) — batches are aggregated ranges, matching the LLM-path
            # invariant in ``metadata_repository``.
            resource.episode = None
            if pre_start is not None:
                resource.episode_start = pre_start
            if pre_end is not None:
                resource.episode_end = pre_end
            # Whole-run markers ("全N季"/"N-M季") spell out the covered
            # seasons in the title itself: record them as multi-season
            # coverage so the batch is dispatchable even before (or without)
            # torrent content detection, which may later refine/overwrite.
            season_span = detect_season_span(title)
            if season_span is not None and len(season_span) >= 2:
                resource.batch_scope = "multi_season"
                resource.batch_seasons = season_span
        # Compilation/archive torrents ("[整理搬运] 猫眼三姐妹／猫之眼：TV动画+剧场版...")
        # bundle an entire work. Extract the primary work name as the search
        # title so the resource can link to that work (via the title index or
        # local FTS) and flag it as a batch, without needing the LLM to parse
        # the long descriptive blob.
        compilation_work = extract_compilation_work_title(title)
        if compilation_work:
            resource.is_batch = True
            # The title layer cannot subdivide a compilation pack; default to
            # "season" — torrent analysis may refine it (e.g. to franchise).
            resource.batch_scope = "season"
            resource.search_title = compilation_work
        # Subtitle language pre-fill. Store an empty list (rather than None)
        # once parsed, so downstream code can distinguish "never parsed" from
        # "no explicit marking".
        resource.subtitle_langs = detect_subtitle_langs(title)
        # NN(MM) double-labeled episode. When the title spells out both the
        # per-season number and the absolute count (e.g. "13(85)"), take the
        # per-season one and stash the absolute for audit / manual review.
        # This runs before the LLM so the MetadataAgent never sees the
        # ambiguity — see _reconcile_episode for the LLM-driven case.
        pre_ep, pre_abs = detect_absolute_episode(title)
        if pre_ep is not None:
            resource.episode = pre_ep
            resource.absolute_episode = pre_abs
            resource.episode_confidence = "reconciled"
        db.add(resource)
        await db.flush()
        from app.services.resource_publication import publish_resource

        await publish_resource(db, resource.id, kind="created")
        await require_execution_ownership()
        # Commit the new resource immediately so the SQLite write lock is
        # released *before* the metadata ReAct loop below. agent.process runs
        # many LLM + external search calls (tens of messages per resource when
        # a source misbehaves and can take minutes; holding a
        # write transaction open across that blocks every other writer -
        # including channel edits, which surface as "database is locked" /
        # requests that never return. The metadata result is persisted by a
        # fresh short transaction on the next commit.
        await db.commit()

        # Phase A: the resource row is created and committed above. The slow
        # metadata + poster work is deferred to Phase B (below) so this loop
        # stays fast and never holds the shared fetch session across an agent
        # run - the same "release the write lock before metadata" property
        # the inline version had, now also with real concurrency.
        existing_guids.add(guid)
        new_resource_ids.append(resource.id)
        new_count += 1
        logger.debug(
            "[fetch:%s] Committed resource %s (%d/%d new so far)",
            channel.id,
            resource.id,
            new_count,
            len(entries),
        )

    # Phase B: run metadata + poster download for the new resources
    # concurrently. Each task uses its own DB session (see
    # ``_process_resource_metadata``) so the slow LLM/search work doesn't
    # hold this shared fetch session's write lock. The semaphore is shared
    # with the backfill phase below so one fetch cycle bounds total in-flight
    # metadata work to ``MAX_METADATA_CONCURRENCY``.
    semaphore = asyncio.Semaphore(MAX_METADATA_CONCURRENCY)
    if new_resource_ids:
        await _gather_metadata(
            *(
                _process_resource_metadata(rid, channel.id, semaphore)
                for rid in new_resource_ids
            )
        )

    # 3. Backfill: re-run metadata for retry-eligible unmatched resources.
    # Existing resources are skipped by the GUID dedup in step 2, so without
    # this phase a transient failure (timeout / LLM-format error) or a source
    # that later improves would never get a second chance.
    backfilled_count = 0
    try:
        backfilled_count = await _backfill_unmatched_resources(
            channel,
            db,
            semaphore,
            force=force,
            # New entries already completed the same metadata/torrent pass in
            # Phase B. A force re-fetch covers all pre-existing rows without
            # paying for every newly-seen entry twice in the same job.
            exclude_ids=set(new_resource_ids),
        )
    except ExecutionOwnershipLostError:
        raise
    except Exception as e:
        logger.warning("[fetch:%s] backfill phase failed: %s", channel.id, e)

    await require_execution_ownership()
    # Finalize channel status - only mark success when the feed fetch succeeded.
    if feed_error is None:
        channel.last_fetched_at = utcnow()
        channel.last_fetch_status = "success"
        channel.status = "active"
        channel.last_fetch_error = None

    await db.commit()

    # Enqueue agent runs (fire-and-forget)
    from app.services.task_queue import task_queue
    for agent in channel.agents:
        await require_execution_ownership()
        if agent.status != "active":
            continue
        try:
            await task_queue.enqueue(
                "run_agent",
                f"agent:{agent.id}",
                {"agent_id": agent.id, "automatic": True},
            )
        except Exception as e:
            logger.warning("Failed to enqueue run_agent for %s: %s", agent.id, e)

    return {
        "status": "error" if feed_error is not None else ("success" if new_count > 0 else "unchanged"),
        "total": len(entries),
        "new_count": new_count,
        "new_resource_ids": new_resource_ids,
        "backfilled_count": backfilled_count,
        "error": feed_error,
    }
