"""FileResource API routes."""

import hashlib
import json
import logging
from collections import Counter
from pathlib import Path

from fastapi import APIRouter, Depends, Query
from fastapi.responses import JSONResponse, StreamingResponse
from sqlalchemy import func, or_, select, update
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.database import async_session_factory, get_db
from app.models.channel import Channel
from app.models.download_notification import DownloadNotification
from app.models.download_task import DownloadTask
from app.models.downloader import DownloaderInstance
from app.models.file_resource import FileResource
from app.models.metadata_cache import METADATA_CACHE_GENERATION, MetadataCache

# Aliased: several endpoint functions do function-local ``from ... import
# TVSeries/Movie``, which would shadow a same-named module-level import
# (UnboundLocalError) inside those functions.
from app.models.movie import Movie as _Movie
from app.models.resource_work_link import ResourceWorkLink
from app.models.series import TVSeries as _TVSeries
from app.schemas.common import api_json, paginated_response, success_response
from app.schemas.file_resource import (
    EpisodeCorrectionRequest,
    FileResourceDetailResponse,
    FileResourceResponse,
    MagnetResolveRetryRequest,
    ResourceAssociationUpdateRequest,
    ResourceFilesResponse,
    ResourceParseCorrectionRequest,
)
from app.services import task_queue as task_queue_module  # live queue singleton (replaced at startup)
from app.services.agent_resource_requests import request_channel_resources, wake_agents
from app.services.metadata_cache_store import cache_identity, store_cache
from app.services.metadata_service import fetch_and_link_metadata
from app.services.torrent_inspect import (
    ensure_torrent_cached,
    fetch_torrent_file,
    maybe_inspect_torrent,
    parse_torrent_files,
)

router = APIRouter()

logger = logging.getLogger(__name__)

_BATCH_ANALYSIS_SOURCE = "batch_file_analysis:v4"


async def _latest_task_status_by_resource(
    db: AsyncSession, resources: list[FileResource]
) -> dict[str, str]:
    """Return the effective dispatch outcome per resource, in two queries.

    The raw task status lies about completion: organize cleanup
    (``task_cleanup.delete_task_after_organize``) flips a *completed* task to
    ``cancelled`` after moving its files into the library, and the progress
    sync does the same when the torrent leaves the daemon. ``completed_at``
    is the reliable completion marker (same semantics as
    ``_task_occupies_download_slot`` in agent_service). Effective outcomes:

    - ``organized`` — latest task completed and its OrganizePlan is done
    - ``completed`` — completed, plan missing/not done
    - ``cancelled`` — only when ``completed_at`` is NULL (genuine cancel)
    - anything else passes through (pending/queued/downloading/paused/error)
    """
    resource_ids = [resource.id for resource in resources]
    if not resource_ids:
        return {}
    rows = (await db.execute(
        select(
            DownloadTask.id,
            DownloadTask.file_resource_id,
            DownloadTask.status,
            DownloadTask.completed_at,
            DownloadTask.created_at,
        ).where(DownloadTask.file_resource_id.in_(resource_ids))
    )).all()
    latest: dict[str, tuple[object, str, str, object]] = {}
    for task_id, resource_id, status, completed_at, created_at in rows:
        current = latest.get(resource_id)
        if current is None or created_at > current[0]:
            latest[resource_id] = (created_at, task_id, status, completed_at)

    # Second query: organize-plan state for the completed latest tasks.
    completed_task_ids = [
        task_id
        for _, task_id, _status, completed_at in latest.values()
        if completed_at is not None
    ]
    plan_status_by_task: dict[str, str | None] = {}
    if completed_task_ids:
        from app.models.download_notification import DownloadNotification
        from app.models.organize_plan import OrganizePlan

        plan_rows = (await db.execute(
            select(DownloadNotification.download_task_id, OrganizePlan.status)
            .select_from(DownloadNotification)
            .outerjoin(
                OrganizePlan,
                OrganizePlan.notification_id == DownloadNotification.id,
            )
            .where(DownloadNotification.download_task_id.in_(completed_task_ids))
        )).all()
        plan_status_by_task = {task_id: plan_status for task_id, plan_status in plan_rows}

    outcome: dict[str, str] = {}
    for resource_id, (_created, task_id, status, completed_at) in latest.items():
        if completed_at is not None:
            outcome[resource_id] = (
                "organized"
                if plan_status_by_task.get(task_id) == "done"
                else "completed"
            )
        else:
            outcome[resource_id] = status
    return outcome


async def _pending_decision_resource_ids(
    db: AsyncSession, channel_id: str, resources: list[FileResource]
) -> set[str]:
    """Return page resources that are candidates of a pending PendingDecision
    of any agent on this channel."""
    resource_ids = {resource.id for resource in resources}
    if not resource_ids:
        return set()
    from app.models.agent import Agent
    from app.models.pending_decision import PendingDecision

    pending_rows = (await db.execute(
        select(PendingDecision.candidates).where(
            PendingDecision.status == "pending",
            PendingDecision.agent_id.in_(
                select(Agent.id).where(Agent.channel_id == channel_id).scalar_subquery()
            ),
        )
    )).scalars().all()
    candidate_ids: set[str] = set()
    for candidates in pending_rows:
        candidate_ids.update(candidates or [])
    return resource_ids & candidate_ids


def _serialize_list_resource(
    resource: FileResource,
    task_status_by_id: dict[str, str],
    pending_decision_ids: set[str],
) -> dict:
    payload = FileResourceResponse.model_validate(resource)
    status = task_status_by_id.get(resource.id)
    return payload.model_copy(
        update={
            "has_download_task": status is not None,
            "download_status": status,
            "pending_decision": resource.id in pending_decision_ids,
        }
    ).model_dump()


def _batch_analysis_fingerprint(resource: FileResource, files: list[dict]) -> str:
    payload = {
        "version": 4,
        "resource_id": resource.id,
        "title": resource.search_title or resource.title_cn or resource.title_raw,
        "files": [(item.get("name"), item.get("size")) for item in files],
    }
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


async def _store_batch_analysis(key: str, payload: dict) -> None:
    from app.database import retry_on_lock

    async def attempt():
        async with async_session_factory() as session:
            try:
                await store_cache(
                    session, title=key, source=_BATCH_ANALYSIS_SOURCE,
                    content_type="batch_analysis", metadata_json=payload,
                )
                await session.commit()
            except Exception:
                await session.rollback()
                raise

    await retry_on_lock(attempt)


async def _retry_torrent_cache(db: AsyncSession, resource_id: str) -> None:
    """Best-effort .torrent re-cache before a manual-confirmation rerun.

    The targeted agent rerun following a manual correction reuses the cached
    .torrent to rebuild file assignments; when the cache is missing (the
    original fetch failed) the rerun would settle nothing, so re-download it
    here. Only fires when ``torrent_file`` is missing (or its file is gone)
    and ``torrent_url`` is a plain http(s) direct link. Any failure is
    logged and swallowed — this must never block the confirmation flow.
    """
    try:
        resource = await db.get(FileResource, resource_id)
        if resource is None:
            return
        cached = resource.torrent_file
        if cached and Path(cached).exists():
            return
        url = resource.torrent_url or ""
        if not url.startswith(("http://", "https://")):
            return
        await ensure_torrent_cached(resource)
        await maybe_inspect_torrent(db, resource)
        await db.commit()
    except Exception:  # noqa: BLE001 — best-effort, never blocks the flow
        logger.warning(
            "[resources] torrent re-cache failed for %s", resource_id, exc_info=True
        )

# Eager-load set for single-resource responses that serialize the batch
# enrichment tables (FileResourceDetailResponse). List endpoints keep using
# the lean FileResourceResponse and must NOT validate against this model.
_DETAIL_LOAD_OPTIONS = [
    selectinload(FileResource.series).selectinload(_TVSeries.collection),
    selectinload(FileResource.movie).selectinload(_Movie.collection),
    selectinload(FileResource.audio_work),
    selectinload(FileResource.collection),
    selectinload(FileResource.work_links).selectinload(ResourceWorkLink.series),
    selectinload(FileResource.work_links).selectinload(ResourceWorkLink.movie),
    selectinload(FileResource.file_assignments),
]


@router.get("/channels/{channel_id}/resources")
async def list_resources(
    channel_id: str,
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100),
    grouped: bool = Query(False),
    matched: bool | None = Query(
        None,
        description="Filter by link state: true=linked to a work, false=unmatched.",
    ),
    db: AsyncSession = Depends(get_db),
):
    ch = await db.get(Channel, channel_id)
    if not ch:
        return JSONResponse(
            status_code=404,
            content={"success": False, "data": None, "error": {"code": "NOT_FOUND", "message": "Channel not found"}},
        )
    base_q = select(FileResource).where(FileResource.channel_id == channel_id)
    # Filter by metadata link state so the channel page can show parsed vs
    # unparsed resources in separate tabs. In grouped mode, matched=True drops
    # the synthetic "unknown" bucket (its count query returns 0).
    if matched is True:
        base_q = base_q.where(
            or_(
                FileResource.series_id.isnot(None),
                FileResource.movie_id.isnot(None),
                FileResource.audio_work_id.isnot(None),
            )
        )
    elif matched is False:
        base_q = base_q.where(
            FileResource.series_id.is_(None),
            FileResource.movie_id.is_(None),
            FileResource.audio_work_id.is_(None),
        )

    if grouped:
        # Paginate by WORK GROUP (not by row). A group is a TVSeries, a Movie,
        # or the synthetic "unknown" bucket for resources without linked
        # metadata. Groups are ordered by their most recent
        # ``published_at`` (or ``created_at`` as a fallback), then paginated;
        # every resource in a group on the current page is returned so the
        # frontend can render the whole work without cross-page splitting.
        pub_col = func.coalesce(FileResource.published_at, FileResource.created_at)

        # Aggregate one row per (series_id / movie_id / unknown) with the max
        # publish time. We do it in three lightweight queries and merge in
        # Python — the group count is bounded (# of works in the channel) so
        # this stays cheap even for feeds with tens of thousands of rows.
        series_groups = (await db.execute(
            select(FileResource.series_id, func.max(pub_col))
            .where(FileResource.channel_id == channel_id, FileResource.series_id.isnot(None))
            .group_by(FileResource.series_id)
        )).all()
        movie_groups = (await db.execute(
            select(FileResource.movie_id, func.max(pub_col))
            .where(FileResource.channel_id == channel_id, FileResource.movie_id.isnot(None))
            .group_by(FileResource.movie_id)
        )).all()
        audio_groups = (await db.execute(
            select(FileResource.audio_work_id, func.max(pub_col))
            .where(
                FileResource.channel_id == channel_id,
                FileResource.audio_work_id.isnot(None),
            )
            .group_by(FileResource.audio_work_id)
        )).all()
        unknown_last = (await db.execute(
            select(func.max(pub_col), func.count())
            .where(
                FileResource.channel_id == channel_id,
                FileResource.series_id.is_(None),
                FileResource.movie_id.is_(None),
                FileResource.audio_work_id.is_(None),
            )
        )).one()

        entries: list[tuple[str, str | None, object]] = []
        for sid, ts in series_groups:
            entries.append(("series", sid, ts))
        for mid, ts in movie_groups:
            entries.append(("movie", mid, ts))
        for aid, ts in audio_groups:
            entries.append(("audio", aid, ts))
        # The synthetic "unknown" bucket holds unmatched resources; it is only
        # relevant when the caller wants unmatched or all resources. Skip it for
        # matched=True so the parsed tab shows only linked work-groups.
        if matched is not True and unknown_last[1] and unknown_last[1] > 0:
            entries.append(("unknown", None, unknown_last[0]))

        # Sort by last_update desc; None values sink to the end for stability.
        from datetime import datetime as _dt
        _epoch = _dt.min
        entries.sort(key=lambda e: e[2] or _epoch, reverse=True)

        total_groups = len(entries)
        offset = (page - 1) * page_size
        page_entries = entries[offset : offset + page_size]

        # Load resources for the groups on this page (bulk-load per bucket).
        series_ids_on_page = [tid for typ, tid, _ in page_entries if typ == "series"]
        movie_ids_on_page = [tid for typ, tid, _ in page_entries if typ == "movie"]
        audio_ids_on_page = [tid for typ, tid, _ in page_entries if typ == "audio"]
        has_unknown_on_page = any(typ == "unknown" for typ, _, _ in page_entries)

        resource_by_series: dict[str, list[FileResource]] = {}
        resource_by_movie: dict[str, list[FileResource]] = {}
        resource_by_audio: dict[str, list[FileResource]] = {}
        unknown_resources: list[FileResource] = []

        _load_opts = (
            selectinload(FileResource.series).selectinload(_TVSeries.collection),
            selectinload(FileResource.movie).selectinload(_Movie.collection),
            selectinload(FileResource.audio_work),
            selectinload(FileResource.collection),
        )

        if series_ids_on_page:
            rs = (await db.execute(
                base_q.options(*_load_opts)
                .where(FileResource.series_id.in_(series_ids_on_page))
                .order_by(FileResource.published_at.desc())
            )).scalars().all()
            for r in rs:
                resource_by_series.setdefault(r.series_id, []).append(r)
        if movie_ids_on_page:
            rs = (await db.execute(
                base_q.options(*_load_opts)
                .where(FileResource.movie_id.in_(movie_ids_on_page))
                .order_by(FileResource.published_at.desc())
            )).scalars().all()
            for r in rs:
                resource_by_movie.setdefault(r.movie_id, []).append(r)
        if audio_ids_on_page:
            rs = (await db.execute(
                base_q.options(*_load_opts)
                .where(FileResource.audio_work_id.in_(audio_ids_on_page))
                .order_by(FileResource.published_at.desc())
            )).scalars().all()
            for r in rs:
                resource_by_audio.setdefault(r.audio_work_id, []).append(r)
        if has_unknown_on_page:
            unknown_resources = list((await db.execute(
                base_q.options(*_load_opts)
                .where(
                    FileResource.series_id.is_(None),
                    FileResource.movie_id.is_(None),
                    FileResource.audio_work_id.is_(None),
                )
                .order_by(FileResource.published_at.desc())
            )).scalars().all())

        page_resources = [
            resource
            for buckets in (
                resource_by_series.values(), resource_by_movie.values(),
                resource_by_audio.values(), [unknown_resources],
            )
            for resources in buckets
            for resource in resources
        ]
        task_status_by_id = await _latest_task_status_by_resource(db, page_resources)
        pending_decision_ids = await _pending_decision_resource_ids(db, channel_id, page_resources)

        out = []
        for typ, tid, last_ts in page_entries:
            if typ == "series":
                items = resource_by_series.get(tid, [])
                if not items:
                    continue
                s = items[0].series
                out.append({
                    "type": "series",
                    "id": tid,
                    "title": (s.original_title or s.title_cn or s.title_en or tid) if s else tid,
                    "poster_url": s.poster_url if s else None,
                    "last_update": last_ts,
                    "resources": [_serialize_list_resource(r, task_status_by_id, pending_decision_ids) for r in items],
                })
            elif typ == "movie":
                items = resource_by_movie.get(tid, [])
                if not items:
                    continue
                m = items[0].movie
                out.append({
                    "type": "movie",
                    "id": tid,
                    "title": (m.original_title or m.title_cn or m.title_en or tid) if m else tid,
                    "poster_url": m.poster_url if m else None,
                    "last_update": last_ts,
                    "resources": [_serialize_list_resource(r, task_status_by_id, pending_decision_ids) for r in items],
                })
            elif typ == "audio":
                items = resource_by_audio.get(tid, [])
                if not items:
                    continue
                a = items[0].audio_work
                out.append({
                    "type": "audio",
                    "id": tid,
                    "title": (a.original_title or a.title_cn or a.title_en or tid) if a else tid,
                    "poster_url": a.poster_url if a else None,
                    "last_update": last_ts,
                    "resources": [_serialize_list_resource(r, task_status_by_id, pending_decision_ids) for r in items],
                })
            else:  # unknown
                out.append({
                    "type": "unknown",
                    "id": None,
                    "title": "未识别",
                    "poster_url": None,
                    "last_update": last_ts,
                    "resources": [
                        _serialize_list_resource(r, task_status_by_id, pending_decision_ids)
                        for r in unknown_resources
                    ],
                })

        return success_response(
            {"groups": out},
            meta={"total": total_groups, "page": page, "page_size": page_size},
        )

    total_q = await db.execute(select(func.count()).select_from(base_q.subquery()))
    total = total_q.scalar_one()
    offset = (page - 1) * page_size
    result = await db.execute(
        base_q.options(
            selectinload(FileResource.series).selectinload(_TVSeries.collection),
            selectinload(FileResource.movie).selectinload(_Movie.collection),
            selectinload(FileResource.audio_work),
            selectinload(FileResource.collection),
        )
        .order_by(FileResource.published_at.desc())
        .offset(offset).limit(page_size)
    )
    resources = result.scalars().all()
    task_status_by_id = await _latest_task_status_by_resource(db, resources)
    pending_decision_ids = await _pending_decision_resource_ids(db, channel_id, resources)
    return paginated_response(
        [_serialize_list_resource(r, task_status_by_id, pending_decision_ids) for r in resources],
        total=total, page=page, page_size=page_size,
    )


# ---------------------------------------------------------------------------
# Field values — powers autocomplete for Filter DSL eq/ne inputs
# ---------------------------------------------------------------------------

# Only columns we actually let users filter on via the DSL are allowed. Numeric
# fields don't offer autocomplete (values are unbounded), and the JSON list
# column ``subtitle_langs`` needs a per-dialect unnest so we handle it below.
_AUTOCOMPLETE_STRING_FIELDS = {
    "subtitle_group", "resolution", "source", "video_codec", "audio_codec",
    "subtitle_type", "container", "title_cn", "title_en", "search_title",
}
_AUTOCOMPLETE_LIST_FIELDS = {"subtitle_langs", "subtitle_groups"}
_AUTOCOMPLETE_ALL = _AUTOCOMPLETE_STRING_FIELDS | _AUTOCOMPLETE_LIST_FIELDS


@router.get("/channels/{channel_id}/field-values")
async def list_channel_field_values(
    channel_id: str,
    field: str = Query(..., description="FileResource column to enumerate"),
    q: str = Query("", description="Case-insensitive prefix filter"),
    limit: int = Query(10, ge=1, le=50),
    db: AsyncSession = Depends(get_db),
):
    """Return the top-N distinct values of ``field`` for this channel.

    Powers the Filter DSL editor's autocomplete on ``eq/ne/contains/fuzzy``
    inputs so users can pick from real values in the feed while still typing
    anything they want. Whitelist-guarded to prevent leaking arbitrary
    columns. Ordered by frequency descending so the most common option (e.g.
    ``1080p``) surfaces first.
    """
    ch = await db.get(Channel, channel_id)
    if not ch:
        return JSONResponse(
            status_code=404,
            content={"success": False, "data": None,
                     "error": {"code": "NOT_FOUND", "message": "Channel not found"}},
        )
    if field not in _AUTOCOMPLETE_ALL:
        return JSONResponse(
            status_code=422,
            content={"success": False, "data": None,
                     "error": {"code": "VALIDATION_ERROR",
                               "message": f"unsupported field {field!r}"}},
        )

    prefix = (q or "").strip().lower()

    if field in _AUTOCOMPLETE_STRING_FIELDS:
        col = getattr(FileResource, field)
        stmt = (
            select(col, func.count().label("cnt"))
            .where(
                FileResource.channel_id == channel_id,
                col.isnot(None),
                col != "",
            )
        )
        if prefix:
            stmt = stmt.where(func.lower(col).like(f"{prefix}%"))
        stmt = stmt.group_by(col).order_by(func.count().desc()).limit(limit)
        rows = (await db.execute(stmt)).all()
        return success_response([r[0] for r in rows])

    # subtitle_langs — JSON array column. SQLite and PostgreSQL disagree on
    # how to unnest, so pull the JSON blobs and aggregate in Python. The
    # per-channel volume is small (thousands at most), so a fetch-and-count
    # in memory is fine and avoids dialect-specific SQL.
    column = getattr(FileResource, field)
    stmt = select(column).where(
        FileResource.channel_id == channel_id,
        FileResource.subtitle_langs.isnot(None),
    )
    rows = (await db.execute(stmt)).all()
    counter: Counter[str] = Counter()
    for (val,) in rows:
        if not val:
            continue
        for tag in val:
            if not isinstance(tag, str):
                continue
            t = tag.strip()
            if not t:
                continue
            if prefix and not t.lower().startswith(prefix):
                continue
            counter[t] += 1
    top = [tag for tag, _cnt in counter.most_common(limit)]
    return success_response(top)


@router.get("/resources/{resource_id}")
async def get_resource(resource_id: str, db: AsyncSession = Depends(get_db)):
    resource = await db.get(
        FileResource, resource_id, options=_DETAIL_LOAD_OPTIONS
    )
    if not resource:
        return JSONResponse(
            status_code=404,
            content={"success": False, "data": None, "error": {"code": "NOT_FOUND", "message": "Resource not found"}},
        )
    payload = FileResourceDetailResponse.model_validate(resource).model_dump()
    channel = await db.get(Channel, resource.channel_id)
    if channel is not None:
        from app.services.resource_confirmation import inspect_resource_confirmation

        confirmation = inspect_resource_confirmation(
            resource, channel.required_metadata_fields
        )
        payload["confirmation_kinds"] = list(confirmation.kinds)
        payload["missing_fields"] = list(confirmation.missing_fields)
    return success_response(payload)


@router.get("/resources/{resource_id}/metadata")
async def get_resource_metadata(resource_id: str, db: AsyncSession = Depends(get_db)):
    resource = await db.get(
        FileResource, resource_id,
        options=[
            selectinload(FileResource.series).selectinload(_TVSeries.collection),
            selectinload(FileResource.movie).selectinload(_Movie.collection),
            selectinload(FileResource.audio_work),
        ],
    )
    if not resource:
        return JSONResponse(
            status_code=404,
            content={"success": False, "data": None, "error": {"code": "NOT_FOUND", "message": "Resource not found"}},
        )

    channel = await db.get(Channel, resource.channel_id)
    try:
        await fetch_and_link_metadata(db, resource, channel)
        await db.commit()
    except Exception as e:
        await db.rollback()
        return JSONResponse(
            status_code=500,
            content={"success": False, "data": None, "error": {"code": "INTERNAL_SERVER_ERROR", "message": str(e)}},
        )

    await db.refresh(resource, ["series", "movie", "audio_work"])
    linked = None
    if resource.series:
        from app.schemas.series import TVSeriesResponse
        entity = TVSeriesResponse.model_validate(resource.series).model_dump()
        # Per-season episode counts so the episode-correction UI can prefill
        # the season from an absolute episode number client-side (mirrors
        # locate_absolute_episode on PATCH /resources/{id}/episode).
        entity["seasons"] = resource.series.seasons
        linked = {"type": "series", "entity": entity}
    elif resource.movie:
        from app.schemas.movie import MovieResponse
        linked = {"type": "movie", "entity": MovieResponse.model_validate(resource.movie).model_dump()}
    elif resource.audio_work:
        from app.schemas.audio_work import AudioWorkResponse
        linked = {"type": "audio", "entity": AudioWorkResponse.model_validate(resource.audio_work).model_dump()}

    return success_response({
        "resource_id": resource.id,
        "series_id": resource.series_id,
        "movie_id": resource.movie_id,
        "audio_work_id": resource.audio_work_id,
        "metadata_matched_at": resource.metadata_matched_at,
        "linked": linked,
    })


@router.patch("/resources/{resource_id}/episode")
async def correct_episode(
    resource_id: str,
    body: EpisodeCorrectionRequest,
    db: AsyncSession = Depends(get_db),
):
    """Record a user's manual episode number correction.

    Overwrites ``episode`` (per-season) and, when provided, ``season`` and
    ``absolute_episode`` (cross-season audit copy). Sets
    ``episode_confidence="manual"`` so downstream logic knows the value is
    hand-vetted — the metadata agent will not re-reconcile on the next run,
    and the Filter DSL can distinguish manual corrections via
    ``episode_confidence eq manual``.

    When the caller omits ``season`` but an absolute episode number is known
    and the linked series' per-season counts are available, the season (and
    episode, if also omitted) is derived via ``locate_absolute_episode`` —
    explicit values always win over the derivation.

    Re-runs the channel's active agents so a previously-ambiguous resource
    can be picked up immediately after correction.
    """
    resource = await db.get(FileResource, resource_id)
    if not resource:
        return JSONResponse(
            status_code=404,
            content={"success": False, "data": None,
                     "error": {"code": "NOT_FOUND", "message": "Resource not found"}},
        )

    resource.episode = body.episode
    # Only touch season when the caller explicitly sent it. That lets a user
    # fix the episode number without wiping the parsed season, mirroring the
    # preserve-when-omitted semantics used for absolute_episode below.
    if body.season is not None:
        resource.season = body.season
    # Only touch absolute_episode when the caller explicitly sent it. That
    # lets a user fix the per-season number without wiping the original
    # absolute value we captured during reconciliation.
    if body.absolute_episode is not None:
        resource.absolute_episode = body.absolute_episode

    # Derive the season from the absolute number when the caller did NOT
    # explicitly send a season: an absolute-across-seasons number plus the
    # known per-season counts pins down (season, episode) exactly. The
    # per-season model locates the number along the linked work's COLLECTION
    # members (and re-points the resource at the located season work); the
    # legacy fallback uses the linked row's own per-season counts. Explicit
    # values in the request always win — the derivation only fills fields the
    # caller left out.
    if (
        "season" not in body.model_fields_set
        and resource.series_id
        and resource.absolute_episode is not None
    ):
        from app.models.series import TVSeries
        from app.services.metadata_episode_reconcile import (
            locate_absolute_episode,
            seasons_map_for_work,
        )
        from app.services.metadata_service import (
            locate_absolute_episode_in_collection,
        )
        series_row = await db.get(TVSeries, resource.series_id)
        located_episode = None
        if series_row is not None:
            if series_row.collection_id:
                found = await locate_absolute_episode_in_collection(
                    db, series_row.collection_id, resource.absolute_episode
                )
                if found is not None:
                    member, located_episode = found
                    resource.series_id = member.id
                    resource.season = member.season_number
            if located_episode is None:
                seasons_map = seasons_map_for_work(series_row)
                located = locate_absolute_episode(resource.absolute_episode, seasons_map)
                if located is not None:
                    resource.season = located[0]
                    located_episode = located[1]
        if located_episode is not None and "episode" not in body.model_fields_set:
            resource.episode = located_episode

    resource.episode_confidence = "manual"

    # Capture the channel id before commit (the ORM object may be expired
    # after commit and ``resource`` is about to be re-fetched below).
    channel_id = resource.channel_id
    await db.flush()

    # Generalize the correction: siblings of the same work+channel still
    # queued as ambiguous/raw get the freshly-established numbering
    # convention applied immediately, so one manual fix heals the whole
    # release pattern instead of one row at a time.
    healed_ids: list[str] = []
    try:
        from app.services.episode_history import heal_sibling_episodes
        from app.services.metadata_episode_reconcile import seasons_map_for_work

        linked = await db.get(_TVSeries, resource.series_id) if resource.series_id else None
        healed_ids = await heal_sibling_episodes(
            db, resource,
            seasons_map=seasons_map_for_work(linked) if linked else {},
        )
    except Exception:
        logger.exception("[correct_episode] sibling heal failed for %s", resource_id)

    # Commit BEFORE enqueuing the agent re-run: run_agent runs in its own
    # session and only sees committed data. Enqueuing first creates a race
    # where the worker reads the pre-correction ``episode_confidence`` and
    # keeps the resource behind the Channel confirmation gate.
    requested_agent_ids = await request_channel_resources(db, channel_id, [resource_id, *healed_ids])
    await db.commit()

    # Re-cache a missing .torrent so the targeted rerun can rebuild file
    # assignments (best-effort, never blocks the flow).
    await _retry_torrent_cache(db, resource_id)

    # Re-trigger active agents on this channel so the corrected resource can
    # now pass the Channel confirmation gate and be dispatched. Pass the
    # resource id explicitly so run_agent does a *targeted* run against the
    # agent's current rules — bypassing the consumption watermark, since the
    # corrected resource may be old. The watermark is not advanced. Siblings
    # healed by the fresh convention ride along in the same targeted run.
    await wake_agents(requested_agent_ids, [resource_id, *healed_ids])

    # Re-fetch with relationships so Pydantic can serialize without lazy IO.
    resource = (await db.execute(
        select(FileResource)
        .where(FileResource.id == resource_id)
        .options(*_DETAIL_LOAD_OPTIONS)
    )).scalar_one()
    return success_response(FileResourceDetailResponse.model_validate(resource).model_dump())


async def _resolve_resource_files(
    db: AsyncSession, resource: FileResource
) -> tuple[list[dict], str]:
    """Resolve a resource's torrent file listing (shared by the files GET
    endpoint and the analyze-batch suggestions).

    Resolution order (first hit wins, recorded in ``source``):
    torrent_cache → torrent_fetch → downloader RPC → notification snapshot.
    Returns ``([], "none")`` when nothing is available. May commit (the live
    fetch persists the cache path).
    """
    # 1. Local .torrent cache.
    cached = resource.torrent_file
    if cached and Path(cached).exists():
        files = parse_torrent_files(cached)
        if files is not None:
            return files, "torrent_cache"

    # 2. Live fetch of an http(s) direct link (persist the cache path).
    url = resource.torrent_url or ""
    if url.startswith(("http://", "https://")):
        path = await fetch_torrent_file(url, resource.id)
        if path:
            resource.torrent_file = path
            await db.commit()
            files = parse_torrent_files(path)
            if files is not None:
                return files, "torrent_fetch"

    # 3. Latest download task → downloader RPC (best-effort, failures silent).
    task = (await db.execute(
        select(DownloadTask)
        .where(DownloadTask.file_resource_id == resource.id)
        .order_by(DownloadTask.created_at.desc())
        .limit(1)
    )).scalar_one_or_none()
    if task is not None and task.transmission_torrent_id is not None and task.downloader_id:
        downloader = await db.get(DownloaderInstance, task.downloader_id)
        if downloader is not None:
            from app.clients.downloader import get_downloader_client

            try:
                torrent_info = await get_downloader_client(
                    downloader
                ).get_torrent_files(task.transmission_torrent_id)
            except Exception:  # noqa: BLE001 — best-effort
                torrent_info = None
            if torrent_info and torrent_info.get("files"):
                return torrent_info["files"], "downloader"

    # 4. Frozen download-notification snapshot.
    notification = (await db.execute(
        select(DownloadNotification)
        .join(DownloadTask, DownloadNotification.download_task_id == DownloadTask.id)
        .where(DownloadTask.file_resource_id == resource.id)
        .order_by(DownloadNotification.created_at.desc())
        .limit(1)
    )).scalar_one_or_none()
    if notification is not None:
        files = (notification.payload or {}).get("files")
        if files:
            return files, "notification"

    return [], "none"


@router.get("/resources/{resource_id}/files")
async def get_resource_files(resource_id: str, db: AsyncSession = Depends(get_db)):
    """Return the resource's torrent file listing.

    Resolution order (first hit wins, recorded in ``source``):

    1. ``torrent_cache`` — a previously cached .torrent on disk.
    2. ``torrent_fetch`` — live-download the http(s) ``torrent_url`` (the
       local path is persisted back to ``resource.torrent_file``).
    3. ``downloader`` — the latest download task's downloader RPC.
    4. ``notification`` — the frozen download-notification snapshot.
    5. ``none`` — no source could produce a listing.
    """
    resource = await db.get(FileResource, resource_id)
    if not resource:
        return JSONResponse(
            status_code=404,
            content={"success": False, "data": None,
                     "error": {"code": "NOT_FOUND", "message": "Resource not found"}},
        )

    files, source = await _resolve_resource_files(db, resource)
    magnet_state = None
    if not files and (resource.torrent_url or "").startswith("magnet:"):
        magnet_state = {
            "status": resource.magnet_resolve_status,
            "error": resource.magnet_resolve_error,
            "attempts": resource.magnet_resolve_attempts,
            "updated_at": resource.magnet_resolve_updated_at,
            "trackers": resource.magnet_resolve_trackers,
        }
    return success_response(
        ResourceFilesResponse(
            files=files, source=source, magnet_resolve=magnet_state
        ).model_dump()
    )


@router.post("/resources/{resource_id}/magnet-resolve")
async def resolve_magnet_metadata(
    resource_id: str,
    body: MagnetResolveRetryRequest | None = None,
    db: AsyncSession = Depends(get_db),
):
    """Manual retry for magnet metadata resolution.

    Resets the failure state (attempts, error) and re-enqueues the background
    resolution job. Rejected with 422 when the resource is not a magnet link,
    libtorrent is unavailable, or the feature is disabled; 409 while a
    resolution is already pending/running.

    Optional body ``{"trackers": [...]}``: a validated custom tracker list
    persisted for the resolution attempt(s) (kept on failure, cleared on
    done); omitted/null/empty clears the stored list (defaults only).
    """
    from app.config import settings
    from app.services import magnet_resolve

    resource = await db.get(FileResource, resource_id)
    if not resource:
        return JSONResponse(
            status_code=404,
            content={"success": False, "data": None,
                     "error": {"code": "NOT_FOUND", "message": "Resource not found"}},
        )
    if not (resource.torrent_url or "").startswith("magnet:"):
        return JSONResponse(
            status_code=422,
            content={"success": False, "data": None,
                     "error": {"code": "VALIDATION_ERROR",
                               "message": "Resource is not a magnet link"}},
        )
    if magnet_resolve.lt is None:
        return JSONResponse(
            status_code=422,
            content={"success": False, "data": None,
                     "error": {"code": "VALIDATION_ERROR",
                               "message": "libtorrent is not installed on this server"}},
        )
    if not settings.magnet_resolve_enabled:
        return JSONResponse(
            status_code=422,
            content={"success": False, "data": None,
                     "error": {"code": "VALIDATION_ERROR",
                               "message": "Magnet metadata resolution is disabled"}},
        )
    if resource.magnet_resolve_status in ("pending", "running"):
        return JSONResponse(
            status_code=409,
            content={"success": False, "data": None,
                     "error": {"code": "INVALID_STATE",
                               "message": "Magnet resolution already in progress"}},
        )

    custom_trackers = None
    if body is not None and body.trackers:
        try:
            custom_trackers = magnet_resolve.validate_tracker_urls(body.trackers)
        except ValueError as e:
            return JSONResponse(
                status_code=422,
                content={"success": False, "data": None,
                         "error": {"code": "VALIDATION_ERROR", "message": str(e)}},
            )

    # The identity-map read can predate another worker's claim. Reset only
    # the observed generation, never a replacement attempt or active claim.
    result = await db.execute(
        update(FileResource)
        .where(
            FileResource.id == resource_id,
            FileResource.magnet_resolve_attempt_id == resource.magnet_resolve_attempt_id,
            FileResource.magnet_resolve_status == resource.magnet_resolve_status,
            FileResource.torrent_url == resource.torrent_url,
        )
        .values(
            magnet_resolve_trackers=custom_trackers,
            magnet_resolve_attempt_id=None,
            magnet_resolve_attempts=0,
            magnet_resolve_error=None,
        )
        .execution_options(synchronize_session=False)
    )
    if not result.rowcount:
        await db.rollback()
        return JSONResponse(
            status_code=409,
            content={"success": False, "data": None,
                     "error": {"code": "INVALID_STATE",
                               "message": "Magnet resolution changed; reload before retrying"}},
        )
    # Commit BEFORE enqueuing: the job's status claim runs in its own session
    # and must see the reset counters.
    await db.commit()
    await magnet_resolve.enqueue_resolution(resource.id)

    return success_response({
        "magnet_resolve": {
            "status": "pending",
            "error": None,
            "attempts": 0,
            "updated_at": resource.magnet_resolve_updated_at,
            "trackers": custom_trackers,
        }
    })


@router.post("/resources/{resource_id}/reparse-metadata")
async def reparse_resource_metadata(
    resource_id: str,
    db: AsyncSession = Depends(get_db),
):
    """Persist a reparse request before attempting its queue wakeup."""
    from app.services.resource_reparse_requests import create_request, wake_request

    resource = await db.get(FileResource, resource_id)
    if not resource:
        return JSONResponse(
            status_code=404,
            content={"success": False, "data": None,
                     "error": {"code": "NOT_FOUND", "message": "Resource not found"}},
        )
    request = await create_request(db, resource_id, resource.channel_id)
    await db.commit()
    if request is None:
        return JSONResponse(
            status_code=409,
            content={"success": False, "data": None,
                     "error": {"code": "ALREADY_RUNNING", "message": "Metadata reparse already pending"}},
        )
    await wake_request(request)
    return success_response({"reparse": {"status": "pending"}})


@router.put("/resources/{resource_id}/associations")
async def update_resource_associations(
    resource_id: str,
    body: ResourceAssociationUpdateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Apply the edit wizard's full desired state atomically.

    Validates every invariant (works existence, non-batch single-work cap,
    batch-scope derivation, placement membership / season / episode-run
    overlap), applies works + collection + assignments + generic fields in
    one transaction, then re-runs the channel's active agents as a targeted
    run (commit-first, watermark untouched — same convention as PATCH).
    Overlap violations return 422; continuity gaps are returned as warnings.
    """
    resource = await db.get(FileResource, resource_id)
    if not resource:
        return JSONResponse(
            status_code=404,
            content={"success": False, "data": None,
                     "error": {"code": "NOT_FOUND", "message": "Resource not found"}},
        )

    from app.services.resource_association import (
        AssociationValidationError,
        apply_association_update,
    )

    try:
        result = await apply_association_update(db, resource, body)
    except AssociationValidationError as e:
        await db.rollback()
        return JSONResponse(
            status_code=422,
            content={"success": False, "data": None,
                     "error": {"code": "VALIDATION_ERROR", "message": e.message}},
        )
    except Exception as e:  # noqa: BLE001 — unexpected failure
        await db.rollback()
        logger.exception("[associations] apply failed for %s", resource_id)
        return JSONResponse(
            status_code=500,
            content={"success": False, "data": None,
                     "error": {"code": "INTERNAL_SERVER_ERROR", "message": str(e)}},
        )

    channel_id = resource.channel_id
    requested_agent_ids = await request_channel_resources(db, channel_id, [resource_id])
    await db.commit()

    # Re-cache a missing .torrent so the targeted rerun can rebuild file
    # assignments (best-effort, never blocks the flow).
    await _retry_torrent_cache(db, resource_id)

    try:
        await task_queue_module.task_queue.enqueue(
            "refresh_resource_organize",
            f"resource-organize:{resource_id}",
            {"resource_id": resource_id},
        )
    except Exception:
        logger.exception("[associations] failed to enqueue organize refresh for %s", resource_id)

    await wake_agents(requested_agent_ids, [resource_id])

    resource = (await db.execute(
        select(FileResource)
        .where(FileResource.id == resource_id)
        .options(*_DETAIL_LOAD_OPTIONS)
    )).scalar_one()
    payload = FileResourceDetailResponse.model_validate(resource).model_dump()
    payload["warnings"] = result.warnings
    return success_response(payload)


@router.post("/resources/{resource_id}/analyze-batch")
async def analyze_resource_batch(
    resource_id: str,
    db: AsyncSession = Depends(get_db),
):
    """LLM suggestions for the wizard's file-mapping step (non-persistent).

    Re-runs the batch content analysis over the current listing and returns
    title-keyed work suggestions with per-file placements. Nothing is written;
    binding titles to concrete works happens client-side against the step-1
    association set.
    """
    resource = await db.get(FileResource, resource_id)
    if not resource:
        return JSONResponse(
            status_code=404,
            content={"success": False, "data": None,
                     "error": {"code": "NOT_FOUND", "message": "Resource not found"}},
        )

    files, source = await _resolve_resource_files(db, resource)
    if not files:
        return success_response({"suggestion": None, "listing_source": source})

    from app.services.batch_content_analysis import suggest_batch_content

    channel = await db.get(Channel, resource.channel_id)
    try:
        suggestion = await suggest_batch_content(db, resource, channel, files=files)
    except Exception as e:  # noqa: BLE001 — best-effort analysis
        logger.warning("[analyze-batch] failed for %s: %s", resource_id, e)
        suggestion = None

    return success_response({
        "suggestion": suggestion,
        "listing_source": source,
    })


@router.post("/resources/{resource_id}/analyze-batch-stream")
async def analyze_resource_batch_stream(
    resource_id: str,
    force: bool = Query(False),
    db: AsyncSession = Depends(get_db),
):
    """Stream or join one cached batch analysis for the wizard."""
    resource = await db.get(FileResource, resource_id)
    if not resource:
        return JSONResponse(
            status_code=404,
            content={"success": False, "data": None,
                     "error": {"code": "NOT_FOUND", "message": "Resource not found"}},
        )
    files, source = await _resolve_resource_files(db, resource)
    fingerprint = _batch_analysis_fingerprint(resource, files)

    cached = None
    if not force:
        cached = (await db.execute(select(MetadataCache).where(
            *cache_identity(fingerprint, _BATCH_ANALYSIS_SOURCE),
            MetadataCache.generation == METADATA_CACHE_GENERATION,
        ))).scalar_one_or_none()

    def emit(kind: str, **payload):
        return f"data: {json.dumps(api_json({'type': kind, **payload}), ensure_ascii=False)}\n\n"

    if cached is not None:
        async def cached_events():
            yield emit("status", message="已复用文件解析缓存")
            yield emit("result", **cached.metadata_json)
        return StreamingResponse(cached_events(), media_type="text/event-stream")

    from app.services import task_queue as task_queue_module
    from app.services.task_queue import JobStatus

    queue = task_queue_module.task_queue
    job_key = f"batch-analysis:{fingerprint}"
    existing = await queue.status(job_key)
    if force or existing is None or existing.get("status") not in (
        JobStatus.QUEUED, JobStatus.RUNNING,
    ):
        await queue.enqueue("analyze_batch_files", job_key, {
            "resource_id": resource_id,
            "fingerprint": fingerprint,
            "job_key": job_key,
        })

    async def events():
        import asyncio

        last_message = None
        last_output = ""
        while True:
            state = await queue.status(job_key)
            if state is None:
                yield emit("warning", message="解析任务状态已失效")
                return
            result = state.get("result") or {}
            message = result.get("message")
            output = result.get("output") or ""
            if message and message != last_message:
                yield emit("status", message=message)
                last_message = message
            if output.startswith(last_output) and len(output) > len(last_output):
                yield emit("delta", content=output[len(last_output):])
            elif output != last_output and output:
                yield emit("delta", content=output)
            last_output = output
            status = state.get("status")
            if status == JobStatus.DONE:
                yield emit("result", **result)
                return
            if status == JobStatus.FAILED:
                yield emit("warning", message=state.get("error") or "解析失败")
                return
            await asyncio.sleep(0.25)

    return StreamingResponse(events(), media_type="text/event-stream")


@router.patch("/resources/{resource_id}")
async def correct_parse_fields(
    resource_id: str,
    body: ResourceParseCorrectionRequest,
    db: AsyncSession = Depends(get_db),
):
    """Record a user's manual correction of parsed resource fields.

    Applies only explicitly-sent fields, then enforces the batch invariants
    (see ``ResourceParseCorrectionRequest``). Sending any episode-number field
    marks ``episode_confidence="manual"``. Re-runs the channel's active agents
    as a targeted run (like ``correct_episode``) so the corrected resource can
    be dispatched immediately.
    """
    resource = await db.get(FileResource, resource_id)
    if not resource:
        return JSONResponse(
            status_code=404,
            content={"success": False, "data": None,
                     "error": {"code": "NOT_FOUND", "message": "Resource not found"}},
        )

    sent = body.model_fields_set
    if "episode" in sent:
        resource.episode = body.episode
    if "season" in sent:
        resource.season = body.season
    if "absolute_episode" in sent:
        resource.absolute_episode = body.absolute_episode
    if "episode_start" in sent:
        resource.episode_start = body.episode_start
    if "episode_end" in sent:
        resource.episode_end = body.episode_end
    if "is_batch" in sent:
        resource.is_batch = body.is_batch
    if "batch_scope" in sent:
        resource.batch_scope = body.batch_scope

    # Generic media-descriptor corrections (wizard step 3). Applied like the
    # parse fields (explicitly-sent keys only) but they never touch
    # episode_confidence — a mis-parsed resolution says nothing about the
    # episode number.
    for _field in (
        "resolution", "subtitle_group", "subtitle_groups", "source", "video_codec",
        "audio_codec", "subtitle_type", "container", "subtitle_langs",
    ):
        if _field in sent:
            setattr(resource, _field, getattr(body, _field))

    # Keep the legacy scalar and canonical list synchronized.  The plural
    # field is authoritative when both are present; conflicting submissions
    # are rejected rather than silently rewriting a manual correction.
    from app.services.subtitle_groups import (
        join_legacy_subtitle_group,
        normalize_subtitle_groups,
    )
    if "subtitle_group" in sent and "subtitle_groups" in sent:
        if normalize_subtitle_groups(body.subtitle_group) != normalize_subtitle_groups(
            body.subtitle_groups, split=False
        ):
            return JSONResponse(
                status_code=422,
                content={"success": False, "data": None, "error": {
                    "code": "VALIDATION_ERROR",
                    "message": "subtitle_group and subtitle_groups disagree",
                }},
            )
    if "subtitle_groups" in sent:
        resource.subtitle_groups = normalize_subtitle_groups(body.subtitle_groups, split=False)
        resource.subtitle_group = join_legacy_subtitle_group(resource.subtitle_groups)
        resource.subtitle_groups_source = "manual"
    elif "subtitle_group" in sent:
        resource.subtitle_groups = normalize_subtitle_groups(body.subtitle_group)
        resource.subtitle_group = body.subtitle_group
        resource.subtitle_groups_source = "manual"

    # Batch invariants (aligned with the fetch-service pre-parser).
    if resource.is_batch:
        resource.episode = None
        if resource.batch_scope is None:
            resource.batch_scope = "season"
    else:
        resource.batch_scope = None
        resource.episode_start = None
        resource.episode_end = None

    if sent & {"episode", "season", "absolute_episode"}:
        resource.episode_confidence = "manual"
    elif resource.is_batch and resource.episode_confidence == "ambiguous":
        # A 合集 has no single episode/season to confirm — marking it as batch
        # settles the ambiguous question even when no episode field was sent.
        resource.episode_confidence = "manual"

    # Capture the channel id before commit (the ORM object may be expired
    # after commit and ``resource`` is about to be re-fetched below).
    channel_id = resource.channel_id
    await db.flush()

    # Same convention generalization as ``correct_episode``: when the
    # correction touched the episode-number fields, heal unresolved siblings
    # of the same work+channel before committing.
    healed_ids: list[str] = []
    if sent & {"episode", "season", "absolute_episode"} and not resource.is_batch:
        try:
            from app.services.episode_history import heal_sibling_episodes
            from app.services.metadata_episode_reconcile import seasons_map_for_work

            linked = await db.get(_TVSeries, resource.series_id) if resource.series_id else None
            healed_ids = await heal_sibling_episodes(
                db, resource,
                seasons_map=seasons_map_for_work(linked) if linked else {},
            )
        except Exception:
            logger.exception("[correct_parse_fields] sibling heal failed for %s", resource_id)

    # Commit BEFORE enqueuing the agent re-run: run_agent runs in its own
    # session and only sees committed data.
    requested_agent_ids = await request_channel_resources(db, channel_id, [resource_id, *healed_ids])
    await db.commit()

    # Re-cache a missing .torrent so the targeted rerun can rebuild file
    # assignments (best-effort, never blocks the flow).
    await _retry_torrent_cache(db, resource_id)

    await wake_agents(requested_agent_ids, [resource_id, *healed_ids])

    # Re-fetch with relationships so Pydantic can serialize without lazy IO.
    resource = (await db.execute(
        select(FileResource)
        .where(FileResource.id == resource_id)
        .options(*_DETAIL_LOAD_OPTIONS)
    )).scalar_one()
    return success_response(FileResourceDetailResponse.model_validate(resource).model_dump())
