"""Metadata cache for title cleaning and agent results.

Stores cached results keyed by ``(title, source)`` where ``source`` namespaces
the cache by both type and data source:

- ``"metadata_agent:<source>"`` - Full metadata agent result for one external
  source (e.g. ``"metadata_agent:tmdb"``, ``"metadata_agent:wikipedia"``), including
  clean_title, content_type, inferred episode/season, matched entity, and
  confidence. Namespacing by source keeps one source's results from being
  served for a channel configured with a different source.
- ``"llm_title"`` - Legacy title cleaning cache (pre-refactor, retained for
  reference).

The ``metadata_json`` column stores the complete result dict, whose shape
depends on the ``source`` value.
"""

import hashlib
import uuid
from datetime import datetime

from sqlalchemy import JSON, DateTime, String, Text, UniqueConstraint, event
from sqlalchemy.orm import Mapped, mapped_column

from app.database import Base
from app.utils.sql_time import UTCNow

# Bump this whenever the classification / judge / matching logic that
# PRODUCES cached verdicts changes (e.g. the tv-vs-movie classifier). Rows
# written by older generations are treated as cache misses and lazily
# deleted on read, so stale verdicts from superseded logic can never
# short-circuit the fixed code. Legacy rows (pre-versioning) migrated to
# ``generation = 0`` and are therefore always stale.
# Generation history:
#   1 — initial versioning (tv-vs-movie classifier fix).
#   2 — P1 (Exa-fallback identity semantics) + P2 (wikipedia seasons/episodes
#       attach) + P3 (identity bag: alt_external_ids / langlink pageids)
#       changed verdict logic; stale cached verdicts must refetch.
#   3 — genre unification: the closed TMDB genre set is injected into the
#       judge/ReAct prompts and clamped via genre_registry.normalize_genres;
#       cached verdicts from older generations carry un-normalized genre.
#   4 — genre prompt becomes best-effort: the judge/ReAct instruction now
#       requires inferring at least one genre from the synopsis when the
#       source lists none, so genre-less verdicts should not reappear.
#   6 — bind web fallback identities to shown candidates; filter before query
#       early-stop and reject ungrounded identity/episode-list payloads.
#   7 — bind primary/alternate identities to source evidence; invalidate
#       cached model identities produced before grounding enforcement.
METADATA_CACHE_GENERATION = 7


def cache_title_hash(title: str) -> str:
    """Hash the exact stored title; namespace callers own their normalization."""
    return hashlib.sha256(title.encode("utf-8")).hexdigest()


def _default_title_hash(context):
    return cache_title_hash(context.get_current_parameters()["title"])


class MetadataCache(Base):
    __tablename__ = "metadata_cache"
    __table_args__ = (
        UniqueConstraint("title_hash", "source", name="uq_metadata_cache_key"),
    )

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True, default=lambda: str(uuid.uuid4())
    )
    title: Mapped[str] = mapped_column(Text, nullable=False)
    title_hash: Mapped[str] = mapped_column(String(64), nullable=False, default=_default_title_hash)
    source: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    content_type: Mapped[str | None] = mapped_column(String(50), nullable=True)
    metadata_json: Mapped[dict] = mapped_column(JSON, nullable=False)
    # Logic generation that produced this verdict; see METADATA_CACHE_GENERATION.
    generation: Mapped[int] = mapped_column(
        nullable=False, default=METADATA_CACHE_GENERATION
    )

    created_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=UTCNow(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=UTCNow(), onupdate=UTCNow(), nullable=False
    )


@event.listens_for(MetadataCache, "before_insert")
@event.listens_for(MetadataCache, "before_update")
def _update_title_hash(mapper, connection, target):
    target.title_hash = cache_title_hash(target.title)
