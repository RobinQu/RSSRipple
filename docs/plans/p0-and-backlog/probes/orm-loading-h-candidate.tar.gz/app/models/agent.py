"""Agent ORM model."""

import uuid
from datetime import datetime

from sqlalchemy import JSON, Boolean, DateTime, Enum, ForeignKey, Integer, String, func
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


class Agent(Base):
    __tablename__ = "agents"

    id: Mapped[str] = mapped_column(
        String(36), primary_key=True, default=lambda: str(uuid.uuid4())
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    channel_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("channels.id", ondelete="CASCADE"), nullable=False
    )
    downloader_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("downloader_instances.id", ondelete="RESTRICT"), nullable=False
    )
    download_subdir: Mapped[str | None] = mapped_column(String(500), nullable=True)
    task_expire_days: Mapped[int] = mapped_column(Integer, default=30, nullable=False)
    llm_enabled: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    scope_channel_wide: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    conflict_resolution: Mapped[str] = mapped_column(
        String(20), default="auto", nullable=False
    )
    # Optional user-supplied instruction for the LLM candidate picker. When
    # empty the built-in default prompt is used (prefer most-complete
    # metadata, highest resolution, subtitles, newest). Applies to both the
    # "auto" conflict-resolution path and the suggestion shown in "ask" mode.
    llm_prompt: Mapped[str | None] = mapped_column(String(4000), nullable=True)
    # Ordered candidate-preference rules (FieldCondition JSON list, first rule
    # = highest priority). In conflict resolution they rank same-key candidates
    # deterministically (lexicographic tie-break) BEFORE the LLM pick: a unique
    # winner dispatches/suggests without any LLM call; a remaining tie goes to
    # the LLM, then the heuristic scorer. Preferences only ever reorder —
    # they never filter candidates out of the conflict set.
    pick_preferences: Mapped[list | None] = mapped_column(JSON, nullable=True)
    filter_config: Mapped[dict | None] = mapped_column(JSON, nullable=True)
    status: Mapped[str] = mapped_column(
        Enum("active", "paused", "error", name="agent_status"),
        default="active",
        nullable=False,
    )
    last_run_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    last_run_status: Mapped[str | None] = mapped_column(String(50), nullable=True)
    # Compatibility timestamp for UI and explicit time-based scans/migration.
    # Incremental eligibility is owned by AgentPublicationProgress and the
    # channel's committed publication sequence, not resource creation time.
    # Null still denotes first-run initialization without implicit backfill.
    last_consumed_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    # Webhook subscriptions for download notifications live in their own
    # table (``agent_webhooks``) — an Agent may fan out to several webhooks.
    # The legacy ``notify_webhook_url/_mock/_token`` columns remain in the
    # physical table as inert orphans (no DROP migration; registrations are
    # copied over by a light migration on startup).
    created_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, server_default=func.now(), onupdate=func.now(), nullable=False
    )

    # Relationships
    channel = relationship("Channel", back_populates="agents")
    downloader = relationship("DownloaderInstance", back_populates="agents")
    works = relationship(
        "AgentWork",
        back_populates="agent",
        order_by="AgentWork.created_at.asc()",
        lazy="selectin",
        cascade="all, delete-orphan",
    )
    download_tasks = relationship(
        "DownloadTask",
        back_populates="agent",
        lazy="raise",
        passive_deletes=True,
    )
    pending_decisions = relationship(
        "PendingDecision",
        back_populates="agent",
        lazy="raise",
        cascade="all, delete-orphan",
    )
    suggestions = relationship(
        "AgentSuggestion",
        back_populates="agent",
        lazy="raise",
        cascade="all, delete-orphan",
    )
    runs = relationship(
        "AgentRun",
        back_populates="agent",
        cascade="all, delete-orphan",
        passive_deletes=True,
    )
    notifications = relationship(
        "DownloadNotification",
        back_populates="agent",
        lazy="raise",
        passive_deletes=True,
    )
    webhooks = relationship(
        "AgentWebhook",
        back_populates="agent",
        lazy="raise",
        passive_deletes=True,
    )
