# API 端点设计

B4 候选：资源 magnet 人工重试以读取时的 attempt、状态和 magnet URL 为条件原子重置计数及错误，同时清空旧 `magnet_resolve_attempt_id`，下一次领取生成新标识。条件失配返回 409 `INVALID_STATE`，不入队、不覆盖新领取。响应结构不变；此协议仍待完整并发验收。

所有端点前缀 `/api/v1`，请求/响应均为 JSON。统一响应结构：

```json
{
  "success": true,
  "data": { ... },
  "error": null,
  "meta": { "page": 1, "page_size": 20, "total": 100 }
}
```

分页端点使用查询参数 `page`（默认 1）和 `page_size`（默认 20，最大 100），在 `meta` 中返回分页信息。非分页端点 `meta` 可省略或返回空对象。

### 认证（Auth）

`AUTH_ENABLED=true`（默认）时，`/api/v1/*` 与 `/posters/*` 全部受 `AuthMiddleware` 保护，需携带有效凭证；`/api/v1/auth/*` 与 `/health`（容器健康检查探针）开放；SPA 页面与静态资源开放（前端在收到 401 后自行跳转 `/login`）。无凭证或凭证无效一律返回 401 `{success:false, data:null, error:{code:"UNAUTHORIZED",...}, meta:{}}`。

两类凭证（任一有效即可）：
- **会话 Cookie**（Web 端）：`POST /auth/otp` 签发的 HttpOnly Cookie `rssripple_auth`。
- **API Key**（程序端）：`Authorization: Bearer <key>` 或 `X-API-Key: <key>` 头；接受环境变量 `API_KEY`（可选静态引导 key）或 `api_keys` 表中的 key。

| Method | Path | 说明 |
|--------|------|------|
| POST | `/auth/otp` | TOTP 登录：body `{"code": "123456"}`；校验通过（容忍 ±1 时间窗）后签发 HttpOnly Cookie `rssripple_auth`（30 天，SameSite=Lax），返回 `{authenticated: true}`；验证码错误 401 `UNAUTHORIZED` |
| POST | `/auth/logout` | 清除会话 Cookie，返回 `{authenticated: false}` |
| GET | `/auth/status` | 当前请求是否已认证 `{authenticated: bool}`，始终 200 |
| GET | `/api-keys` | API key 列表（`[{id, name, prefix, created_at}]`；不暴露 hash/明文） |
| POST | `/api-keys` | 创建 API key：body `{"name": "..."}` → 201，`data` 额外含 `key`（`rr_...` 明文，**仅本次响应返回一次**） |
| DELETE | `/api-keys/{id}` | 删除 API key；不存在 404 |

TOTP 秘钥与 Cookie 签名秘钥在首次启动时自动生成并持久化到 `app_settings`（`auth_totp_secret` / `auth_cookie_secret`）；首次启动和重启均不在日志输出秘钥或 provisioning URI。运维通过本地终端执行 `python -m app.scripts.auth_enrollment --show`，只读获取已有绑定 URI；命令拒绝重定向输出，不创建或轮换秘钥，不新增公开绑定 API。Turso 需先停止应用以释放独占文件锁，详见 conventions.md 的认证器绑定流程。

### 健康检查（Health）

| Method | Path | 说明 |
|--------|------|------|
| GET | `/health` | 容器健康检查探针。**免认证**（不在 `/api/v1/*`、`/posters/*` 保护前缀内）：对 DB 执行 `SELECT 1`，可达返回 200 `{status:"ok", database:"ok"}`，不可达返回 503 `{status:"unhealthy", database:"unreachable"}`（不做 DB 写入，Turso 单进程文件锁下健康检查进程不直接开库，只经 HTTP 进应用进程）。所有 docker compose 的 app/eval 服务健康检查均指向该端点 |

### Dashboard

| Method | Path | 说明 |
|--------|------|------|
| GET | `/dashboard/overview` | 非实时概览：活跃 Agent/频道数、按活动任务数排序的 Top4 Agent 精简摘要、三类待办的独立服务端分页。Query：`decision_page`/`confirmation_page`/`plan_page`（默认 1）及共享 `page_size`（默认 10，最大 100） |
| GET | `/dashboard/downloads` | 实时下载快照：`active_download_count` + `active_download_groups`。下载器 RPC 并发且单实例最多等待 2 秒；失败时已跟踪任务保留数据库速度，无法读取的未跟踪种子跳过 |
| GET | `/dashboard` | 向后兼容聚合响应，合并 overview 与 downloads；SPA 不轮询此端点 |
| POST | `/dashboard/todos/ignore` | 单个或批量忽略同类待办。Body：`{kind: "decision"|"confirmation"|"plan", ids: string[1..100]}`。decision→`skipped`；confirmation→资源写 `confirmation_ignored_at`，永久退出待确认列表但不删除资源；plan→`cancelled` 并追加 organize audit。响应 `{requested, ignored, unchanged}` |

`GET /dashboard` 兼容聚合响应的 `data` 结构（拆分端点分别返回对应字段）：
```json
{
  "active_agents": 3,
  "active_channels": 2,
  "top_agents": [ { "id": "...", "name": "...", "active_task_count": 2, "works": [ ... ] } ],
  "active_download_count": 12,
  "active_download_groups": [
    {
      "type": "series" | "movie" | "unknown" | "untracked",
      "id": "uuid-or-null",
      "title": "作品名或未识别",
      "poster_url": "/posters/xxx.jpg",
      "tasks": [ { "task_id": "...", "resource_title": "...", "progress": 0.5, "download_speed": 1048576, "agent_id": "...", "agent_name": "...", "channel_id": "...", "channel_name": "..." } ]
    }
  ],
  "pending_decisions": [ { ... } ],
  "pending_decisions_total": 3,
  "pending_confirmations": [ { ... } ],
  "pending_confirmations_total": 36,
  "pending_plans": [ { ... } ],
  "pending_plans_total": 2
}
```

三个 `*_total` 均为对应待办的真实全量数，不受当前页 `page_size` 限制；三个页码相互独立，切换其中一个列表不会改变另两个列表的页位。Agent 决策总数与分页结果只计入候选数至少为 2 的有效多选一决策；文件资源确认总数与分页结果统一调用 Channel 确认策略计算，并排除 `confirmation_ignored_at` 非空的资源。

`pending_confirmations` 条目结构 `{resource, channel_name, work_title, work_ref, kinds, missing_fields}`：`work_title`/`work_ref` 为标题展示与跳转目标，按 互斥作品 FK（series/movie）→ 挂载合集（`collection_id`，对应 `/collections/:id`）→ 合集包 `resource_work_links` 首个关联作品 的优先级取首个可用者，全空（未识别）则为 null（标题不可点击）。

`untracked` 组：对每个下载器调用 `list_torrents`，筛选**未下载完成**（`is_finished=false` 且 `percent_done<1`——Transmission 对 stopped 的 100% 种子也报 `isFinished=false`，需双条件；不限传输状态，stopped/paused 的未完成种子同样属于未跟踪）且 torrent id 不属于任何非终态（pending/queued/downloading/paused）DownloadTask 的种子；下载器不可达时跳过（不影响整体响应）。其 task 条目 `task_id` 为合成值（`untracked-{downloader_id}-{torrent_id}`），`agent_*`/`channel_*` 为 null，附带 `downloader_id`/`downloader_name` 与原始种子状态 `status`（Transmission 枚举）；仅正在传输（downloading/download pending）的未跟踪种子计入 `active_download_count`。

### Queue（队列监控）

只读实时快照，无数据库表、无持久化：数据全部来自任务队列后端（`BaseQueue.list_jobs()`）与 APScheduler 内存状态。统计范围由后端决定——memory 后端为进程重启以来（`stats_scope="since_restart"`），redis 后端为状态 hash 未过期窗口（`stats_scope="last_24h"`，对应 `JOB_TTL_SECONDS=86400`）。

| Method | Path | 说明 |
|--------|------|------|
| GET | `/queue/overview` | 队列聚总：`backend`/`app_role`/`stats_scope`/`total` + 按状态计数 `counts`（`{queued, running, done, failed}`）+ 按 `job_type` 聚合 `by_type`。每个 by_type 条目 `{job_type, total, queued, running, done, failed, success_rate, avg_duration_seconds}`：`success_rate = done/(done+failed)`，分母为 0 时 null；`avg_duration_seconds` 为同时具备 `started_at`/`finished_at` 的终态任务的平均耗时秒数，无样本时 null。by_type 按 total 降序、job_type 升序 |
| GET | `/queue/jobs` | 任务明细列表（内存过滤/排序/分页）。Query：`status`、`job_type`（均可选精确匹配）、`page`（默认 1）、`page_size`（默认 50，最大 100）。排序：running → queued → 终态按 `queued_at` 降序（缺 `queued_at` 的排在各组最后）。条目为任务状态字典 `{job_id, job_type, key, status, result, error, queued_at, started_at, finished_at}`；分页信息走统一 `meta` |
| GET | `/queue/scheduler` | 调度器快照。调度器未初始化（`APP_ROLE=web` 或 `SCHEDULER_ENABLED=false`）时返回 `{enabled: false, jobs: []}`（200，非 500）；否则 `{enabled: true, jobs: [{id, trigger, next_run_time}]}`，`next_run_time` 为 ISO 8601 字符串或 null |

`GET /queue/overview` 的 `data` 结构示例：
```json
{
  "backend": "memory",
  "app_role": "all",
  "stats_scope": "since_restart",
  "total": 4,
  "counts": { "queued": 1, "running": 1, "done": 1, "failed": 1 },
  "by_type": [
    { "job_type": "run_agent", "total": 3, "queued": 1, "running": 1, "done": 1, "failed": 0, "success_rate": 1.0, "avg_duration_seconds": 12.4 }
  ]
}
```

### Channels

> 兼容变更：新建频道的代码基线为 `search_title/content_type/is_batch/year/is_anime` 五件套；`title_cn` 与 `title_en` 均可选。启动轻迁移会一次性移除历史基线遗留的 `title_cn`/`title_en`；用户此后主动勾选的字段仍遵循只增不减。

| Method | Path | 说明 |
|--------|------|------|
| GET | `/channels` | 频道列表（分页） |
| POST | `/channels` | 创建频道（服务端校验 RSS URL 可达与格式合法性） |
| GET | `/channels/form-token` | 获取表单防重复提交 Token（一次有效，存服务端 Cache） |
| GET | `/channels/metadata-sources` | 频道表单数据源目录（三数据源架构：仅 wikipedia/tmdb/bangumi + 可用性标志 + 默认值） |
| GET | `/channels/required-field-catalog` | 必填元数据字段目录（覆盖全部 Filter DSL 字段；两级分组 `sections`（作品形态先行：base/tv/pack → release/work）+ 每项 `{key, section, group, dsl_fields, lock, locked, applies_to}`，`lock`=代码强制作用域（`always` 或行形态如 `tv_single`），`applies_to`=适用行形态（null=全形态）） |
| GET | `/channels/{id}` | 频道详情（含最近 20 条 FileResource 预览） |
| PUT | `/channels/{id}` | 更新频道（含 field_mapping/metadata_agent_enabled 等所有字段，一次性保存；`required_metadata_fields` 只增不删，见下） |
| DELETE | `/channels/{id}` | 删除频道（级联删除其 file_resources、agents、tasks、mappings） |
| POST | `/channels/{id}/fetch?force=false` | 手动触发抓取（入队，返回 task_id）；`force=false` 只抓新条目并按常规冷却回填未匹配资源，`force=true` 无上限重跑频道全部既有条目，绕过 metadata 缓存/本地作品短路并重做 torrent 文件关联富化 |
| GET | `/channels/{id}/fetch-status` | 轮询抓取任务状态（running/success/failed + 进度信息） |
| POST | `/channels/{id}/analyze` | 非流式 LLM 分析 RSS，返回 field_mapping（阻塞等待直到完成或超时） |
| POST | `/channels/{id}/analyze-stream` | SSE 流式 LLM 分析（`status/delta/reset/done/error` 事件；连接建立即冲刷响应头，RSS 抓取与 LLM 生成的 delta 实时下发，重试前发 `reset` 通知前端清空半程文本） |
| POST | `/channels/{id}/summarize-filters` | 给定若干资源 ID，按 Agent 规则结构生成建议：作品订阅 + 全局共性条件 + 按作品差异化条件 |
| POST | `/channels/validate-url` | 验证 RSS URL 可达性与格式（创建前校验） |
| POST | `/channels/preview-feed` | 预览 RSS 源，可选附带 field_mapping 预览解析结果（不落库） |
| POST | `/channels/analyze-url-stream` | 基于 URL 的 SSE 流式分析（创建频道前使用，无需 channel_id） |

频道调度：创建事务提交成功后才尝试首次自动抓取；inactive 或 SCHEDULER_ENABLED=false 不自动入队，`meta.fetch_triggered` 反映首次入队结果。更新/删除后的周期任务由各 worker 每 30 秒对账同步，无需重启 worker；接口不操作 web 本地调度器。ChannelUpdate 当前不接受 status（不能通过 PUT 暂停/恢复）；数据库中 inactive 状态由同一对账机制移除周期任务。

频道创建/更新的元数据字段：`metadata_source` 仅接受 `wikipedia | tmdb | bangumi`（其他值 422）；`metadata_fallback_sources` 为网络搜索回退（wigolo）的有序站点白名单（JSON 数组，元素必须是注册表站点名 wikipedia/tmdb/bangumi/mal/anilist/imdb/douban，未知值 422；`null`=默认顺序，`[]`=禁用回退）。`default_is_anime`（「默认标记为 Anime」，默认 false）：Create 接受、Response 透出，**创建后不可改**——PUT 提交不同值返回 422 VALIDATION_ERROR，同值幂等放行。

频道资源列表响应额外返回派发结果三字段：`has_download_task`（该资源曾创建过任意 `DownloadTask` 即为 true，任意当前状态）；`download_status`（该资源**最新**一条 DownloadTask 的**有效**派发结果，从未派发为 null，多任务按 `created_at` 取最新）——原始 status 不可直接信：organize 清理（`task_cleanup.delete_task_after_organize`）会把已完成任务置 cancelled，`completed_at` 才是真实完成标记（与 agent_service `_task_occupies_download_slot` 同口径），故 `completed_at` 非空时按计划状态归并为 `organized`（OrganizePlan done）/ `completed`，`cancelled` 仅当 `completed_at` 为 NULL（真实取消），其余状态透传；`pending_decision`（该资源是本频道任一 Agent 当前 pending 的 PendingDecision 候选时为 true），供打「待决策」标。

`required_metadata_fields`（必填元数据字段清单，权威目录 `app/services/required_fields.py`）：**强制且创建后只增不删**。Create 省略时默认为代码强制基线（永不可清除，不存在"不限制"状态）＝**基础必选五件套**（`search_title/content_type/is_batch/year/is_anime`）∪ **形态必填**（TV 单集→`episode`；TV 单季合集→`episode_start`+`episode_end`；跨季合集不要求单值 season/range，仅校验 `batch_seasons`（links-only 形态校验关联季作品 links 与派生缓存一致）；多作品合集→`resource_collection`）；`title_cn`/`title_en` 均为可选目录字段；显式 `null` 一律 422；未知目录键 422；重复键去重、结果按目录规范序重排并强制并入基线。PUT 提交的数组若缺失任何已保存键 → 422 VALIDATION_ERROR。**作品单季化目录变更**：`season` 键从形态必填退役为**可选**（季号由季作品身份承载，DSL 字段保留），`absolute_episode`/`episode_confidence` 两键退役出目录（字段仍在资源模型与 DSL）；存量频道声明里的这三键由启动轻迁移一次性移除（哨兵 `required_fields_per_season_v1`），此后用户可在只增不删策略下重新加入 `season`。Agent 运行前按资源形态检查这些字段的实际值，缺失资源进入 Channel 文件资源待确认并阻止派发；AudioWork 不进入 TV 合集范围检查；`pick_preferences` 可引用目录外字段，空值只是不命中偏好。

`POST /channels/{id}/summarize-filters` 请求体：`{ "resource_ids": ["...", "..."] }`；响应 `data`：

```json
{
  "works": [
    {
      "content_type": "tv",
      "series_id": "...", "movie_id": null,
      "title": "...", "poster_url": "/posters/x.jpg",
      "resource_count": 3,
      "filter_overrides": { "...BoolCondition 或 null..." },
      "override_explanation": "subtitle_group=ANi"
    }
  ],
  "global_filter_config": { "...BoolCondition 或 null..." },
  "unlinked_count": 1,
  "explanation": "resolution=1080p; unlinked=1"
}
```

规则拆分逻辑：字段（subtitle_groups/resolution/video_codec/audio_codec/container/subtitle_type/source）在**全部选中资源**中 ≥80% 同值 → 全局条件；字幕组按成员生成 `contains` 条件；在**单个作品**内 ≥80% 同值但不满足全局 → 该作品的 `filter_overrides`。未链接作品的资源计入 `unlinked_count`，不产生订阅。

### Agents

| Method | Path | 说明 |
|--------|------|------|
| GET | `/agents` | Agent 列表（分页） |
| POST | `/agents` | 创建 Agent，body 含 `filter_config`、`works`（AgentWork 列表，最多 10 个）、可选 `llm_prompt`、可选 `pick_preferences`（优选偏好：有序 FieldCondition 列表，确定性排序层，422 校验同 Filter DSL 叶子规则）、可选 `dispatch_resource_ids`（规则预览回填提交） |
| GET | `/agents/{id}` | Agent 详情（含 works、统计信息；TV 类型 works 附带 `latest_completed_season/episode`——按非空 `completed_at` 识别该剧集全库范围内最新已完成下载的季/集号，因此整理后转为 cancelled 的历史任务仍计入；无完成记录或为电影时为 null） |
| PUT | `/agents/{id}` | 更新 Agent（整体替换，含 works 列表） |
| DELETE | `/agents/{id}` | 删除 Agent（级联删除其 works、pending_decisions、runs；tasks 标记 cancelled） |
| POST | `/agents/{id}/run` | 手动触发处理（入队处理该 Agent 频道下未处理资源）。可选 body `{"scan_since": "<ISO 8601>" \| null}`：指定本次运行的扫描起始时间（按资源入库时间，必须为过去时间，否则 422）；显式 `null` = 不限制（全量历史）；不带 body = 普通增量运行 |
| GET | `/agents/{id}/run-status` | 轮询处理状态 |
| POST | `/agents/{id}/test-filters` | 给定资源或全部资源测试 filter_config 匹配情况，返回匹配结果明细 |
| GET | `/agents/{id}/suggestions` | 读取持久化的未识别资源建议分组，供用户一键添加为订阅作品 |
| GET | `/agents/{id}/runs` | 运行历史（分页）：每次 run 一条记录，含计数、状态、匹配资源 ID 列表、`scan_since`（指定起始时间运行的扫描下界；null=增量/定向，`1970-01-01`=全量）；`non_empty=true` 时仅返回"非空"运行（dispatched>0 或 pending_decisions>0 或 status 为 running/failed），隐藏无产出的例行空跑。读时修正：AgentRun 的 status/pending_decisions 是运行结束时的快照，若该 agent 当前已无 pending 决策，响应中 `status="pending_decisions"` 的 run 改写为 `"success"` 返回（不回写 DB，历史计数保留）；`matched_resources` 每条目附 `pending_decision: bool`——该资源仍是当前 pending 决策候选时为 true，供前端打「待决策」标；另附 `dispatched: bool`——该资源曾创建过 DownloadTask（即冲突解决中被实际派发）时为 true，供前端打「已派发」标 |
| POST | `/agents/rules-preview` | 提交拟变更的订阅规则，预览匹配差异（新增匹配 / 不再匹配 / 已在队列跳过），供用户选择回填资源 |

`POST /agents` 请求体示例：
```json
{
  "name": "新番自动下载",
  "channel_id": "...",
  "downloader_id": "...",
  "download_subdir": "Anime/新番",
  "scope_channel_wide": false,
  "conflict_resolution": "auto",
  "llm_enabled": true,
  "llm_prompt": "优先选择内封简繁日字幕的 2160p HEVC 资源",
  "pick_preferences": [ { "field": "subtitle_langs", "operator": "contains", "value": "zh-CN" } ],
  "filter_config": { "combinator": "and", "conditions": [ { "field": "resolution", "operator": "in", "value": ["1080p","2160p"] } ] },
  "works": [
    { "content_type": "tv", "series_id": "...", "enable_episode_dedup": true, "filter_overrides": null }
  ],
  "dispatch_resource_ids": null
}
```

`dispatch_resource_ids` 语义：
- `null`（默认）：普通保存，不回填、不改动水位线（用于非规则编辑）。
- 数组（可为空 `[]`）：表示本次保存经过 rules-preview 流程。后端会派发数组中选中的资源，并在同一保存事务重置发布 baseline/cursor 为当前频道提交前缀、更换 generation、清空历史时间准入；`last_consumed_at` 仍更新为兼容展示时间。空数组 = 不回填资源但重置准入边界。

`POST /agents/{id}/test-filters` 请求体：`{ "resource_ids": ["..."]? }`（不传则测试最近 50 条资源）；响应返回每条资源是否通过及每个条件的命中情况。

`POST /agents/rules-preview` 请求体：
```json
{
  "agent_id": "uuid | null",      // 已有 Agent 时传，old rules 从 DB 读取；新建时不传
  "channel_id": "uuid | null",    // agent_id 缺省时必填，old rules 视为空（全部为新增匹配）
  "scope_channel_wide": false,
  "filter_config": { "...BoolCondition..." },
  "works": [ { "content_type": "tv", "series_id": "...", ... } ]
}
```
响应 `data`：
```json
{
  "newly_matching": [ { "...RulesPreviewResource..." } ],     // 新增匹配且无活跃 DownloadTask → 可选回填
  "no_longer_matching": [ { "...RulesPreviewResource..." } ], // 不再匹配（仅展示，不撤销已入队任务）
  "in_queue_skipped": 0                                        // 新增匹配但已有活跃任务的跳过数
}
```

### Agent Works（子资源）

独立 CRUD，用于在 Agent 详情页管理订阅作品。

| Method | Path | 说明 |
|--------|------|------|
| GET | `/agents/{agent_id}/works` | 列出 Agent 所有订阅作品 |
| POST | `/agents/{agent_id}/works` | 新增订阅作品 |
| PUT | `/agents/{agent_id}/works/{id}` | 更新作品的覆盖设置（去重开关、filter_overrides 等） |
| DELETE | `/agents/{agent_id}/works/{id}` | 移除订阅作品 |

`POST /agents/{agent_id}/works` 请求体：
```json
{
  "content_type": "tv",
  "series_id": "uuid",       // tv 时必填
  "movie_id": null,          // movie 时必填
  "enable_episode_dedup": true,
  "filter_overrides": null
}
```

### Downloaders

| Method | Path | 说明 |
|--------|------|------|
| GET | `/downloaders` | 下载器列表 |
| POST | `/downloaders` | 创建下载器 |
| GET | `/downloaders/{id}` | 下载器详情 |
| PUT | `/downloaders/{id}` | 更新下载器 |
| DELETE | `/downloaders/{id}` | 删除下载器；若仍有关联 Agent 返回 `409 CONFLICT` 并在 `error.details.agents` 中带出 `[{id, name}]` 列表，UI 可据此指引用户先解绑/删除这些 Agent |
| POST | `/downloaders/{id}/test` | 测试 Transmission RPC 连通性，并用 `free_space(download_dir)` 检查默认下载目录；**同时校验卷绑定有效性**（存在且可读可写）。请求体可选 `{url, username, password, download_dir, volume_id, volume_subpath}`：用于编辑表单按未保存的表单值探测（缺省字段回退到已存值，空密码 = 沿用已存密码；`volume_id`/`volume_subpath` 缺省沿用已存值、显式 `null` = 解绑即恒等）；带覆盖值的探测不更新 status，仅探测已存配置时才更新 status。响应含 `volume_check`（`{exists, readable, writable}` 或 null），卷绑定无效时 `success=false` 且 message 说明原因 |
| GET | `/downloaders/{id}/tasks` | 本地 DownloadTask 分页列表（内联 `file_resource` 及其 series/movie/audio_work/collection 关联，供作品列与 metadata 列渲染）；返回的 `status` 为**展示用有效状态**：原始行为 `cancelled` 但 `completed_at` 非空时（organize 清理/进度同步会把已完成任务置 cancelled，`completed_at` 才是可靠完成标记，语义同频道资源列表的派发结果）改报 `completed`，其 organize 计划已 done 则报 `organized`；`status` 过滤按**有效状态**语义（`completed` 含 organized 行、`cancelled` 仅真正取消）；`sort` 查询参数为逗号分隔的 `key:asc|desc`（key ∈ `status`/`created_at`/`progress`/`title`，status 按完成度分组 asc=未完成优先、title 走资源 join），缺省 `status:asc,created_at:desc`（未完成靠前、组内入队最新靠前），非法 key 忽略、全部非法回退默认，id 升序兜底保证分页稳定 |
| GET | `/downloaders/{id}/torrents` | Transmission 实时种子列表（直连 RPC 返回） |

`POST /downloaders` 请求体示例：
```json
{
  "name": "家用 NAS Transmission",
  "type": "transmission",
  "url": "http://127.0.0.1:9091/transmission/rpc",
  "username": "user",
  "password": "pass",
  "download_dir": "/volume1/downloads/rssripple",
  "volume_id": "b7f1…",
  "volume_subpath": "downloads/rssripple"
}
```

下载目录规则：
- `download_dir` 必填，必须是 Transmission 下载服务器视角的绝对路径；支持 POSIX（`/volume1/downloads`）、Windows drive path（`D:\Downloads`）和 daemon 支持的 UNC path。
- RSSRipple 后端可能无法访问该目录，因此路径语义以 Transmission daemon 为准。
- `volume_id` / `volume_subpath`（R1 卷绑定，均可空）：daemon 视角的 `download_dir` 根 == `volume.mount_path + volume_subpath`，用于把通知快照里的 daemon 路径解析为本进程视角（见 file-organization.md「统一路径解析：逻辑存储卷」）；两者皆 null = 两视角一致（恒等，默认）。`volume_id` 必须指向存在的 StorageVolume（404），`volume_subpath` 校验规则同 `Agent.download_subdir`（相对路径、禁 `..`/绝对路径/控制字符，空串归 null）且必须依附 `volume_id`（422）。P1 的 `path_map` 字段已移除。
- 创建/编辑时做路径格式校验；`POST /downloaders/{id}/test` 必须调用 Transmission `free_space(download_dir)`，返回目录可识别性与剩余空间。
- 真实写入能力、子目录存在性、磁盘不足等仍以 `torrent_add(download_dir=...)` 的结果为最终准据。
- 若多个 Agent 共用一个 Downloader，建议通过 Agent 的 `download_subdir` 分流目录。

### Storage Volumes

逻辑存储卷（file-organization.md「统一路径解析：逻辑存储卷」）：指向 RSSRipple 容器内一个挂载点；一切配置面路径引用存 `(volume_id, subpath)`，使用处动态解析 `volume.mount_path + subpath`。

| Method | Path | 说明 |
|--------|------|------|
| GET | `/volumes` | 逻辑卷列表（分页） |
| POST | `/volumes` | 创建 `{name, mount_path, remark?}` → 201；`mount_path` 必须绝对路径且**存在**（422）；`name` 全局唯一（重复 409 `DUPLICATE_SUBMISSION`） |
| GET | `/volumes/{id}` | 详情 |
| PUT | `/volumes/{id}` | 更新 `{name?, mount_path?, remark?}`（改 mount_path 全局生效——所有卷引用动态解析；同样过存在性校验 422 与名称唯一 409） |
| DELETE | `/volumes/{id}` | 删除；被下载器卷绑定 / 媒体服务器绑定 / Library 库根引用时 409 `DELETE_BLOCKED`（`error.details` 带出对应 `downloaders` / `media_server_bindings` / `libraries` 数组） |
| POST | `/volumes/{id}/check` | 探测挂载点存在性与写权限 → `{exists, writable}`（writable 仅展示提示，不拦截保存） |

### Media Servers

媒体服务器实例（file-organization.md「MediaServerInstance / MediaServerBinding」，R2）：多服务器、多类型（plex/emby/jellyfin）；Library 由扫描派生。token 不回显（对齐 Downloader password 惯例）。

| Method | Path | 说明 |
|--------|------|------|
| GET | `/media-servers` | 服务器列表（不分页；每项含 bindings 数组、派生 `library_count` 与 `unbound_library_count`） |
| POST | `/media-servers` | 创建 `{name, type, url, token?, enabled?, bindings?}` → **201**；`type` 限 `plex/emby/jellyfin`（422）；bindings 条目 `{server_path_prefix, volume_id, subpath?}`——prefix 非空（422）、volume 不存在（404）、subpath 校验同 `Agent.download_subdir` |
| GET | `/media-servers/{id}` | 详情（含 bindings 数组） |
| PUT | `/media-servers/{id}` | 部分更新；`bindings` 内嵌**整体替换**（缺省不动，数组含 `[]` 全量替换；同创建校验）；`token` 传 null/缺省 = 保持存储值 |
| DELETE | `/media-servers/{id}` | 删除（bindings 随 FK CASCADE；派生 Library `media_server_id` SET NULL 保留行） |
| POST | `/media-servers/{id}/test` | 连通性 + 凭证校验 → `{ok, server_version?, message?}` |
| POST | `/media-servers/{id}/scan` | 扫描 sections/虚拟目录，幂等 upsert Library（经 bindings 最长前缀匹配解析卷；未命中落 `volume_id=NULL` 待绑定）→ `{created, updated, unbound}`；服务器停用 → 409 `INVALID_STATE`；连接/接口失败 → 502 `MEDIA_SERVER_ERROR` |

### Download Tasks

| Method | Path | 说明 |
|--------|------|------|
| POST | `/tasks` | 手动创建下载任务（绕过 Agent，见下文） |
| GET | `/tasks` | **全局**下载任务列表（分页，`page_size`≤100；可选过滤 `downloader_id`/`agent_id`/`status`，status 非法值 422；`created_at` 倒序）。供外部消费者（如 vault-organizer）按通知 payload 的 `download_task_id` 寻址查询 |
| GET | `/agents/{agent_id}/tasks` | Agent 的下载任务（分页）。与 `/downloaders/{id}/tasks` 共用 `app/api/v1/task_listing.py` 的任务列表能力：内联 `file_resource` 及作品/合集关联（供共享任务表格渲染作品列与 metadata 列）、返回**展示用有效状态**（cancelled+completed_at → completed/organized）、`status` 过滤按有效状态语义（`completed` 含 organized 行）、`sort` 同规格（key ∈ `status`/`created_at`/`progress`/`title`，缺省 `status:asc,created_at:desc`） |
| GET | `/tasks/{id}` | 任务详情（含 file_resource、agent、channel 信息） |
| POST | `/tasks/{id}/pause` | 停止（暂停，调用 Transmission RPC） |
| POST | `/tasks/{id}/resume` | 恢复 |
| POST | `/tasks/{id}/retry` | 重试（重置 retry_count，重新添加 torrent） |
| POST | `/agents/{agent_id}/tasks/batch-retry` | 批量重试：对 Agent 下多个 error/paused 任务统一执行重试 |
| DELETE | `/tasks/{id}` | 删除任务（删除 Transmission 种子并将任务标记 `cancelled`）；query 参数 `delete_data=false` 控制是否同时删除已下载数据 |

`POST /tasks` 手动创建下载任务：

- 请求体：`{ "resource_id": "uuid", "downloader_id": "uuid" }`。
- 成功返回 **201**，`data` 为 `DownloadTaskResponse`；提交下载器成功时 `status="downloading"` 且带 `transmission_torrent_id`/`confirmed_at`，失败时任务仍创建但 `status="error"` 并带 `error_message`。
- 错误码：`NOT_FOUND`（404，resource 或 downloader 不存在）、`VALIDATION_ERROR`（422，请求体缺字段）。
- 手动任务的 `agent_id` 固定为 `null`；`download_dir` 直接使用 Downloader 根目录（不加子目录）；不做去重检查（手动创建是显式用户意图，允许重复）。

任务重试规则：`POST /tasks/{id}/retry` 必须优先使用该任务已持久化的 `download_dir` 重新添加 torrent，而不是重新读取当前 Agent/Downloader 配置；这样 Downloader 默认目录或 Agent 子目录后续变更不会改变历史任务的落点。

`POST /agents/{agent_id}/tasks/batch-retry` 请求体：`{ "task_ids": ["..."] }`；`task_ids` 为 `null`/缺省表示重试该 Agent 全部可重试任务。仅 `status` 为 `error`/`paused` 的任务参与（与行级重试按钮条件一致），其余状态跳过；每个任务复用单任务重试语义（使用任务持久化的 `download_dir`），逐条捕获错误，最后统一 commit。响应 `data`：
```json
{ "processed": 10, "retried": 9, "failed": 1, "errors": ["<task_id>: <原因>"] }
```

### Pending Decisions

| Method | Path | 说明 |
|--------|------|------|
| GET | `/agents/{agent_id}/decisions` | Agent 多候选下载决策列表（分页，可按 status 查询；资源 metadata 确认不在此返回） |
| POST | `/decisions/{id}/confirm` | 确认选择某个候选资源 → 推送下载 |
| POST | `/decisions/{id}/skip` | 跳过本次决策（标记 skipped） |
| POST | `/decisions/{id}/ai-pick` | AI 自动处理：让 LLM 选中最优候选（优先复用缓存的 `llm_picked_resource_id`，否则即时调用 LLM）并派发下载 |
| POST | `/agents/{agent_id}/decisions/batch` | 批量处理：对多条 pending 决策统一执行 `skip` 或 `ai` 动作 |

`POST /decisions/{id}/confirm` 请求体：`{ "resource_id": "uuid" }`。所有决策操作均要求至少两个合格候选；旧版单候选资源修订行返回 409 `INVALID_STATE`。

确认和 AI 派发在最终提交阶段重新校验：至少两个不同候选、未过期、频道归属、当前订阅/过滤规则、频道必填字段，以及与持久决策 scope 一致的覆盖度。资源已删除、覆盖改变或资格失效返回 409 `INVALID_STATE`，不使用旧推荐继续派发。模型准备期间候选集合或 scope 改变也拒绝；模型准备阶段不持有最终确认锁。跳过操作在锁内重新检查 pending，不能覆盖已处理的历史状态。旧表的无键 pending 必须先按 [审核迁移流程](db-migration.md#待决策覆盖身份的审核迁移) 处理。

`POST /decisions/{id}/ai-pick` 无请求体。决策非 `pending` 状态返回 `400 NOT_PENDING`；LLM 未能给出选择返回 `400 LLM_NO_PICK`（需手动确认）。响应 `data`：`{ "id", "status", "decided_resource_id", "decided_at" }`。

`POST /agents/{agent_id}/decisions/batch` 请求体：`{ "decision_ids": ["..."], "action": "skip" | "ai" }`。仅处理 `status="pending"` 的决策；响应 `data`：
```json
{ "processed": 10, "dispatched": 7, "skipped": 2, "failed": 1, "errors": ["<decision_id>: <原因>"] }
```

批量 AI 先准备全部推荐，再逐项锁定与重校验；每项在 SAVEPOINT 内执行，只有成功退出该项事务后才增加成功计数。业务拒绝回滚该项并计入 failed；可重试锁错误或外层事务失效交由请求边界整体回滚，不返回虚假的部分成功。

### Download Notifications（下载完成通知）

完整语义（模型、聚合状态机、payload 契约、fan-out 与退避策略、下游清理 API）见 [notifications.md](notifications.md)。投递为纯出站：无 token、无消费者回调端点（旧版 start/ack/fail 已删除）。**快照契约版本 `version: 2`**（作品单季化，破坏性变更）：`work.seasons` 删除、`work.episodes[]` 去 season 分量、`work` 增加 `season_number`/`number_of_episodes`；v1 快照无 `version` 键，下游迁移指引见 notifications.md「快照 payload（契约）」。

| Method | Path | 说明 |
|--------|------|------|
| GET | `/agents/{agent_id}/notifications` | 该 Agent 的通知队列（分页；`status` 按**聚合状态**过滤 pending/done/failed，其他值 422；列表项不含 payload，带聚合 `status` 与 `delivery_summary {total,done,failed,pending}`） |
| GET | `/notifications/{id}` | 通知详情：完整 payload 快照 + `deliveries` 数组（每条含 webhook_url/status/attempt_count/error_message/delivered_at/next_attempt_at）；`payload.work.genre` 为封闭 TMDB 27 类枚举（完整取值见端点 /docs 描述与 data-models.md「genre 取值约定」） |
| GET | `/agents/{agent_id}/webhooks` | webhook 列表（`[{id, url, mock, enabled, created_at}]`） |
| POST | `/agents/{agent_id}/webhooks` | 注册 webhook：`{ "url": "...", "mock": false, "enabled": true }` → **201**；非 mock 必须 http(s) url（422）；注册后立即对积压通知 fan-out |
| PUT | `/agents/{agent_id}/webhooks/{webhook_id}` | 更新 webhook（部分更新 `{url?, mock?, enabled?}`；重新启用后同样立即 fan-out 恢复投递） |
| DELETE | `/agents/{agent_id}/webhooks/{webhook_id}` | 删除 webhook（delivery 历史随 CASCADE 删除；通知行保留） |
| POST | `/agents/{agent_id}/notifications/regenerate` | 重新生成：`{ "since": datetime \| null }`（null=从最早 completed 任务开始），对该 Agent 的 completed 任务重跑完整生成链路——无通知的补建、已有的重建 payload 并复位投递重投；当次拿不到 torrent 文件清单时保留旧快照；返回 `{ "created": n, "regenerated": m }` |
| POST | `/notifications/{id}/retry` | 单条手动重试：body `{ "mode": "failed" \| "all" }` → `{ "reset": n }`；`failed` 仅重置 failed delivery，`all` 重置全部非 pending（done + failed）delivery，重置后立即到期 |
| POST | `/notifications/retry` | 批量重试：body `{ "mode": "failed" \| "all", "since"?: datetime, "agent_id"?: uuid }` → `{ "reset": n }`；`since` 按通知 `created_at` 过滤，缺省为全库范围 |

### 内置文件整理（Organize）

完整语义（模型、规则与命名模板、两阶段规划/执行、触发链路）见 [file-organization.md](file-organization.md)。

##### Libraries

Library 为媒体服务器**扫描派生**（R2），收敛为只读 + 局部更新：无 POST（手工注册移除）；响应中 `root_path` 为派生展示字段（`volume.mount_path + root_subpath` 解析结果，未绑定为 null），`bound` 为绑定状态。

历史 root/recycle 路径不安全时返回 `root_path=null`、`path_error` 原因（正常为 null），不会使整个列表失败；bound 仍表示有卷绑定。扫描结果中危险的已绑定 Location 返回 502 `MEDIA_SERVER_ERROR`，整个扫描批次无新增/更新。

| Method | Path | 说明 |
|--------|------|------|
| GET | `/libraries` | 库列表（不分页，量小；每项含 `pending_plan_count`、`bound`、派生 `root_path`；`unbound=true` 过滤待绑定） |
| GET | `/libraries/{id}` | 详情（含来源服务器 `media_server_id`/`media_server_name`、`server_path`、解析后的 `root_path` 展示） |
| PUT | `/libraries/{id}` | 仅可更新 `subtitle_lang_map` 与 `volume_id`/`root_subpath`（待绑定就地修复；volume 不存在 404，root_subpath 非法 422）；其余字段由扫描派生，提交即 422 |
| DELETE | `/libraries/{id}` | 删除；存在 **pending/running** 关联计划或指向该库的规则时 **409 `DELETE_BLOCKED`**；done/failed/cancelled 计划不阻断（删除时解除其 library 引用、历史行保留） |

##### Organize Rules

| Method | Path | 说明 |
|--------|------|------|
| GET | `/organize-rules` | 规则列表（priority 升序、created_at 稳定排序；first-match-wins 的求值顺序） |
| POST | `/organize-rules` | 创建 → **201**；`filter` 经 `validate_filter_config`（非法结构/取值操作符空 value → 422）；`path_template` 经 `validate_template`（非法占位符/绝对路径/`..` 段 → 422）；`file_op` 限 `move`/`hardlink`/`copy`（其他 → 422；hardlink/copy 为保种模式，见 file-organization.md 清理策略分流）；`library_id` 不存在 → 404 |
| GET | `/organize-rules/{id}` | 详情 |
| PUT | `/organize-rules/{id}` | 部分更新（含 priority 调整；filter/模板/library 同上校验） |
| DELETE | `/organize-rules/{id}` | 删除；已有计划的 `rule_id` SET NULL 保留历史 |
| POST | `/organize-rules/preview` | dry-run 预览：body `{notification_id 或 resource_id（二选一，422/404）, rule?: <规则草稿>, category?}`；按草稿（缺省=当前规则列表 first-match）渲染，返回 `{matched_rule, library, category, needs_category, uncategorized, ops:[{op_type, src, dst, size, reason}]}`；resource_id 形态 best-effort 经下载器 RPC 取文件清单（只读不停种）；规划失败（PlanError）→ 422 带原因；**不落库不动磁盘** |

##### Plans / Audit

| Method | Path | 说明 |
|--------|------|------|
| GET | `/organize/plans` | 计划列表（分页；`status`（非法值 422）/`library_id` 过滤；created_at 倒序；列表项不含 payload，带 `revision`/`file_op`/`needs_category`、`rule_name`/`library_name`、`ops_summary {total,move,keep,movedir}` 与派生 `pending_reason: "unclassified" \| "unbound" \| null`——library 未定/缺 category → unclassified，目标库未绑定卷 → unbound，仅 pending 计划派生） |
| GET | `/organize/plans/{id}` | 详情：完整 payload 快照 + ops 数组 + audit_entries 时间线（同带 `pending_reason`） |
| POST | `/organize/plans/{id}/execute` | 后台执行（**202** + 当前状态）；pending/failed 及崩溃遗留 running 可执行，共享锁域内任一进程正在执行的计划 → **409 `ALREADY_RUNNING`**，done/cancelled / 待分类 / 缺 category / 待绑定 → **409 `INVALID_STATE`** |
| POST | `/organize/plans/execute-batch` | 批量执行 `{plan_ids: [...]}` → `{results: [{plan_id, status}]}`；锁内逐个，单个失败不影响其余 |
| POST | `/organize/plans/{id}/classify` | 待分类计划人工指定 `{library_id, category?}`：重渲染全部 op 的 dst 并复位 pending；非 pending/failed → 409；library 不存在 → 404；重渲染失败（如模板含 `{category}` 但未指定）→ 422 |
| POST | `/organize/plans/{id}/cancel` | 取消 pending/failed 及崩溃遗留 running 计划 → cancelled（记 audit）；共享锁域内任一进程正在执行的计划 → **409 `ALREADY_RUNNING`**；done/cancelled → **409 `INVALID_STATE`**。可选 body `{delete_task, delete_data}`：`delete_task=true` 同时删除关联下载任务（移除下载器 torrent、任务行置 cancelled，保留磁盘数据，与 `DELETE /tasks/{id}?delete_data=false` 共用 `task_cleanup` 实现）；`delete_data=true` 蕴含删除任务并连同磁盘数据一起删除；清理失败不阻断取消，结果随响应 `task_cleaned` 返回（未请求删除时为 null） |
| GET | `/organize/audit` | 审计条目分页（`plan_id` 过滤；最新在前） |

### File Resources

| Method | Path | 说明 |
|--------|------|------|
| GET | `/channels/{channel_id}/resources` | 频道资源列表。默认（`grouped=false`）按 `published_at` 倒序、按行分页返回。`grouped=true` 时按 **作品分组**分页——每一页返回若干个 group（TVSeries / Movie / 未识别），每个 group 内包含该作品全部资源（不跨页拆分），group 顺序按各自最新资源的 `published_at` 倒序；`meta.total` 表示 group 总数。 |
| GET | `/channels/{channel_id}/field-values` | Filter DSL 编辑器的自动补全数据源。Query 参数 `field`（必填，仅支持字符串字段与 `subtitle_langs`）、`q`（可选，忽略大小写的前缀匹配）、`limit`（默认 10，最大 50）。返回该频道下 top-N 出现频率最高的候选值数组。数值型字段被拒绝（422）。|
| GET | `/resources/{id}` | 资源详情。返回 **Detail schema**：基础资源字段 + `season_ranges`（逐季集数范围）+ `work_links[]`（合集多作品关联，含 `source` provenance 与服务端解析的 `work_title`）+ `file_assignments[]`（文件级映射：path/size/work FK/hint/season/episode_start/end/source）。列表端点仍返回精简基础 schema |
| GET | `/resources/{id}/metadata` | 获取 metadata（若未链接则触发自动匹配流程，返回匹配结果；匹配中返回 status=processing 可轮询）；链接为剧集时 `linked.entity` 额外携带 `seasons`（每季 `season_number`/`episode_count`），供集号修正 UI 从绝对集号前端预填季号 |
| GET | `/metadata/sources` | 统一来源目录：三种主来源、可用状态、可信站点及默认顺序 |
| POST | `/metadata/search` | 统一只读搜索：`{query, content_type, mode, source?, trusted_sites?}`；`trusted_sites=null` 使用默认顺序，`[]` 禁用全网回退；返回本地或在线规范化候选。**`source=bangumi` 时为列表模式**：不走 search-then-judge 收敛管线（不调 LLM），`list_bangumi_subjects` 多查询合并去重（limit 20、仍限动画分类 type=[2]），每个 subject 返回一条薄候选（身份 `bangumi:{id}`、标题/年份/海报/简介，`metadata.subject_season` 标注条目自身季标记——含 Stage 序数——供前端对照 season_hint）；剧场版 platform 条目 content_type=movie，受请求 content_type 边界过滤 |
| POST | `/works/metadata/preview` | 预览在线候选与现有作品的字段差异及人工保护状态，不写库。bangumi 列表模式的薄候选（metadata 缺 `episode_list`）先按需展开——`build_entity_for_subject` 按 subject id 取详情+剧集端点补齐完整 entity（season 取作品自身 `season_number`）再比对；展开失败保留薄候选，diff 相应变少 |
| POST | `/works/metadata/apply` | 应用已确认候选；同步候选提供的非人工字段，空值不清空，身份冲突返回 409。候选扩展/海报获取期间作品季号或合集变化也返回 409，须重新刷新候选。bangumi 薄候选同样按需展开（与 preview 共享同一份展开值，不重复取网），展开后的 `episode_list` 照常 upsert Episode 行 |
| PATCH | `/resources/{id}/episode` | 手动修正集号：`{ "episode": int|null, "season": int?, "absolute_episode": int|null?, "note": string? }` → 写入 per-season episode（可选保留 absolute_episode），设置 `episode_confidence="manual"`。未显式发送 `season` 且已知 absolute 集号、资源已链接剧集时，服务端沿该作品的**合集成员**定位（`locate_absolute_episode_in_collection`：成员按 `season_number` 累加 `number_of_episodes`）并把资源**重指向**定位到的季作品（legacy 未拆分行回退其自身逐季集数）；episode 也未显式发送时一并推导——显式值永远优先。**先 commit 再入队**（worker 只读已提交数据，避免读到修正前的 `ambiguous` 而重建过期决策），然后对该 channel 下所有 active Agent 入队一次**定向运行**（`resource_ids=[该资源]`）：按 Agent 当前规则只处理该资源，**绕过消费水位线**（资源可能较旧）、**不推进水位线**。省略 `absolute_episode` 时保留原值。提交前对同作品+同频道仍 `ambiguous/raw` 的兄弟资源套用新建立的编号约定批量修复（`heal_sibling_episodes`）， healed 行随本次定向运行一并派发（`resource_ids=[该资源, *healed]`）。三个修订端点（本行与下两行）均在 commit 之后、入队之前对 `torrent_file` 缺失的 http(s) 直链资源 best-effort 重建 torrent 缓存（`ensure_torrent_cached` + `maybe_inspect_torrent`，失败静默不阻断主流程），使文件映射随定向重跑一并重建。 |
| PATCH | `/resources/{id}` | 人工修订解析字段（`ResourceParseCorrectionRequest`）：`{ "episode"?, "season"?, "absolute_episode"?, "episode_start"?, "episode_end"?, "is_batch"?, "batch_scope"?: "season"\|"multi_season"\|"franchise"\|"movies", 通用字段?: resolution/subtitle_group/source/video_codec/audio_codec/subtitle_type/container/subtitle_langs }` —— 全可选，仅显式发送的字段被更新（`model_fields_set` 语义）。服务端强制合集不变量（与抓取期 pre-parser 对齐）：`is_batch=true` 强制 `episode=null` 且未显式发送 scope 时缺省 `batch_scope="season"`；`is_batch=false` 清空 `batch_scope`/`episode_start`/`episode_end`。显式发送 `episode`/`season`/`absolute_episode` 任一即置 `episode_confidence="manual"`；未发送集号字段但修订结果为 `is_batch=true` 且原为 `ambiguous` 时同样置 `manual`（合集无单集概念，标记合集即了结集号/季号问题）；**通用媒体描述字段不触碰 `episode_confidence`**。**先 commit 再入队**对该频道全部 active Agent 的定向运行（语义同 PATCH `/episode`，发送集号字段时同样先跑 `heal_sibling_episodes` 批量修复兄弟资源）。旧 `PATCH /resources/{id}/episode` 保留。 |
| PUT | `/resources/{id}/associations` | 编辑向导统一提交（`ResourceAssociationUpdateRequest`）：`{ "is_batch": bool, "works": [{work_type, work_id}], "collection_id"?, "assignments": [{file_path, work_type, work_id, file_size?, season?, episode_start?, episode_end?}], "season"?/"episode"?/"absolute_episode"?(仅非合集分支), "fields"?: 通用字段及 title_cn/title_en/search_title }` → 原子应用全部不变量：非合集至多一个作品（写入互斥 FK，清空 links/assignments/collection）；合集恰一作品时镜像到 FK（保 dedup coverage key），多作品清 FK 仅留 links；`batch_scope` 自动推导（全 movie→movies；tv+movie 或多 tv→franchise；单 tv→season/multi_season 按季证据）；单季合集从 assignments 同步资源级 `season/episode_start/episode_end`，跨季合集清空这些扁平字段并使用 `batch_seasons/season_ranges`（两者为从关联季作品派生的冗余缓存）；assignments 必须引用 works 集合、TV 文件必须带季、同 (work, season) 集号区间**重叠→422**、断档→200+warnings；**两级关联（TV 先合集后季作品）**：提交 `collection_id` 时 `works` 中每个剧集作品必须属于该合集（不一致 422）；**多作品合集（>1 作品）文件清单完整性**：每个关联作品至少一条指派、已知 torrent 清单的媒体文件全部被指派（清单不可得时该子项降级 warning）、各季作品指派区间覆盖其 `number_of_episodes` 应有集数（整段缺失 422、首尾断档 200+warnings）；works 在线候选物化时若季号不可定（upsert 返回 None）→ 422 提示先关联合集下的具体季作品。work links 与 assignments 均按差量更新，重复保存幂等。works 为空的非合集提交保留现有挂载（含音频链接）。先 commit 再定向 Agent 重跑；响应为 Detail schema + `warnings[]` |
| POST | `/resources/{id}/analyze-batch` | 向导第二步重析（**不落库**）：按 files 端点同一解析链取清单 → 返回 `{ "suggestion": { "deterministic": {scope_hint, seasons, season_ranges, files:[{path,size,season,episode}], clusters:[{title,files}]}, "works": [{candidate_key,title,content_type,files:[...]}] }, "listing_source" }`。**deterministic 层始终返回**（纯路径解析无需 LLM，并支持 `Title 01;` archive 格式）；`works` 的 candidate_key 只能来自服务端候选作品集合，后端校验后返回，标题仅作兼容提示；无清单时 `suggestion=null` |
| POST | `/resources/{id}/analyze-batch-stream?force=false` | 上述重析的 SSE 交互端点；web 按资源/标题/torrent 清单/解析版本指纹读取持久缓存，未命中则以 `batch-analysis:<fingerprint>` 幂等键提交 `analyze_batch_files` 后台任务，并轮询队列的共享进度状态转发 `status` / LLM `delta` / `warning` / `result`。`force=true` 仅供用户主动「重新解析」在旧任务结束后以同 key 重新入队并覆盖旧缓存；Redis Queue 的 active-key 原子去重保证多 web/多窗口只执行一次，SSE 断开不取消 worker 任务。 |
| GET | `/resources/{id}/files` | 资源 torrent 文件清单（`ResourceFilesResponse`）：`{ "files": [{"name", "size"}], "source", "magnet_resolve"? }`，`source` 记录清单来源（首个命中即返回）：`torrent_cache`（本地缓存 .torrent 经 bencode 解析）→ `torrent_fetch`（http(s) `torrent_url` 现场下载，缓存路径写回 `torrent_file`）→ `downloader`（最新 DownloadTask 的下载器 RPC `get_torrent_files`，失败静默）→ `notification`（最新完成通知冻结快照 `payload.files`）→ `none`（全部不可用，返回空 `files`）。`magnet_resolve` 仅当 `torrent_url` 为 magnet: 且无清单时返回：`{ "status": null\|"pending"\|"running"\|"done"\|"failed", "error", "attempts", "updated_at", "trackers" }`（status 为 null = 从未解析，UI 按排队语义展示；trackers 为存储的自定义 tracker 列表，null=仅默认）。404 遵循统一错误结构。 |
| POST | `/resources/{id}/magnet-resolve` | magnet 元数据解析手动重试（重置 `magnet_resolve_attempts=0`、`magnet_resolve_error=null` 后重新入队 `resolve_magnet_torrent`，**先 commit 再入队**；响应 `{ "magnet_resolve": {...} }` 状态块，含 `trackers`）。可选 body `{ "trackers": [str, ...] \| null }`：非空经 `validate_tracker_urls` 严格校验（udp/http(s) scheme + 非空 host + 无空白/控制字符，≤20 条、每条 ≤200 字符；非法 → 422 `VALIDATION_ERROR`，消息含首个违规 URL）并持久化到 `magnet_resolve_trackers`（failed 保留供预填、done 清空）；省略/null/空列表 → 清空为 NULL（仅用默认 tracker）。404 资源不存在；422 `VALIDATION_ERROR`（非 magnet 链接 / libtorrent 不可用 / `MAGNET_RESOLVE_ENABLED=false`）；409 `INVALID_STATE`（status 为 pending/running 解析进行中）。 |
| POST | `/resources/{id}/reparse-metadata` | 完整后台元数据重新解析（编辑向导「重新解析元数据」按钮）：写入 `confirmation_ignored_at`（资源立即退出 Dashboard 待确认——**临时忽略**，与手动忽略的差异见 data-models）→ **先 commit 再入队** `reprocess_resource_metadata`（key `reprocess-resource:{id}`，payload `{resource_id, channel_id}`），任务跑抓取期完整元数据管线（`_process_resource_metadata`，`force_refresh=True` 绕过缓存）并在结束（**成败都**）清除忽略标记让待确认策略重评——数据仍不全重新进入待办、完整匹配留在外面；不创建定向派发请求；完成事件由普通增量按既有历史准入消费。不重置 `metadata_attempts`/`metadata_failure_type`（backfill 的 retry-eligibility 门控在调度侧，直接调用不受限）。404 资源不存在；key 已有活跃任务 → 409 `ALREADY_RUNNING`；成功响应 `{ "reparse": { "status": "pending" } }`。 |

`PUT /resources/{id}/associations` 成功提交后额外入队 `refresh_resource_organize`：对该资源已有 completed 任务原地刷新通知快照，并重建 pending/failed 变更计划。`GET /organize/plans/{id}` 返回 `resource_id`，供详情 Drawer 复用文件资源向导的「文件关联」步骤直接修订；非开放状态只读。

`POST /metadata/search` 请求体示例：
```json
{
  "query": "Ascendance of a Bookworm",
  "content_type": "tv",
  "mode": "online",
  "source": "tmdb",
  "trusted_sites": ["bangumi", "anilist", "tmdb", "wikipedia"]
}
```

响应 `data`：
```json
{
  "candidates": [
    {
      "title_cn": "...", "title_en": "...", "original_title": "...",
      "description": "...", "poster_url": "https://...", "year": 2024,
      "external_id": "...", "external_source": "tmdb", "content_type": "tv"
    }
  ]
}
```

### 作品仓库（Works）

统一的海报墙 API，合并 TVSeries 和 Movie 两种实体。

| Method | Path | 说明 |
|--------|------|------|
| GET | `/works` | 作品列表（分页，支持 search 模糊搜索和 content_type 过滤：all/tv/movie；`collection_id` 参数：合集 UUID=仅该合集成员（音频作品被排除），字面量 `none`=仅未分组作品，缺省=不过滤；tv/movie 条目带 `collection_id`/`collection_name`（显示名 = 合集 title_cn 或 title_en，未分组为 null）与 `is_anime`（可空布尔三态，见下），剧集条目另带 `season_number`（作品单季化：该作品是第几季，0=特典），音频条目无合集恒为 null） |
| POST | `/works/merge` | 手动合并作品（作品单季化的常规修复工具，见 data-models.md 去重与 per-season-works.md）：body `{survivor_type: "series"\|"movie", survivor_id, duplicate_ids, confirm: true}` → 复用去重合并机器把 `duplicate_ids` 合并进 `survivor_id` 并删除重复行（FileResource/AgentWork/ChannelRawTitleMapping/PendingDecision/Episode/合集 links/文件 assignments 全部重指向，身份袋取并集）。仅同类型可合并，series 另限同 `season_number`（作品即季，跨季合并会破坏模型，422）；`confirm` 非 true → 422 带不可逆警告文案（前端据此弹确认框）；survivor_id 出现在 duplicate_ids / 列表为空 → 422；任一 id 不存在 → 404。响应带各项重指向计数与 notes |
| POST | `/works/batch-refresh-metadata` | body `{items, source, trusted_sites}`；后台使用统一搜索服务并同步候选提供的非人工字段 |

### TVSeries

`genre` 字段（Create/Update/Response）为封闭 TMDB 27 类枚举（/docs 中 `GenreName` 渲染完整取值，约定见 data-models.md「genre 取值约定」）；Create/Update 提交表外值返回 422。`is_anime` 字段（Create/Update/Response）为可空布尔三态（True=日本动画 / False=确认实拍 / null=未判定，判定与赋值规则见 data-models.md「is_anime 判定约定」）；Create/Update 接受手动指定。`manually_edited_fields`（Response 透出，不可直接提交）为人工编辑保护字段名列表：PUT 时按显式发送的 `MANUAL_EDITABLE_FIELDS` 字段（含显式 null）记录，自动扫描不再覆盖。`MANUAL_EDITABLE_FIELDS` 另含 `content_type`（Update 限 `tv`/`movie`）与 `external_id`/`external_source`（外部身份）：PUT 显式发送且身份实际变化时，先把旧 `(external_source, external_id)` 幂等写入 `WorkExternalId` 身份袋（id 已被其他作品占用则冲突不抢、仅记 warning），再覆盖主列——作品在旧身份下仍可反查。

| Method | Path | 说明 |
|--------|------|------|
| GET | `/series` | 列表（分页，支持 title 模糊搜索） |
| POST | `/series` | 手动创建季作品，并在同一事务建立 series_group 壳合集 |
| GET | `/series/{id}` | 剧集详情（含 episodes、资源数、任务数） |
| PUT | `/series/{id}` | 更新剧集元数据（别名合并策略：追加不去重）；显式发送的可编辑字段记入 `manually_edited_fields`（含 `content_type`/`external_id`/`external_source`，身份变更旧值先入 WorkExternalId 身份袋，见上）；`content_type` 显式改为非 tv（如 movie）时，联动清除该剧集下资源残留的 `episode_confidence="ambiguous"`（置 null——非 tv 作品无集号/季号问题） |
| DELETE | `/series/{id}` | 删除剧集；AgentWork 或人工作品链接、文件映射、标题映射引用时返回 409 DELETE_BLOCKED。允许删除时同事务清理身份袋、解除资源与自动文件映射的作品绑定，保留文件路径与资源 |

### Movies

`is_anime` 字段（Create/Update/Response）同 TVSeries：可空布尔三态，Create/Update 接受手动指定。`manually_edited_fields` 同 TVSeries：PUT 记录显式编辑字段，自动扫描跳过。

| Method | Path | 说明 |
|--------|------|------|
| GET | `/movies` | 列表（分页，支持 title 模糊搜索） |
| POST | `/movies` | 手动创建电影元数据 |
| GET | `/movies/{id}` | 电影详情 |
| PUT | `/movies/{id}` | 更新电影元数据；显式发送的可编辑字段记入 `manually_edited_fields`（含 `content_type`/`external_id`/`external_source`，身份变更旧值先入 WorkExternalId 身份袋，语义同 PUT `/series/{id}`） |
| DELETE | `/movies/{id}` | 删除电影；引用保护及身份/自动文件映射处理同剧集删除 |

系列/电影详情响应额外包含 `collection`（`{id, name}` 或 null）与 `collection_siblings`（同合集其他作品 `[{id, title, year, type}]`，剧集条目另带 `season_number`，供详情页季切换器按季排序跳转；来自本地库共享 collection_id 查询）。响应顶层同时暴露 `external_id`/`external_source`、`canonical_name`/`wikipedia_url`（Wikipedia 实际 URL，优先于 curid 回退），以及服务端计算的 `source_links`（`[{source, label, url}]`，由站点注册表 `metadata_source_registry.build_source_links` 生成，支持旧复合形 `TMDB:NNN; IMDb:ttNNN` 拆分，TMDB 链接按 tv/movie 区分路径）——前端详情页直接渲染，不再自行解析。

### WorkCollections（作品合集）

大 IP 系列分组（CRUD-lite）。一个作品至多属于一个合集；挂载已属其他合集的作品返回 409 DUPLICATE_SUBMISSION——**例外**：当前合集为单成员 `external_source="series_group"` 壳合集（季作品 upsert 的自动产物）时，attach 直接吸收该壳（身份袋与 aliases 去重并入目标、目标已有值优先、删除空壳、作品重挂目标），多成员壳或其他 source 的合集仍 409。

| Method | Path | 说明 |
|--------|------|------|
| GET | `/collections` | 合集列表（分页，支持 search 名称模糊搜索；每项额外带 `work_count` 成员作品数） |
| POST | `/collections` | 创建合集（body: title_cn 必填，title_en/description/poster_url 可选） |
| GET | `/collections/{id}` | 合集详情（含 `works`: `[{id, title, year, type}]`；`?include_parts=true` 且合集为 `tmdb_collection` 源时额外返回 `untracked_parts`: `[{tmdb_id, title, year, poster_url}]` —— TMDB collection parts 中本地库未收录的作品，按需拉取、进程内 10 分钟缓存、不落库；拉取失败返回空数组） |
| GET | `/collections/{id}/works` | 合集成员作品分页列表（`page`/`page_size`；每项与 `GET /works` 相同的归一化结构，content_type 为 `tv`/`movie`；**季作品在前按 `season_number` 升序**（特典 0 居首），电影在后按 created_at 倒序） |
| PATCH | `/collections/{id}` | 更新合集（title_cn/title_en/description/poster_url） |
| DELETE | `/collections/{id}` | 删除合集（季作品重挂新壳，电影可无合集；同步资源及身份袋，不删作品） |
| POST | `/collections/{id}/works` | 挂载作品（body: `{work_type: "series"\|"movie", work_id}`；重复挂载同合集幂等） |
| DELETE | `/collections/{id}/works/{work_id}?work_type=` | 从合集移除作品（季作品重挂新壳，电影 collection_id 置空；保留作品和文件指派） |

---


整理计划列表/详情的 `file_op` 是当前计划版本的冻结模式（历史未知为 null），`needs_category` 来自相同版本；不能用当前规则覆盖。执行 202 前探测跨进程忙碌，实际后台执行仍必须独立取得所有权；旧 running 缺模式或锁域无效返回 409 INVALID_STATE。pending/failed 配置过期由执行入口先重建当前版本。取消需同一共享锁与状态 CAS，提交 cancelled 后才可清理任务/数据，失败结果不回写过期版本。


Agent 新建/编辑的 rules-preview 回填若发生内部候选持久化错误，返回 500 INTERNAL_SERVER_ERROR 并回滚本次保存（配置、订阅、任务和水位线均不部分提交）；错误响应不回显底层 SQL。客户端可在问题修正后重试所选资源。普通未回填保存及空数组推进水位线的既有语义不变。下载器已接收的种子不能随数据库回滚，重复提交由下载器按 infohash 去重。


资源修订补偿：`PATCH /resources/{id}/episode`、`PATCH /resources/{id}`、`PUT /resources/{id}/associations` 将资源及 active Agent 的持久重跑请求一起提交；前两者包含自动修复的兄弟资源。请求写入失败回滚修改；提交后队列忙碌或不可用仍返回保存成功，由周期分发补偿。响应结构不变，保存成功不代表下载已派发。


合集生命周期：删除与解绑保留作品 UUID、季号、人工 work_links/file_assignments；关联多新合集的资源清空单一合集指针，不猜归属。无作品依据的 collection-only 资源在删除合集时清指针，单独解绑成员时保留原合集。所有变更同事务提交。attach 在锁定来源/目标后重读成员，若已移到其他未锁定合集返回 409 INVALID_STATE；等待期间目标不存在返回 404。并发重复删除只允许一个成功，后续请求返回 404。

### 合集挂载同季冲突

`POST /collections/{id}/works` 指派剧集时，目标已有同 season_number 作品（含 S0）返回 409 `DUPLICATE_SUBMISSION`。拒绝不迁移来源壳合集的身份袋、别名或资源指针。已属于目标的同一作品重复提交仍幂等成功；电影不应用剧集季号约束。检查后竞争导致数据库唯一约束失败时，完整挂载 SAVEPOINT 回滚并返回同样的 409。


`POST /series` 和 `PUT /series/{id}` 不接受退役字段 `number_of_seasons` / `seasons`；显式传入（包括 null）返回 422 VALIDATION_ERROR，整次请求不写入作品、壳合集或人工保护字段。读取响应暂保留旧 number_of_seasons 供历史数据诊断；作品身份以 season_number 为准，普通 API 不得借退役列声明多季作品。


### Agent 发布进度的 API 语义

响应中的 `last_consumed_at` 保持时间格式，但不再充当发布事件游标。普通 null/未传回填数组保存不移动消费边界；实际规则或派发设置变更、订阅 CRUD 使旧运行 generation 失效，同频道仅改名保持进度。已确认资源不因普通规则保存自动重放。

普通频道切换保持时间字段，以旧时间下界保留新频道历史候选，发布 cursor 从 0 开始、baseline 取新频道当前提交前缀。NULL 时间且缺进度的 Agent 留待首次初始化。回填数组（含空）成功后原子重置进度，内部持久化错误整体回滚。

指定时间运行按 `created_at > scan_since` 选择，null 表示全历史；处理前持久化可恢复范围，失败后普通增量可补偿，成功只确认开始时发布前缀。显式回填重置优先于旧扫描确认。显式资源修订请求继续使用独立 B9 持久请求，不受普通历史排除影响。

### OTP 请求额度与 429

POST /api/v1/auth/otp 在验证码验证前预留持久额度：每来源 5 次/60 秒，全局 30 次/60 秒。窗口从首次预留开始；到期重置，不因拒绝延长。成功登录和验证失败均计数，来源超限的请求也计入全局额度；全局拒绝不新增来源桶。超过任一额度返回 429，error.code=RATE_LIMITED，Retry-After 为至少 1 的剩余秒数，不签发 Cookie。通过 OTPRequest 校验的字符串都计数；schema 错误直接 422，不执行 OTP 验证或预留。GET /auth/status、POST /auth/logout 不受该额度限制。
