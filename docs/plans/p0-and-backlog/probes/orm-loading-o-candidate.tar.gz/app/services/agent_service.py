"""Agent service: DSL-based resource filtering and dispatch."""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from sqlalchemy import and_, delete, inspect, or_, select, text
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.config import settings
from app.models.agent import Agent
from app.models.agent_suggestion import AgentSuggestion
from app.models.download_task import DownloadTask
from app.models.downloader import DownloaderInstance
from app.models.file_resource import FileResource
from app.models.movie import Movie
from app.models.pending_decision import PendingDecision
from app.models.resource_work_link import ResourceWorkLink
from app.models.series import TVSeries
from app.services.filter_engine import (
    evaluate_field_condition,
    evaluate_filter_config,
    loaded_relation,
    merge_filters,
)
from app.services.resource_confirmation import (
    LEGACY_CONFIRMATION_REASON_PREFIXES,
    inspect_resource_confirmation,
)
from app.services.runtime_config import runtime_config
from app.utils.download_paths import DownloadPathError, resolve_download_dir
from app.utils.time import utcnow

logger = logging.getLogger(__name__)


@dataclass
class RunResult:
    total_resources: int = 0
    matched: int = 0
    dispatched: int = 0
    pending_decisions: int = 0
    filter_failed: int = 0
    duplicates_skipped: int = 0
    unrecognized: int = 0
    suggestions: list[dict] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    # Resource ids that matched the agent's rules this run (passed work-scope
    # + filter). Populated for run-history display.
    matched_resource_ids: list[str] = field(default_factory=list)


_RESOLUTION_SCORE = {"2160p": 3, "4k": 3, "1080p": 2, "720p": 1}

_DEDUP_ACTIVE_STATUSES = ("pending", "queued", "downloading", "paused", "completed")


def _task_occupies_download_slot():
    """Return the SQL predicate for active or previously downloaded tasks."""
    return or_(
        DownloadTask.status.in_(_DEDUP_ACTIVE_STATUSES),
        and_(
            DownloadTask.status == "cancelled",
            DownloadTask.completed_at.is_not(None),
        ),
    )


@dataclass
class RuleSet:
    """A snapshot of the subscription rules used to test resource matching.

    Captured separately from the ``Agent`` ORM object so the diff logic can
    evaluate old vs new rules without mutating the persisted agent.
    """
    scope_channel_wide: bool
    filter_config: dict | None
    work_by_series_id: dict[str, Any] = field(default_factory=dict)
    work_by_movie_id: dict[str, Any] = field(default_factory=dict)


def _build_rule_set(agent: Agent) -> RuleSet:
    by_series: dict[str, Any] = {}
    by_movie: dict[str, Any] = {}
    for w in (agent.works or []):
        if w.series_id:
            by_series[w.series_id] = w
        if w.movie_id:
            by_movie[w.movie_id] = w
    return RuleSet(
        scope_channel_wide=agent.scope_channel_wide,
        filter_config=agent.filter_config,
        work_by_series_id=by_series,
        work_by_movie_id=by_movie,
    )


def _linked_series_ids(resource: FileResource) -> list[str]:
    """Series work ids carried on the multi-work link table.

    Per-season works (作品单季化): terminal multi-season packs clear the
    legacy work FKs and reference every linked season work through
    ``resource_work_links``. Only the already-loaded relationship is read
    (async sessions cannot lazy-load).
    """
    links = loaded_relation(resource, "work_links")
    if not links:
        return []
    return sorted({link.series_id for link in links if link.series_id})


def _resource_matches_rules(
    resource: FileResource, rules: RuleSet
) -> tuple[bool, Any]:
    """Filter-level match: does ``resource`` fall under this rule set?

    Returns ``(matched, work)`` where ``work`` is the subscribed AgentWork the
    resource resolved to (None for channel-wide). Matched is True when the
    resource is in scope (subscribed work, or channel-wide) AND passes the
    merged effective filter. This is intentionally *not* a dispatch decision
    — dedup / ambiguous / conflict handling are runtime concerns layered on
    top in ``process_resources``.

    Links-carried multi-season packs (no flat work FK) are in scope when ANY
    linked season work is subscribed.
    """
    work = None
    if not rules.scope_channel_wide:
        if resource.series_id and resource.series_id in rules.work_by_series_id:
            work = rules.work_by_series_id[resource.series_id]
        elif resource.movie_id and resource.movie_id in rules.work_by_movie_id:
            work = rules.work_by_movie_id[resource.movie_id]
        else:
            for sid in _linked_series_ids(resource):
                if sid in rules.work_by_series_id:
                    work = rules.work_by_series_id[sid]
                    break
            if work is None:
                return False, None
    effective = merge_filters(
        rules.filter_config, work.filter_overrides if work else None
    )
    if effective is not None and not evaluate_filter_config(effective, resource):
        return False, work
    return True, work


async def compute_rule_diff(
    old: RuleSet,
    new: RuleSet,
    resources: list[FileResource],
    db: AsyncSession,
) -> dict:
    """Diff resource matching between two rule sets over ``resources``.

    Used by the rules-preview endpoint (scenario ②): when subscription rules
    change, the user sees newly-matching resources (backfill candidates) and
    no-longer-matching ones (informational; in-queue tasks are never revoked).

    - ``newly_matching``: matches new rules, did NOT match old rules, and has
      no active DownloadTask → eligible for user-selected backfill.
    - ``no_longer_matching``: matched old rules, does NOT match new rules.
    - ``in_queue_skipped``: count of newly-matching resources skipped because
      they already have an active DownloadTask.
    """
    res_ids = [r.id for r in resources]
    tasked: set[str] = set()
    if res_ids:
        rows = (await db.execute(
            select(DownloadTask.file_resource_id).where(
                DownloadTask.file_resource_id.in_(res_ids),
                _task_occupies_download_slot(),
            )
        )).all()
        tasked = {row[0] for row in rows}

    newly_matching: list[FileResource] = []
    no_longer_matching: list[FileResource] = []
    in_queue_skipped = 0
    for r in resources:
        old_m, _ = _resource_matches_rules(r, old)
        new_m, _ = _resource_matches_rules(r, new)
        if new_m and not old_m:
            if r.id in tasked:
                in_queue_skipped += 1
            else:
                newly_matching.append(r)
        elif old_m and not new_m:
            no_longer_matching.append(r)
    return {
        "newly_matching": newly_matching,
        "no_longer_matching": no_longer_matching,
        "in_queue_skipped": in_queue_skipped,
    }


def _resolution_score(resolution: str | None) -> int:
    if not resolution:
        return 0
    return _RESOLUTION_SCORE.get(resolution.lower().strip(), 0)


def resolve_torrent_payload(resource: FileResource) -> str | bytes:
    """Pick the payload handed to the downloader's ``add_torrent``.

    When the fetch pipeline cached the .torrent file locally
    (``resource.torrent_file``), push its raw bytes so the daemon does not
    re-download it (dead links, private-tracker cookie requirements). Falls
    back to the URL/magnet when there is no cached file or it cannot be read.
    """
    if resource.torrent_file:
        try:
            return Path(resource.torrent_file).read_bytes()
        except OSError as e:
            logger.warning(
                "Cached torrent file unreadable for resource %s (%s): %s; "
                "falling back to torrent_url",
                resource.id, resource.torrent_file, e,
            )
    return resource.torrent_url


async def create_and_submit_task(
    resource: FileResource,
    downloader: DownloaderInstance,
    db: AsyncSession,
    agent_id: str | None = None,
    download_dir: str = "",
) -> DownloadTask:
    """Create a DownloadTask and attempt to add it to the downloader.

    Shared by agent dispatch and manual creation (``POST /tasks``).
    """
    from app.services.task_queue import current_job_identity, require_execution_ownership

    await require_execution_ownership()
    identity = current_job_identity()
    reservation = None
    payload = resolve_torrent_payload(resource)
    if identity is not None:
        from app.services.download_dispatch import operation_key, payload_digest, reserve_dispatch

        parameters = {
            "resource_id": resource.id, "agent_id": agent_id,
            "downloader_id": downloader.id, "download_dir": download_dir,
            "payload_digest": payload_digest(payload),
        }
        reservation = await reserve_dispatch(
            db.bind, operation_key(identity, resource.id, agent_id), parameters, job_identity=identity,
        )
        existing = await db.get(DownloadTask, reservation.task_id)
        if existing is not None:
            return existing
        if reservation.settled:
            raise ValueError("Queued download task was removed; refusing to recreate it")
        # Reservation can wait on another writer; recheck before starting RPC.
        await require_execution_ownership()
    task = DownloadTask(
        agent_id=agent_id,
        file_resource_id=resource.id,
        downloader_id=downloader.id,
        download_dir=download_dir,
        status="pending",
        max_retries=settings.max_retry_count,
    )
    if reservation is None:
        db.add(task)
    # NOTE: no flush before the RPC on purpose. Flushing would emit the INSERT
    # and acquire the SQLite write lock for the whole duration of the
    # downloader call (up to ``transmission_timeout`` seconds), stalling all
    # foreground writes. The RPC only needs constructor-set attributes, so we
    # flush once at the end instead.
    from app.clients.downloader import get_downloader_client

    wrapper = get_downloader_client(downloader)
    try:
        result = await asyncio.wait_for(
            wrapper.add_torrent(
                payload,
                download_dir=task.download_dir,
            ),
            timeout=settings.transmission_timeout,
        )
        task.status = "downloading"
        task.transmission_torrent_id = result["torrent_id"]
        task.confirmed_at = utcnow()
    except Exception as e:
        logger.warning("Failed to add torrent for resource %s: %s", resource.id, e)
        task.status = "error"
        task.error_message = str(e)[:2000]

    # The remote call may outlive this execution's lease. Leave the durable
    # reservation available for the replacement instead of settling stale output.
    await require_execution_ownership()
    if reservation is not None:
        from app.services.download_dispatch import persist_dispatch_result

        return await persist_dispatch_result(db, reservation, {
            "agent_id": agent_id, "file_resource_id": resource.id,
            "downloader_id": downloader.id, "download_dir": download_dir,
            "status": task.status, "max_retries": task.max_retries,
            "transmission_torrent_id": task.transmission_torrent_id,
            "confirmed_at": task.confirmed_at, "error_message": task.error_message,
        })
    await db.flush()
    return task


async def dispatch_download(
    agent: Agent, resource: FileResource, db: AsyncSession, *, consumption_snapshot=None
) -> DownloadTask:
    """Create a DownloadTask and attempt to add it to Transmission."""
    downloader = await db.get(DownloaderInstance, agent.downloader_id)
    if not downloader:
        task = DownloadTask(
            agent_id=agent.id,
            file_resource_id=resource.id,
            downloader_id=agent.downloader_id,
            download_dir=agent.download_subdir or "",
            status="error",
            error_message=f"Downloader {agent.downloader_id} not found",
            max_retries=settings.max_retry_count,
        )
        db.add(task)
        await db.flush()
        return task

    # Resolve the effective download directory, falling back to the downloader
    # root directory if subdir resolution fails.
    download_dir: str
    try:
        download_dir = resolve_download_dir(downloader.download_dir, agent.download_subdir)
    except DownloadPathError as e:
        download_dir = downloader.download_dir
        task = DownloadTask(
            agent_id=agent.id,
            file_resource_id=resource.id,
            downloader_id=agent.downloader_id,
            download_dir=download_dir,
            status="error",
            error_message=str(e),
            max_retries=settings.max_retry_count,
        )
        db.add(task)
        await db.flush()
        return task

    if consumption_snapshot is not None:
        from app.services.agent_publication_progress import require_current_scope

        await require_current_scope(db, consumption_snapshot)

    return await create_and_submit_task(
        resource,
        downloader,
        db,
        agent_id=agent.id,
        download_dir=download_dir,
    )


_DEFAULT_LLM_PICK_PROMPT = (
    "从以下候选中为同一集挑选最佳资源。优先级：metadata 字段最完整 > "
    "清晰度最高（2160p>1080p>720p）> 带字幕（subtitle_langs 非空）> "
    "发布时间最新。"
)


def _parse_llm_pick(text: str, candidate_count: int) -> tuple[int | None, str | None]:
    """Extract a 1-based candidate index + reason from an LLM text response.

    Tries JSON first (``{"pick": <n>, "reason": "..."}``), then falls back to
    a leading integer. Returns ``(None, reason)`` when no valid pick is found.
    """
    if not text:
        return None, None
    import json as _json
    import re

    m = re.search(r"\{[^{}]*\}", text)
    if m:
        try:
            obj = _json.loads(m.group(0))
            pick = obj.get("pick")
            reason = obj.get("reason")
            if isinstance(pick, int) and 1 <= pick <= candidate_count:
                return pick, (reason if isinstance(reason, str) else None)
        except Exception:
            pass

    m = re.match(r"\s*(?:pick[:\s]*)?(\d+)", text, re.IGNORECASE)
    if m:
        pick = int(m.group(1))
        if 1 <= pick <= candidate_count:
            return pick, text.strip() or None
    return None, text.strip() or None


async def _generate_llm_pick(
    agent: Agent,
    candidates: list[FileResource],
    key: tuple,
) -> tuple[str | None, str | None]:
    """Ask the LLM to pick the best candidate.

    Returns ``(picked_resource_id, reason)``. ``picked_resource_id`` is None
    when the LLM is disabled, unreachable, or didn't return a valid pick.
    Uses ``agent.llm_prompt`` when set, else the built-in default prompt.
    """
    if not agent.llm_enabled or not runtime_config.llm_api_key or not candidates:
        return None, None
    try:
        from app.services.feed_analyzer import call_llm

        instruction = (agent.llm_prompt or "").strip() or _DEFAULT_LLM_PICK_PROMPT
        lines = [instruction, ""]
        # Field glossary so custom prompts can rely on the extra work fields.
        lines.append(
            "候选字段说明：title 为资源原始标题；year/rating 来自关联作品"
            "（电影取 release_date 年份、剧集取首播年份；rating 满分 10 分），"
            "null 表示无关联作品或该字段无数据。"
        )
        lines.append("")
        for i, c in enumerate(candidates, 1):
            meta_fields = sum(
                1 for v in (
                    getattr(c, "subtitle_groups", None) or c.subtitle_group,
                    c.resolution, c.source, c.video_codec,
                    c.audio_codec, c.subtitle_type, c.container, c.file_size,
                ) if v not in (None, "", [])
            )
            has_sub = bool(getattr(c, "subtitle_langs", None)) or bool(c.subtitle_type)
            work = loaded_relation(c, "movie") or loaded_relation(c, "series")
            work_year, work_rating = None, None
            if work is not None:
                work_date = getattr(work, "release_date", None) or getattr(work, "start_date", None)
                work_year = work_date.year if work_date else None
                work_rating = getattr(work, "rating", None)
            lines.append(
                f"{i}. title={c.title_raw} year={work_year} rating={work_rating} "
                f"subtitle_groups={getattr(c, 'subtitle_groups', None) or c.subtitle_group} resolution={c.resolution} "
                f"source={c.source} video_codec={c.video_codec} audio_codec={c.audio_codec} "
                f"size={c.file_size} subtitle_langs={getattr(c, 'subtitle_langs', None)} "
                f"has_subtitle={has_sub} meta_completeness={meta_fields}/8 "
                f"published={c.published_at}"
            )
        lines.append("")
        lines.append('只返回 JSON：{"pick": <候选编号>, "reason": "<一句话理由>"}。')
        messages = [
            {"role": "system", "content": "You help choose the best media release from multiple candidates."},
            {"role": "user", "content": "\n".join(lines)},
        ]
        raw = await call_llm(messages)
        pick_idx, reason = _parse_llm_pick(raw or "", len(candidates))
        picked_id = candidates[pick_idx - 1].id if pick_idx else None
        return picked_id, reason
    except Exception as e:
        logger.debug("LLM pick failed: %s", e)
        return None, None


async def create_pending_decision(
    agent: Agent,
    key: tuple,
    candidates: list[FileResource],
    db: AsyncSession,
    *,
    reason_override: str | None = None,
    skip_llm: bool = False,
    coverage: tuple | None = None,
) -> PendingDecision:
    """Upsert a PendingDecision for multiple conflicting candidates.

    Same ``(agent, series_id | movie_id, season, episode)`` tuple must always
    map to a single row in ``status='pending'``. Repeated agent runs re-merge
    new candidate ids into the existing row instead of piling up duplicates
    (which used to cause the 76-rows-for-4-episodes explosion).

    ``key`` is ``(type, target_id, episode)`` for single-episode series
    conflicts — the decision's season component is derived from the work's
    own ``season_number`` (per-season works carry the season in their
    identity) — or the explicit 4-element ``(type, target_id, season,
    episode)`` shape used by batch-conflict decisions. ``reason_override``
    supplies a scope-aware message for batch conflicts.
    """
    if len(key) == 4:
        type_, target_id, season, episode = key
    else:
        type_, target_id, episode = key
        season = None
    series_id = target_id if type_ == "series" else None
    movie_id = target_id if type_ == "movie" else None

    title = ""
    if type_ == "series":
        s = await db.get(TVSeries, target_id) if target_id else None
        title = (s.title_cn or s.title_en or "") if s else ""
        if season is None and s is not None:
            # Per-season works: the decision's season component is the work's
            # own season_number (the season lives in the work identity, not
            # in the resource parse).
            season = s.season_number
    else:
        m = await db.get(Movie, target_id) if target_id else None
        title = (m.title_cn or m.title_en or "") if m else ""

    if reason_override is not None:
        reason = reason_override.format(title=title) if "{" in reason_override else reason_override
    elif type_ == "series" and episode is not None and season is not None:
        reason = f"多个资源匹配 {title} 第{season}季第{episode:02d}集"
    elif type_ == "series" and episode is not None:
        reason = f"多个资源匹配 {title} 第{episode:02d}集"
    elif type_ == "series":
        reason = f"多个资源匹配 {title}"
    else:
        reason = f"多个资源匹配电影 {title}"

    from app.services.decision_store import choice_identity, persist_choice

    candidate_ids = list(dict.fromkeys(c.id for c in candidates))
    if len(candidate_ids) < 2:
        raise ValueError("A pending choice requires at least two distinct candidates")
    decision_key, scope = choice_identity(type_, target_id, season, episode, coverage)
    existing = await db.scalar(select(PendingDecision).where(
        PendingDecision.agent_id == agent.id, PendingDecision.status == "pending",
        PendingDecision.decision_key == decision_key,
    ))
    proposed_ids = list(dict.fromkeys([*((existing.candidates or []) if existing else []), *candidate_ids]))
    if skip_llm:
        picked_id, reason_txt = None, None
    elif existing and set(existing.candidates or []) == set(proposed_ids) and existing.llm_picked_resource_id:
        picked_id, reason_txt = existing.llm_picked_resource_id, existing.llm_suggestion
    else:
        proposed = list((await db.scalars(select(FileResource).where(FileResource.id.in_(proposed_ids)).options(
            selectinload(FileResource.series), selectinload(FileResource.movie),
        ))).all())
        picked_id, reason_txt = await _suggest_pick(agent, proposed, key)
    from app.services.task_queue import require_execution_ownership

    await require_execution_ownership()
    return await persist_choice(
        db, agent_id=agent.id, decision_key=decision_key, decision_scope=scope,
        candidate_ids=candidate_ids, proposed_ids=proposed_ids,
        picked_id=picked_id, suggestion=reason_txt,
        fields=dict(series_id=series_id, movie_id=movie_id, season=season, episode=episode, reason=reason),
    )


def score_and_pick(
    candidates: list[FileResource],
    work: Any,
    agent: Agent,
) -> FileResource:
    """Heuristic ranking: resolution > file_size > published_at, with a
    subtitle-language bonus as the final tie-break (zh-CN > zh-TW > other)
    so otherwise-identical variants resolve towards 简体 when the preference
    rules and the LLM could not discriminate."""
    lang_bonus_map = {"zh-TW": 1, "zh-CN": 2}

    def lang_bonus(r: FileResource) -> int:
        langs = r.subtitle_langs or []
        return max(
            (lang_bonus_map[lang] for lang in langs if lang in lang_bonus_map),
            default=0,
        )

    def score(r: FileResource) -> tuple:
        return (
            _resolution_score(r.resolution),
            r.file_size or 0,
            r.published_at or datetime.min.replace(tzinfo=UTC),
            lang_bonus(r),
        )
    return max(candidates, key=score)


def pick_by_preferences(
    candidates: list[FileResource],
    preferences: list[dict] | None,
) -> tuple[list[FileResource], dict | None]:
    """Narrow ``candidates`` to the best tier under ordered preference rules.

    Lexicographic ("ordered should") semantics: the first rule splits the pool
    into match / no-match and the matching tier wins; later rules break
    remaining ties within the winning tier. Rules that match everything or
    nothing in the current tier cannot discriminate and are skipped.

    Preferences only ever REORDER — they never filter candidates out of the
    conflict set: with no preferences, a single candidate, or an all-way tie
    the original list is returned unchanged.

    Returns ``(tier, deciding_rule)`` — the rule that last narrowed the pool
    (None when no rule discriminated). A malformed rule is skipped rather
    than breaking dispatch.
    """
    best = list(candidates)
    deciding: dict | None = None
    if not preferences or len(best) <= 1:
        return best, None
    for pref in preferences:
        if not isinstance(pref, dict):
            continue
        try:
            winners = [c for c in best if evaluate_field_condition(pref, c)]
        except Exception:  # noqa: BLE001 — a bad rule must never break dispatch
            logger.debug("pick preference rule skipped: %s", pref)
            continue
        if 0 < len(winners) < len(best):
            best = winners
            deciding = pref
            if len(best) == 1:
                break
    return best, deciding


def _describe_preference(pref: dict) -> str:
    field = pref.get("field", "?")
    op = pref.get("operator", "?")
    if op in ("is_empty", "is_not_empty"):
        return f"{field} {op}"
    return f"{field} {op} {pref.get('value')}"


async def _suggest_pick(
    agent: Agent,
    candidates: list[FileResource],
    key: tuple,
) -> tuple[str | None, str | None]:
    """Suggestion for ask-mode decisions: deterministic preference rules
    first (the reason is labeled as rule-sourced, not LLM), the LLM breaks
    any remaining tie on the narrowed tier."""
    tier, deciding = pick_by_preferences(candidates, agent.pick_preferences)
    if len(tier) == 1 and len(candidates) > 1 and deciding is not None:
        return tier[0].id, f"命中优选偏好规则（确定性选择）：{_describe_preference(deciding)}"
    return await _generate_llm_pick(agent, tier, key)


async def _persist_suggestions(
    agent_id: str,
    suggestions: list[dict],
    db: AsyncSession,
) -> None:
    """Replace the persisted suggestion snapshot for an agent."""
    await db.execute(delete(AgentSuggestion).where(AgentSuggestion.agent_id == agent_id))
    for group in suggestions:
        sample_title = (group.get("sample_title") or "").strip()
        resources = group.get("resources") or []
        if not sample_title or not resources:
            continue
        db.add(
            AgentSuggestion(
                agent_id=agent_id,
                sample_title=sample_title,
                resources=list(resources),
                status="active",
            )
        )


# ── Batch (合集) content-coverage dedup ─────────────────────────────────────
# Batch resources carry no per-episode identity, so the (series, season,
# episode) dedup key doesn't apply. Instead they dedup/conflict by *content
# coverage*: two batches are duplicates only when they cover exactly the same
# content. Same-coverage versions (different encodes / subtitle groups) go
# through the same conflict resolution as single episodes (ask →
# PendingDecision / auto → LLM pick → heuristic scorer); different coverage
# (S1 pack vs S2 pack, S1-S2 vs S1-S3) never conflicts.

# PendingDecision.episode marker for batch-conflict decisions. Distinguishes
# them from episode-less single-episode decisions, which would otherwise
# share the (series, season, NULL) idempotency key and merge. The decisions
# UI renders only reason + candidates, so the sentinel is never displayed.
_BATCH_EPISODE_SENTINEL = -1



def _batch_coverage_key(resource: FileResource) -> tuple | None:
    from app.services.resource_coverage import batch_coverage

    coverage = batch_coverage(resource)
    if coverage is None:
        return None
    kind = "movie" if resource.movie_id else resource.batch_scope
    return kind, coverage


async def _find_existing_episode_task(
    agent: Agent,
    resource: FileResource,
    db: AsyncSession,
) -> DownloadTask | None:
    """Existing active/completed task of this agent occupying the same
    episode slot.

    Slot identity is ``(series, episode)``: per-season works encode the
    season in the work identity, so no season component is compared (the old
    season-compatible matching was retired with the per-season model).
    """
    stmt = (
        select(DownloadTask)
        .join(FileResource, DownloadTask.file_resource_id == FileResource.id)
        .where(
            DownloadTask.agent_id == agent.id,
            _task_occupies_download_slot(),
            FileResource.series_id == resource.series_id,
            FileResource.episode == resource.episode,
        )
    )
    return (await db.execute(stmt)).scalars().first()


async def _find_active_batch_duplicate(
    agent: Agent,
    resource: FileResource,
    coverage: tuple,
    db: AsyncSession,
) -> DownloadTask | None:
    """Active/completed task of this agent whose batch resource covers exactly
    the same content as ``resource``. Compared in Python because the coverage
    of multi-season packs lives in the link table / a JSON list (small N per
    agent+work). Links-carried packs (no flat FK) match against the agent's
    other FK-less batch resources."""
    if resource.movie_id:
        work_filter = FileResource.movie_id == resource.movie_id
    elif resource.series_id:
        work_filter = FileResource.series_id == resource.series_id
    else:
        work_filter = and_(
            FileResource.series_id.is_(None),
            FileResource.movie_id.is_(None),
        )
    stmt = (
        select(DownloadTask)
        .join(FileResource, DownloadTask.file_resource_id == FileResource.id)
        .where(
            DownloadTask.agent_id == agent.id,
            _task_occupies_download_slot(),
            FileResource.is_batch.is_(True),
            work_filter,
        )
        .options(
            selectinload(DownloadTask.file_resource).selectinload(FileResource.work_links).selectinload(ResourceWorkLink.series),
            selectinload(DownloadTask.file_resource).selectinload(FileResource.file_assignments),
            selectinload(DownloadTask.file_resource).selectinload(FileResource.series),
        )
    )
    for task in (await db.execute(stmt)).scalars():
        if _batch_coverage_key(task.file_resource) == coverage:
            return task
    return None


def _batch_decision_key(key: tuple) -> tuple[tuple, str]:
    """Translate an internal batch candidate key ``("batch", target_id, cov)``
    into a ``create_pending_decision`` key + reason template.

    The season component of a season-pack decision is filled in by
    ``create_pending_decision`` from the work's own ``season_number``.

    Known limitation: links-carried multi-season packs have no flat work FK,
    so their decisions share one ``(series=NULL, season=NULL, episode=-1)``
    idempotency slot per agent even when their linked work sets differ — the
    (series, season, episode) idempotency columns can't encode a work-id set.
    """
    _, target_id, cov = key
    if cov[0] == "movie":
        return ("movie", target_id, None, _BATCH_EPISODE_SENTINEL), (
            "多个合集资源匹配电影 {title}，内容相同，请选择一个版本"
        )
    if cov[0] == "season":
        return ("series", target_id, None, _BATCH_EPISODE_SENTINEL), (
            "多个合集资源匹配 {title}（同季包），内容相同，请选择一个版本"
        )
    return ("series", target_id, None, _BATCH_EPISODE_SENTINEL), (
        "多个合集资源匹配 {title}（跨季包），内容相同，请选择一个版本"
    )


async def _process_candidate_group(agent, key, cands, db, *, consumption_snapshot=None) -> bool:
    """Dispatch one coverage group; return whether it created a decision."""
    dispatch_options = {}
    if consumption_snapshot is not None:
        from app.services.agent_publication_progress import require_current_scope

        await require_current_scope(db, consumption_snapshot)
        dispatch_options["consumption_snapshot"] = consumption_snapshot
    if len(cands) == 1:
        await dispatch_download(agent, cands[0], db, **dispatch_options)
        return False
    else:
        if agent.conflict_resolution == "ask":
            if key[0] == "batch":
                pd_key, reason = _batch_decision_key(key)
                await create_pending_decision(
                    agent, pd_key, cands, db, reason_override=reason, coverage=key[2]
                )
            else:
                await create_pending_decision(agent, key, cands, db)
            return True
        else:
            # "auto": deterministic preference rules first — they only
            # rank, never filter. A unique winner dispatches without
            # any LLM call; a tied shortlist goes to the LLM pick
            # (self-gated on llm_enabled + API key); the heuristic
            # scorer stays the final fallback.
            tier, _deciding = pick_by_preferences(cands, agent.pick_preferences)
            if len(tier) == 1:
                chosen = tier[0]
            else:
                picked_id, _pick_reason = await _generate_llm_pick(agent, tier, key)
                chosen = next((c for c in tier if c.id == picked_id), None)
                if chosen is None:
                    chosen = score_and_pick(tier, None, agent)
            await dispatch_download(agent, chosen, db, **dispatch_options)
            return False


async def process_resources(
    agent: Agent,
    resources: list[FileResource],
    db: AsyncSession,
    *,
    autocommit: bool = False,
    required_metadata_fields: list[str] | None = None,
    consumption_snapshot=None,
) -> RunResult:
    """Process a list of resources through filtering, dedup, and dispatch.

    ``autocommit`` is used by the background run-agent handler: commit after
    each dispatch / decision so the SQLite write lock is released between
    units of work instead of being held for the entire run (which contains
    slow LLM calls and Transmission RPCs). Request-scoped callers keep the
    default (single commit at request end). Operations are idempotent
    (task-dedup / decision upsert), so a mid-run crash simply leaves the
    already-committed units in place.
    """
    result = RunResult()
    from app.services.resource_coverage import load_batch_coverage
    from app.services.task_queue import ExecutionOwnershipLostError, require_execution_ownership

    await require_execution_ownership()
    await load_batch_coverage(db, resources)

    state = inspect(agent, raiseerr=False)
    if state is not None and "works" in state.unloaded:
        # Rules are required here, unlike task/history-only Agent reads. Keep
        # already-loaded in-transaction edits intact rather than refreshing them.
        await db.refresh(agent, ["works"])
    rule_set = _build_rule_set(agent)
    candidates_by_key: dict[tuple, list[FileResource]] = {}
    suggestions: dict[str, dict] = {}

    for resource in resources:
        result.total_resources += 1

        # Metadata pre-check. Metadata completeness is owned by the resource's
        # Channel, not by an Agent decision. Unlinked resources therefore do
        # not create AgentSuggestion/PendingDecision rows. Links-carried
        # multi-season packs (per-season works: flat FK cleared, works on
        # resource_work_links) are recognized through their link table.
        if not resource.series_id and not resource.movie_id:
            if not (
                getattr(resource, "is_batch", False)
                and getattr(resource, "batch_scope", None) == "multi_season"
                and _linked_series_ids(resource)
            ):
                result.unrecognized += 1
                continue

        confirmation = inspect_resource_confirmation(
            resource, required_metadata_fields
        )
        if confirmation.required:
            result.unrecognized += 1
            continue

        # Work scope + filter (filter-level match).
        matched, work = _resource_matches_rules(resource, rule_set)
        if not matched:
            # Distinguish "in scope but filter failed" from "out of scope" for
            # the filter_failed counter; out-of-scope is silently skipped.
            if (
                rule_set.scope_channel_wide
                or (resource.series_id and resource.series_id in rule_set.work_by_series_id)
                or (resource.movie_id and resource.movie_id in rule_set.work_by_movie_id)
                or any(
                    sid in rule_set.work_by_series_id
                    for sid in _linked_series_ids(resource)
                )
            ):
                result.filter_failed += 1
            continue

        # Batch (合集) resources dedup/conflict by *content coverage* (see
        # _batch_coverage_key): strictly identical coverage (same season work /
        # same linked season-work set) goes through the normal conflict
        # resolution; different coverage never conflicts. Coverage is a
        # **mandatory** field for downstream organize planning (覆盖度校验),
        # so unknown coverage is stopped by the Channel confirmation gate.
        # Franchise packs never reach here (work FKs are cleared →
        # unrecognized bucket).
        if getattr(resource, "is_batch", False):
            # Same-FileResource guard (crash recovery / re-run).
            existing_stmt = select(DownloadTask).where(
                and_(
                    DownloadTask.agent_id == agent.id,
                    DownloadTask.file_resource_id == resource.id,
                    _task_occupies_download_slot(),
                )
            )
            if (await db.execute(existing_stmt)).scalars().first():
                result.duplicates_skipped += 1
                continue
            coverage = _batch_coverage_key(resource)
            # Unknown coverage is caught by the Channel confirmation gate
            # above. Keep this defensive guard for callers that supplied a
            # non-ORM resource shape without the expected batch fields.
            if coverage is None:
                result.unrecognized += 1
                continue
            # Cross-run dedup against active/completed tasks with the
            # exact same coverage. Series packs honor the per-work
            # enable_episode_dedup toggle (same as single episodes);
            # movie packs dedup unconditionally (same as movie singles).
            dedup_enabled = (
                True
                if resource.movie_id
                else (work.enable_episode_dedup if work else True)
            )
            if dedup_enabled and await _find_active_batch_duplicate(
                agent, resource, coverage, db
            ):
                result.duplicates_skipped += 1
                continue
            # Aggregate same-coverage versions for conflict resolution
            # (ask → PendingDecision / auto → LLM pick → heuristic).
            key = ("batch", resource.series_id or resource.movie_id, coverage)
            candidates_by_key.setdefault(key, []).append(resource)
            result.matched += 1
            result.matched_resource_ids.append(resource.id)
            continue

        # Dedup check
        if resource.movie_id:
            stmt = select(DownloadTask).where(
                and_(
                    DownloadTask.agent_id == agent.id,
                    _task_occupies_download_slot(),
                    DownloadTask.file_resource.has(movie_id=resource.movie_id),
                )
            )
            existing = (await db.execute(stmt)).scalars().first()
            if existing:
                result.duplicates_skipped += 1
                continue
            key = ("movie", resource.movie_id, None, None)
        else:
            dedup_enabled = work.enable_episode_dedup if work else True
            if dedup_enabled and resource.episode is not None:
                existing = await _find_existing_episode_task(agent, resource, db)
                if existing:
                    result.duplicates_skipped += 1
                    continue
            # Per-season works: the season lives in the work identity, so the
            # conflict slot is (series, episode); create_pending_decision
            # fills the decision's season from the work's season_number.
            key = ("series", resource.series_id, resource.episode)

        candidates_by_key.setdefault(key, []).append(resource)
        result.matched += 1
        result.matched_resource_ids.append(resource.id)

    if autocommit:
        # Background callers own this transaction. Finish selection before
        # independent candidate writers; preserve loaded objects on commit.
        await db.commit()
    guard_options = {"consumption_snapshot": consumption_snapshot} if consumption_snapshot is not None else {}
    for key, cands in candidates_by_key.items():
        await require_execution_ownership()
        try:
            if autocommit:
                from app.database import retry_on_lock

                async def write_candidate():
                    async with AsyncSession(bind=db.bind, expire_on_commit=False) as unit_db:
                        async with unit_db.begin():
                            if unit_db.get_bind().dialect.name == "sqlite":
                                # A logical Session transaction alone does not
                                # make Turso start BEGIN before a SAVEPOINT.
                                # Releasing that first savepoint must not commit
                                # the choice before our outer ownership check.
                                await unit_db.execute(text("BEGIN"))
                            await require_execution_ownership()
                            pending = await _process_candidate_group(agent, key, cands, unit_db, **guard_options)
                            await require_execution_ownership()
                            return pending

                if agent.conflict_resolution == "ask" and len(cands) >= 2:
                    # This branch only persists a choice; it cannot send a
                    # download RPC. Retry the complete fresh transaction.
                    pending = await retry_on_lock(write_candidate)
                else:
                    pending = await write_candidate()
            else:
                # A newly saved Agent may still be uncommitted in this request.
                # Keep that state visible and isolate only the candidate writes.
                async with db.begin_nested():
                    pending = await _process_candidate_group(agent, key, cands, db, **guard_options)
                    await require_execution_ownership()
            if pending:
                result.pending_decisions += 1
            else:
                result.dispatched += 1
        except ExecutionOwnershipLostError:
            raise
        except Exception as e:
            from app.database import _is_retryable_lock_error

            if not autocommit and (
                _is_retryable_lock_error(e)
                or not db.is_active or getattr(e, "connection_invalidated", False)
            ):
                # A lost outer transaction cannot safely continue a backfill.
                raise
            logger.exception("Failed to process candidates for %s: %s", key, e)
            result.errors.append(str(e))

    await require_execution_ownership()
    await _retire_legacy_resource_confirmation_decisions(agent, db)

    result.suggestions = list(suggestions.values())
    await _persist_suggestions(agent.id, result.suggestions, db)
    return result


async def _retire_legacy_resource_confirmation_decisions(
    agent: Agent, db: AsyncSession
) -> None:
    """Remove legacy resource-metadata issues from the Agent decision queue."""
    pd_rows = (await db.execute(
        select(PendingDecision).where(
            PendingDecision.agent_id == agent.id,
            PendingDecision.status == "pending",
        )
    )).scalars().all()
    for pd in pd_rows:
        reason = pd.reason or ""
        if not reason.startswith(LEGACY_CONFIRMATION_REASON_PREFIXES):
            continue
        pd.status = "skipped"
        pd.decided_at = utcnow()
    await db.flush()
