"""Unit tests for source isolation in UnifiedMetadataAgent."""

from app.services import metadata_audio_resolver as mar
from app.services import metadata_wikipedia_client as wc
from app.services.metadata_agent import (
    ResourceMetadata,
    UnifiedMetadataAgent,
    _seasons_map_from,
    normalize_metadata_source_type,
    reconcile_episode,
)


def _tool_names(agent: UnifiedMetadataAgent, source: str) -> set[str]:
    return {tool.name for tool in agent._tools_for_source(source)}


def test_metadata_source_normalization_defaults_to_wikipedia():
    # Legacy values (combined/unknown/None) map to the two-source default.
    assert normalize_metadata_source_type(None) == "wikipedia"
    assert normalize_metadata_source_type("combined") == "wikipedia"
    assert normalize_metadata_source_type("TMDB") == "tmdb"
    assert normalize_metadata_source_type("wikipedia") == "wikipedia"
    assert normalize_metadata_source_type("unknown") == "wikipedia"
    # Local-library lookup is a search mode, not a metadata source.
    assert normalize_metadata_source_type("local") == "wikipedia"
    # Removed sources (exa) map to the default.
    assert normalize_metadata_source_type("exa") == "wikipedia"


def test_channel_metadata_source_resolution_is_two_source():
    from app.services.metadata_sources import (
        normalize_channel_metadata_source,
        resolve_metadata_source,
    )
    assert resolve_metadata_source(None) == "wikipedia"
    assert resolve_metadata_source("tmdb") == "tmdb"
    assert resolve_metadata_source("Wikipedia") == "wikipedia"
    # Deprecated channel sources converge on wikipedia.
    for legacy in ("exa", "jina", "local", "combined", "unknown"):
        assert normalize_channel_metadata_source(legacy) == "wikipedia"


def test_tools_are_restricted_to_selected_source():
    agent = UnifiedMetadataAgent()

    assert _tool_names(agent, "tmdb") == {
        "search_tmdb",
        "get_tmdb_details",
        "finalize",
    }
    assert _tool_names(agent, "wikipedia") == {
        "search_wikipedia",
        "get_wikipedia_page",
        "finalize",
    }


def test_judge_model_sends_both_thinking_spellings(monkeypatch):
    """F6: the judge/ReAct ChatOpenAI model carries enable_thinking both
    top-level and under chat_template_kwargs (sglang only honors the latter)."""
    from app.services import runtime_config as rc

    monkeypatch.setitem(rc._overrides, "llm_enable_thinking", "false")
    agent = UnifiedMetadataAgent()
    extra_body = agent._model.extra_body
    assert extra_body["enable_thinking"] is False
    assert extra_body["chat_template_kwargs"] == {"enable_thinking": False}
    monkeypatch.setitem(rc._overrides, "llm_enable_thinking", "true")
    agent = UnifiedMetadataAgent()
    extra_body = agent._model.extra_body
    assert extra_body["enable_thinking"] is True
    assert extra_body["chat_template_kwargs"] == {"enable_thinking": True}


def test_resource_metadata_parses_batch_fields():
    meta = ResourceMetadata.from_dict({
        "clean_title": "Witch Hat Atelier",
        "content_type": "tv",
        "found": True,
        "inferred_season": 1,
        "is_batch": True,
        "inferred_episode_start": 1,
        "inferred_episode_end": 13,
    })
    assert meta.is_batch is True
    assert meta.episode_start == 1
    assert meta.episode_end == 13


def test_resource_metadata_parses_batch_scope():
    meta = ResourceMetadata.from_dict({
        "clean_title": "Show",
        "content_type": "tv",
        "found": True,
        "is_batch": True,
        "batch_scope": "multi_season",
    })
    assert meta.is_batch is True
    assert meta.batch_scope == "multi_season"


def test_resource_metadata_batch_scope_absent_is_none():
    meta = ResourceMetadata.from_dict({
        "clean_title": "Show",
        "content_type": "tv",
        "found": True,
        "is_batch": True,
    })
    assert meta.batch_scope is None


def test_resource_metadata_batch_scope_off_whitelist_is_none():
    """Free-form LLM output must not poison the writeback — anything outside
    season|multi_season|franchise is dropped."""
    for bad in ("whole_series", "MULTI_SEASON", "", 3, True):
        meta = ResourceMetadata.from_dict({
            "clean_title": "Show",
            "content_type": "tv",
            "found": True,
            "is_batch": True,
            "batch_scope": bad,
        })
        assert meta.batch_scope is None


def test_resource_metadata_defaults_are_non_batch():
    meta = ResourceMetadata.from_dict({
        "clean_title": "Show",
        "content_type": "tv",
        "found": True,
        "inferred_episode": 5,
    })
    assert meta.is_batch is False
    assert meta.episode_start is None
    assert meta.episode_end is None


def test_resource_metadata_parses_subtitle_langs():
    meta = ResourceMetadata.from_dict({
        "clean_title": "Show",
        "content_type": "tv",
        "found": True,
        "subtitle_langs": ["zh-CN", "zh-TW"],
    })
    assert meta.subtitle_langs == ["zh-CN", "zh-TW"]


def test_resource_metadata_subtitle_langs_absent_is_none():
    """None means 'LLM had nothing to say' — pre-parser output should stand."""
    meta = ResourceMetadata.from_dict({
        "clean_title": "Show",
        "content_type": "tv",
        "found": True,
    })
    assert meta.subtitle_langs is None


# ---------------------------------------------------------------------------
# Episode reconciliation (P2)
# ---------------------------------------------------------------------------


def test_seasons_map_extracts_valid_entries_only():
    entity = {
        "seasons": [
            {"season_number": 1, "episode_count": 24},
            {"season_number": 2, "episode_count": 24},
            {"season_number": 0, "episode_count": 3},   # specials → skip
            {"season_number": 3},                          # no count → skip
            {"episode_count": 12},                          # no season → skip
            "not a dict",
        ],
    }
    assert _seasons_map_from(entity) == {1: 24, 2: 24}


def test_seasons_map_from_none_returns_empty():
    assert _seasons_map_from(None) == {}
    assert _seasons_map_from({}) == {}
    assert _seasons_map_from({"seasons": None}) == {}


class TestReconcileEpisode:
    def test_raw_within_bounds_stays_raw(self):
        # S1E5 with a 12-episode season — keep the raw number.
        r = reconcile_episode(raw_episode=5, raw_season=1, seasons_map={1: 12})
        assert r == (5, None, "raw")

    def test_raw_within_tolerance_stays_raw(self):
        # TMDB reports 12 episodes but show already aired 13; +2 tolerance
        # keeps it a "raw" call rather than triggering absolute conversion.
        r = reconcile_episode(raw_episode=13, raw_season=1, seasons_map={1: 12})
        assert r == (13, None, "raw")

    def test_absolute_converts_to_per_season(self):
        # Slime S4: absolute 84 → per-season 13 given prev seasons total 71.
        # seasons_map for S1..S4 with cumulative-71 before S4.
        seasons = {1: 24, 2: 24, 3: 23, 4: 13}
        r = reconcile_episode(raw_episode=84, raw_season=4, seasons_map=seasons)
        assert r == (13, 84, "reconciled")

    def test_absolute_last_episode(self):
        # Slime S4 finale — absolute 85, per-season 12 (if season size = 13,
        # 85-71 = 14 which is 1 over and remains E14 inside the tolerance envelope.
        # We accept anything in [1, season_count + tolerance].
        seasons = {1: 24, 2: 24, 3: 23, 4: 13}
        result = reconcile_episode(raw_episode=85, raw_season=4, seasons_map=seasons)
        assert result is not None
        ep, abs_ep, conf = result
        assert conf == "reconciled"
        assert abs_ep == 85
        assert ep == 14

    def test_no_seasons_map_returns_none(self):
        assert reconcile_episode(raw_episode=84, raw_season=4, seasons_map={}) is None

    def test_unknown_season_returns_none(self):
        # We don't have data for season 5; can't reason about it.
        assert reconcile_episode(
            raw_episode=99, raw_season=5, seasons_map={1: 24, 2: 24}
        ) is None

    def test_conversion_out_of_range_is_ambiguous(self):
        # raw 200 with seasons_map summing to ~85 → converted candidate
        # 200-71=129 which is way outside season 4's 13 episodes. Flag.
        seasons = {1: 24, 2: 24, 3: 23, 4: 13}
        r = reconcile_episode(raw_episode=200, raw_season=4, seasons_map=seasons)
        assert r == (200, None, "ambiguous")

    def test_season_1_no_prev_total_but_raw_too_big(self):
        # If raw > season_count and it's season 1, nothing to subtract →
        # ambiguous rather than a wild conversion.
        r = reconcile_episode(raw_episode=99, raw_season=1, seasons_map={1: 12})
        assert r == (99, None, "ambiguous")


# ---------------------------------------------------------------------------
# Jina source — _extract_search_info wiring
# ---------------------------------------------------------------------------


def _ai_message(tool_name: str, args: dict):
    from langchain_core.messages import AIMessage

    return AIMessage(
        content="",
        tool_calls=[{"name": tool_name, "args": args, "id": tool_name}],
    )


def _tool_message(name: str, content: dict, call_id: str):
    import json as _json

    from langchain_core.messages import ToolMessage

    return ToolMessage(content=_json.dumps(content), name=name, tool_call_id=call_id)


# ---------------------------------------------------------------------------
# Failure classification + retry-state recording + cache/force_refresh behavior
# ---------------------------------------------------------------------------

from types import SimpleNamespace  # noqa: E402
from unittest.mock import AsyncMock, MagicMock  # noqa: E402

from app.services.metadata_agent import (  # noqa: E402
    _classify_failure,
    _record_metadata_attempt,
)


def _meta(found=True, reason=None, search_error=None, matched_entity=None):
    return ResourceMetadata(
        clean_title="X", content_type="tv", found=found,
        reason=reason, search_error=search_error, matched_entity=matched_entity,
    )


def test_classify_failure_success_returns_none():
    # A real success has a matched_entity to link.
    assert _classify_failure(_meta(found=True, matched_entity={"external_id": "x"})) is None


def test_classify_failure_found_true_no_entity_is_transient():
    """found=True with no matched_entity is an LLM finalization gap, not a
    success - it must retry (transient) instead of being cached as a fake
    'match' that leaves the resource permanently unparsed."""
    assert _classify_failure(_meta(found=True)) == "transient"
    assert _classify_failure(_meta(found=True, matched_entity={})) == "transient"


def test_classify_failure_agent_error_recursion_is_transient():
    """Agent-level exceptions wrapped by _run_react as 'Agent error: ...'
    (recursion limit, LLM 4xx/5xx) are infra failures, not a definitive
    no-match - they must retry, never be cached as permanent not_found."""
    for reason in (
        "Agent error: Recursion limit of 25 reached without hitting a stop condition.",
        "Agent error: Error code: 400 - {'error': {'message': 'Error from provider'}}",
        "Agent error: https://en.wikipedia.org/w/api.php",
        "Agent error: Error code: 500 - Internal Server Error",
    ):
        assert _classify_failure(_meta(found=False, reason=reason)) == "transient", reason


def test_classify_failure_transient_markers():
    for reason in (
        "Agent error: Request timed out.",
        "Agent error: Connection error.",
        "Agent did not call finalize",
        "Agent error: Error code: 403 - AccountOverdueError",
    ):
        assert _classify_failure(_meta(found=False, reason=reason)) == "transient", reason
    # search_error is also consulted
    assert _classify_failure(_meta(found=False, search_error="Request timed out.")) == "transient"


def test_classify_failure_web_fallback_errors_are_transient():
    """wigolo fallback failures (and legacy exa markers from cached reasons)
    are infra failures, never a definitive not_found."""
    for reason in (
        "web search failed: WigoloSearchError: wigolo HTTP 502",
        "web search failed: ConnectError: All connection attempts failed",
        "web fallback judge returned unparseable JSON",
        # legacy markers still match (rows cached before the engine swap)
        "exa search failed: ExaMcpError: MCP HTTP 429",
        "exa judge returned unparseable JSON",
    ):
        assert _classify_failure(_meta(found=False, reason=reason)) == "transient", reason


def test_classify_failure_http_source_errors_are_transient():
    """Billing/rate/auth/server errors from the external source are infra
    failures, not a definitive 'no match' - they must retry and must not be
    cached as permanent not_found."""
    for err in (
        "Jina: 402 Payment Required",
        "Client error '402 Payment Required' for url 'https://s.jina.ai/'",
        "Exa: 429 Too Many Requests",
        "Jina: 401 Unauthorized",
        "Exa: 502 Bad Gateway",
        "Jina: 503 Service Unavailable",
    ):
        assert _classify_failure(_meta(found=False, search_error=err)) == "transient", err
    # A real "no match" reason (no HTTP error in reason/search_error) stays not_found
    assert _classify_failure(
        _meta(found=False, reason="No matching work found in Jina search results")
    ) == "not_found"


def test_classify_failure_non_work_markers():
    for reason in (
        "The RSS entry is a music album release",
        "The RSS entry is an ASMR audio recording",
        "The provided RSS entry is for an opening theme song",
    ):
        assert _classify_failure(_meta(found=False, reason=reason)) == "non_work", reason


def test_classify_failure_not_found_default():
    assert _classify_failure(_meta(found=False, reason="No matching work found in Jina")) == "not_found"
    assert _classify_failure(_meta(found=False)) == "not_found"


def test_record_metadata_attempt_increments_and_stamps():
    res = SimpleNamespace(metadata_attempts=0, last_metadata_attempt_at=None, metadata_failure_type=None)
    _record_metadata_attempt(res, _meta(found=False, reason="Request timed out."))
    assert res.metadata_attempts == 1
    assert res.last_metadata_attempt_at is not None
    assert res.metadata_failure_type == "transient"
    # success clears the failure marker
    _record_metadata_attempt(res, _meta(found=True, matched_entity={"external_id": "x"}))
    assert res.metadata_attempts == 2
    assert res.metadata_failure_type is None


def _patched_agent():
    """A UnifiedMetadataAgent with all I/O methods stubbed, so process() can
    be exercised in isolation against the cache/force_refresh logic."""
    agent = UnifiedMetadataAgent()
    agent._apply_manual_mapping = AsyncMock(return_value=False)
    agent._resource_scope_is_current = AsyncMock(return_value=True)
    agent._manual_mapping_scope = AsyncMock(return_value=None)
    agent._get_cache = AsyncMock()
    agent._set_cache = AsyncMock()
    agent._apply_to_resource = AsyncMock()
    agent._run_react = AsyncMock()
    agent._find_known_work = AsyncMock(return_value=None)  # S1 short-circuit off in cache/agent tests
    agent._build_production_message = MagicMock(return_value="msg")
    return agent


def _ns_resource():
    return SimpleNamespace(
        title_raw="[G] Show - 01", series_id=None, movie_id=None,
        metadata_attempts=0, last_metadata_attempt_at=None, metadata_failure_type=None,
    )


def _react_return(found, reason=None):
    finalize = {"clean_title": "Show", "content_type": "tv", "found": found, "reason": reason}
    info = {"method": None, "data_sources_used": [], "source_errors": {}, "error": None}
    return finalize, info


async def test_process_uses_definitive_cache_without_refresh():
    agent = _patched_agent()
    resource = _ns_resource()
    cached = _meta(found=False, reason="No matching work found in Jina")
    agent._get_cache.return_value = cached
    res = await agent.process(resource, SimpleNamespace(id="ch", metadata_source=None), MagicMock())
    agent._run_react.assert_not_called()          # no live run
    agent._apply_to_resource.assert_called_once()  # cached applied
    assert res is cached
    assert resource.metadata_attempts == 1         # attempt recorded from cache
    assert resource.metadata_failure_type == "not_found"


async def test_process_force_refresh_bypasses_definitive_cache():
    agent = _patched_agent()
    agent._get_cache.return_value = _meta(found=False, reason="No matching work found")
    agent._run_react.return_value = _react_return(found=True)
    res = await agent.process(
        _ns_resource(), SimpleNamespace(id="ch", metadata_source=None), MagicMock(),
        force_refresh=True,
    )
    agent._get_cache.assert_not_called()  # cache read skipped
    agent._run_react.assert_called_once()  # ran live
    assert res.found is True


async def test_process_ignores_transient_cache_and_reruns():
    """A legacy cached transient failure must not short-circuit a live run."""
    agent = _patched_agent()
    agent._get_cache.return_value = _meta(found=False, reason="Agent error: Request timed out.")
    agent._run_react.return_value = _react_return(found=True)
    res = await agent.process(
        _ns_resource(), SimpleNamespace(id="ch", metadata_source=None), MagicMock(),
    )
    agent._run_react.assert_called_once()  # cache ignored → live run
    assert res.found is True


async def test_process_does_not_cache_transient_failure():
    agent = _patched_agent()
    agent._get_cache.return_value = None
    agent._run_react.return_value = _react_return(found=False, reason="Agent error: Request timed out.")
    resource = _ns_resource()
    await agent.process(resource, SimpleNamespace(id="ch", metadata_source=None), MagicMock())
    agent._set_cache.assert_not_called()  # transient never cached
    assert resource.metadata_failure_type == "transient"


async def test_process_caches_definitive_not_found():
    agent = _patched_agent()
    agent._get_cache.return_value = None
    agent._run_react.return_value = _react_return(found=False, reason="No matching work found in Jina")
    await agent.process(_ns_resource(), SimpleNamespace(id="ch", metadata_source=None), MagicMock())
    agent._set_cache.assert_called_once()  # definitive outcome cached


# ---------------------------------------------------------------------------
# S3: Wikipedia candidate queries (recall-oriented query generation)
# ---------------------------------------------------------------------------

from app.services.metadata_agent import (  # noqa: E402
    _candidate_queries,
    _classify_wikipedia_page,
    _clean_query,
    _detect_audio_work_type,
    _is_non_media,
    _work_name_prefix,
)


def test_clean_query_strips_season_episode_quality():
    assert _clean_query("无职转生 3期") == "无职转生"
    assert _clean_query("Mushoku Tensei S3 - 03") == "Mushoku Tensei"
    assert _clean_query("Show [01] [1080p HEVC]") == "Show"
    assert _clean_query("Movie 2024") == "Movie 2024"


def test_clean_query_strips_parens_colon_roman():
    # Parenthetical alt titles + colon description tail -> base work name.
    assert _clean_query("新世纪福音战士 (新世紀エヴァンゲリオン) (Neon Genesis Evangelion)：TV动画+剧场版") == "新世纪福音战士"
    # Colon arc/description tail.
    assert _clean_query("辉夜大小姐想让我告白：通往大人的阶梯") == "辉夜大小姐想让我告白"
    # Trailing roman-numeral season marker.
    assert _clean_query("无职转生Ⅲ") == "无职转生"


def test_is_non_media_detects_software():
    assert _is_non_media("BitComet Stable (build 2.21.6.23) 比特彗星全功能解锁豪华版") is True
    assert _is_non_media("[LoliHouse] 无职转生 3期 - 03 [1080p]") is False
    assert _is_non_media("") is False


def test_normalize_title_collapses_traditional_and_simplified():
    # S1 short-circuit must treat Traditional-cased library titles the same
    # as Simplified RSS titles (OpenCC t2s).
    from app.services.metadata_agent import _normalize_title
    assert _normalize_title("说出这边交给我") == _normalize_title("說出這邊交給我")
    assert _normalize_title("无职转生Ⅲ") == _normalize_title("無職轉生Ⅲ")
    # Punctuation dropped so "X！" and "X" collide.
    assert _normalize_title("猫眼三姐妹！") == _normalize_title("猫眼三姐妹")


def test_work_name_prefix_splits_at_first_season_marker():
    assert _work_name_prefix("无职转生 3期") == "无职转生"
    assert _work_name_prefix("Mushoku Tensei S3 - 03") == "Mushoku Tensei"
    assert _work_name_prefix("樱桃小丸子第二期 1538 详情") == "樱桃小丸子"
    # No marker -> no prefix variant.
    assert _work_name_prefix("黄泉使者") == ""


def test_work_name_prefix_splits_cjk_from_romaji():
    # Trailing romaji/English alt-title appended to a CJK work name is split
    # off so "二十世纪电气目录 Nijusseiki Denki Mokuroku" -> "二十世纪电气目录".
    assert _work_name_prefix("二十世纪电气目录 Nijusseiki Denki Mokuroku") == "二十世纪电气目录"
    # Latin-only titles are unaffected (no CJK before the Latin run).
    assert _work_name_prefix("Mushoku Tensei") == ""


def test_detect_audio_work_type():
    assert _detect_audio_work_type("【ASMR】愛上火車 少女們的祕事簿♪[WAV/MP3]") == "asmr"
    assert _detect_audio_work_type("[JMAX] ウマ娘 - トレセンラーメン列伝 [OST FLAC 96kHz/24bit]") == "music"
    assert _detect_audio_work_type("TVアニメ「X」OPテーマ「Y」／Aimer [FLAC]") == "music"
    assert _detect_audio_work_type("某ドラマCD 第1巻 [FLAC]") == "drama_cd"
    assert _detect_audio_work_type("[H-Enc] TV Show (BDRip 1080p HEVC FLAC)") is None
    # Normal anime episodes are NOT flagged.
    assert _detect_audio_work_type("[LoliHouse] 无职转生 3期 - 03 [WebRip 1080p HEVC AAC]") is None
    assert _detect_audio_work_type("") is None
    assert _detect_audio_work_type(None) is None


def test_candidate_queries_emits_season_stripped_variants():
    r = SimpleNamespace(title_cn=None, title_en=None, search_title=None)
    qs = _candidate_queries(
        "[LoliHouse] 无职转生 3期 / Mushoku Tensei S3 - 03 [WebRip 1080p]", r
    )
    assert ("无职转生", "zh") in qs
    assert ("Mushoku Tensei", "en") in qs


def test_candidate_queries_recovers_bracketed_work_name():
    # All-bracket title: dropping every bracket would leave nothing. The
    # work-name bracket content must be recovered as a query.
    r = SimpleNamespace(title_cn=None, title_en=None, search_title=None)
    qs = _candidate_queries(
        "[SweetSub][小書痴的下剋上 領主的養女][Honzuki no Gekokujou S04][13][WebRip][1080P]",
        r,
    )
    assert any("小書痴" in q for q, _ in qs)
    assert any("Honzuki no Gekokujou" in q for q, _ in qs)


def test_candidate_queries_splits_full_width_slash():
    r = SimpleNamespace(title_cn=None, title_en=None, search_title=None)
    qs = _candidate_queries("[整理搬运] 猫眼三姐妹／猫之眼：TV动画+剧场版", r)
    assert ("猫眼三姐妹", "zh") in qs


def test_candidate_queries_uses_search_title_hint():
    r = SimpleNamespace(title_cn=None, title_en=None, search_title="猫眼三姐妹")
    qs = _candidate_queries("[整理搬运] 猫眼三姐妹／猫之眼：TV动画+剧场版", r)
    assert ("猫眼三姐妹", "zh") in qs


def test_candidate_queries_adds_ja_for_kana_fragments():
    r = SimpleNamespace(title_cn=None, title_en=None, search_title=None)
    qs = _candidate_queries("魔法少女まどか☆マギカ / Madoka Magica - 01 [1080p]", r)
    # CJK+kana fragment should produce a ja query in addition to zh.
    langs = {lang for _, lang in qs}
    assert "ja" in langs


def test_clean_query_strips_orphan_brackets():
    # A field-mapping leak can leave an unbalanced bracket (only the closing
    # ']' was consumed upstream) - the orphan '[' must not reach the query.
    assert _clean_query("[ViuTV 幪面超人") == "ViuTV 幪面超人"
    assert _clean_query("幪面超人]") == "幪面超人"
    assert _clean_query("【幪面超人") == "幪面超人"


def test_candidate_queries_skips_station_token_leak():
    # Regression for the ViuTV leak: a multi-bracket fansub title whose second
    # bracket is the TV station "[ViuTV粵語]" must never query the ViuTV
    # television-station Wikipedia page as if it were the work. A1 skips a bare
    # station token; A4 drops a bracket whose content carries one.
    r = SimpleNamespace(title_cn=None, title_en=None, search_title=None)
    qs = _candidate_queries(
        "[jibaketa合成&音頻壓制][ViuTV粵語]幪面超人 - 42", r
    )
    lowered = [q.lower() for q, _ in qs]
    assert not any(q in ("viutv", "viutv粵語", "viutv粤语") for q in lowered)
    # The actual work name is still queried.
    assert any("幪面超人" in q for q, _ in qs)


def test_classify_wikipedia_page_work_vs_non_work():
    # The ViuTV television STATION page is non_work, not a series - this is the
    # page that was auto-linked as a bogus series on a title-similarity match.
    station = ["Television channels in Hong Kong", "Companies based in Hong Kong"]
    assert _classify_wikipedia_page(station, "ViuTV is a television channel") == "non_work"
    # A genuine anime series is a work.
    anime = [
        "2024 anime television series debuts",
        "Anime and live-action television series based on manga",
    ]
    assert _classify_wikipedia_page(anime, "is a Japanese television series") == "work"
    # A film is a work.
    assert _classify_wikipedia_page(["2023 films", "Japanese films"], "is a 2023 film") == "work"
    # A Chinese web-novel page is a work (the source material for donghua
    # adaptations that previously fell through to the judge and got rejected).
    cn_novel = ["2008年中国小说", "中华人民共和国网络小说"]
    assert _classify_wikipedia_page(cn_novel, "《凡人修仙传》是忘语创作的网络小说") == "work"
    # Mixed categories that include the novel markers + a platform/company marker
    # stay ambiguous so the judge can decide.
    mixed_novel = ["中华人民共和国网络小说", "Companies based in China"]
    assert _classify_wikipedia_page(mixed_novel, "") == "ambiguous"
    # A person page is non_work.
    person = ["Living people", "Japanese voice actors"]
    assert _classify_wikipedia_page(person, "is a Japanese voice actor") == "non_work"
    # Disambiguation is non_work.
    assert _classify_wikipedia_page(["Disambiguation pages"], "may refer to") == "non_work"
    # No decisive signal -> ambiguous (defer to the judge).
    assert _classify_wikipedia_page(["Foo"], "some text about a thing") == "ambiguous"
    # Mixed work + non_work categories -> ambiguous.
    mixed = ["Anime television series", "Companies based in Japan"]
    assert _classify_wikipedia_page(mixed, "") == "ambiguous"


# ---------------------------------------------------------------------------
# S1: work-level short-circuit (no LLM when title matches a known work)
# ---------------------------------------------------------------------------


async def test_process_short_circuits_known_series(db_session, sample_channel):
    """A resource whose pre-parsed title matches a known TVSeries links
    directly with no LLM call (S1)."""
    import uuid

    from app.models.file_resource import FileResource
    from app.models.series import TVSeries

    series = TVSeries(id=str(uuid.uuid4()), title_cn="黄泉使者", title_en="Yomi no Tsugai")
    db_session.add(series)
    resource = FileResource(
        id=str(uuid.uuid4()), channel_id=sample_channel.id, guid="g1",
        title_raw="[LoliHouse] 黄泉使者 / Yomi no Tsugai - 14 [1080p]",
        title_cn="黄泉使者", episode=14, season=1,
        torrent_url="magnet:?xt=urn:btih:test1",
    )
    db_session.add(resource)
    await db_session.commit()

    agent = UnifiedMetadataAgent()
    agent._run_react = AsyncMock()  # must NOT be called - short-circuit wins
    res = await agent.process(resource, sample_channel, db_session)

    agent._run_react.assert_not_called()
    assert res.found is True
    assert res.content_type == "tv"
    assert resource.series_id == series.id
    assert resource.movie_id is None
    assert resource.metadata_matched_at is not None
    assert resource.metadata_failure_type is None  # success


async def test_process_reuses_successful_sibling_resource_title(db_session, sample_channel):
    """A prior linked episode is a deterministic alias even when the metadata
    provider stored a different translation/romanisation on the work row."""
    import uuid

    from app.models.file_resource import FileResource
    from app.models.series import TVSeries
    from app.utils.time import utcnow

    series = TVSeries(
        id=str(uuid.uuid4()),
        title_cn="同一个研讨会的染谷同学是AV女优的事",
        title_en="同じゼミの染谷さんがセクシー女優だった話",
        external_id="mal:63619", external_source="mal",
        content_type="tv", number_of_seasons=1,
    )
    sibling = FileResource(
        id=str(uuid.uuid4()), channel_id=sample_channel.id, guid="sibling-e06",
        title_raw="[Sakurato] Onaji Zemi no Someya-san [06]",
        title_cn="关于同组的染谷同学是性感女优这件事。",
        title_en="Onaji Zemi no Someya-san ga Sexy Joyuu Datta Hanashi.",
        search_title="Onaji Zemi no Someya-san ga Sexy Joyuu Datta Hanashi.",
        series_id=series.id, season=1, episode=6,
        metadata_matched_at=utcnow(),
        torrent_url="magnet:?xt=urn:btih:sibling06",
    )
    target = FileResource(
        id=str(uuid.uuid4()), channel_id=sample_channel.id, guid="target-e07",
        title_raw="[桜都字幕组] 关于同组的染谷同学是性感女优这件事。 / "
                  "Onaji Zemi no Someya-san ga Sexy Joyuu Datta Hanashi. [07]",
        title_cn="关于同组的染谷同学是性感女优这件事。",
        title_en="Onaji Zemi no Someya-san ga Sexy Joyuu Datta Hanashi.",
        search_title="Onaji Zemi no Someya-san ga Sexy Joyuu Datta Hanashi.",
        episode=7,
        torrent_url="magnet:?xt=urn:btih:target07",
    )
    db_session.add_all([series, sibling, target])
    await db_session.commit()

    agent = UnifiedMetadataAgent()
    await agent._set_cache(
        target.title_raw,
        "wikipedia",
        ResourceMetadata(
            clean_title=target.title_raw,
            found=False,
            content_type="tv",
            subtitle_group="桜都字幕组",
            reason="No matching work found",
        ),
        db_session,
    )
    await db_session.commit()
    agent._run_react = AsyncMock()
    result = await agent.process(target, sample_channel, db_session)

    agent._run_react.assert_not_called()
    assert result.found is True
    assert target.series_id == series.id
    assert target.season == 1
    assert target.subtitle_group == "桜都字幕组"


async def test_process_resolves_asmr_to_audio_work(monkeypatch, db_session, sample_channel):
    """An ASMR title is detected and resolved to an AudioWork stub (no LLM,
    no TV/movie agent run)."""
    import uuid

    from app.models.audio_work import AudioWork
    from app.models.file_resource import FileResource

    sample_channel.metadata_source = "wikipedia"
    resource = FileResource(
        id=str(uuid.uuid4()), channel_id=sample_channel.id, guid="g_asmr",
        title_raw="【ASMR】愛上火車 少女們的祕事簿♪[WAV/MP3]",
        torrent_url="magnet:?xt=urn:btih:asmr1",
    )
    db_session.add(resource)
    await db_session.commit()

    agent = UnifiedMetadataAgent()
    # No Wikipedia page for this ASMR title -> stub path.
    monkeypatch.setattr(mar, "_search_audio_wikipedia", AsyncMock(return_value=None))
    agent._run_react = AsyncMock()  # must NOT be called - audio path wins

    res = await agent.process(resource, sample_channel, db_session, force_refresh=True)

    agent._run_react.assert_not_called()
    assert res.found is True
    assert res.content_type == "asmr"
    assert resource.audio_work_id is not None
    assert resource.series_id is None
    assert resource.movie_id is None
    assert resource.metadata_failure_type is None  # success
    aw = await db_session.get(AudioWork, resource.audio_work_id)
    assert aw is not None
    assert aw.content_type == "asmr"


async def test_process_force_refresh_bypasses_known_work_short_circuit(db_session, sample_channel):
    """An explicit re-fetch queries the source even for a known local work so
    missing work-level metadata such as its release year can be repaired."""
    import uuid

    from app.models.file_resource import FileResource
    from app.models.series import TVSeries

    series = TVSeries(id=str(uuid.uuid4()), title_cn="黄泉使者")
    db_session.add(series)
    resource = FileResource(
        id=str(uuid.uuid4()), channel_id=sample_channel.id, guid="g1",
        title_raw="[LoliHouse] 黄泉使者 - 14 [1080p]", title_cn="黄泉使者",
        torrent_url="magnet:?xt=urn:btih:test2",
    )
    db_session.add(resource)
    await db_session.commit()

    agent = UnifiedMetadataAgent()
    agent._get_cache = AsyncMock(return_value=None)
    agent._find_known_work = AsyncMock(return_value=("tv", series.id))
    agent._run_search_then_judge = AsyncMock(return_value=(
        {
            "found": False,
            "clean_title": "黄泉使者",
            "content_type": "tv",
            "reason": "not found",
        },
        {"method": None, "data_sources_used": [], "source_errors": {}, "error": None},
    ))
    await agent.process(resource, sample_channel, db_session, force_refresh=True)
    agent._find_known_work.assert_not_called()
    agent._run_search_then_judge.assert_called_once()


async def test_process_short_circuit_matches_season_suffixed_title(db_session, sample_channel):
    """S1 strips season from both sides: a resource titled "X 第四季" matches a
    series titled "X" (base). Catches the Slime-style mismatch."""
    import uuid

    from app.models.file_resource import FileResource
    from app.models.series import TVSeries

    series = TVSeries(id=str(uuid.uuid4()), title_cn="关于我转生变成史莱姆这档事")
    db_session.add(series)
    resource = FileResource(
        id=str(uuid.uuid4()), channel_id=sample_channel.id, guid="g1",
        title_raw="[G] 关于我转生变成史莱姆这档事 第四季 - 14 [1080p]",
        title_cn="关于我转生变成史莱姆这档事 第四季",
        torrent_url="magnet:?xt=urn:btih:test3",
    )
    db_session.add(resource)
    await db_session.commit()

    agent = UnifiedMetadataAgent()
    agent._run_react = AsyncMock()
    await agent.process(resource, sample_channel, db_session)
    agent._run_react.assert_not_called()
    assert resource.series_id == series.id


# ---------------------------------------------------------------------------
# S3: search-first + single-LLM-judge routing
# ---------------------------------------------------------------------------


async def test_process_routes_wikipedia_to_search_then_judge(db_session, sample_channel):
    """S3: a wikipedia-source resource uses _run_search_then_judge, not _run_react."""
    import uuid

    from app.models.file_resource import FileResource

    sample_channel.metadata_source = "wikipedia"
    resource = FileResource(
        id=str(uuid.uuid4()), channel_id=sample_channel.id, guid="g1",
        title_raw="[G] Some New Show - 01 [1080p]", title_cn="Some New Show",
        torrent_url="magnet:?xt=urn:btih:s3route",
    )
    db_session.add(resource)
    await db_session.commit()

    agent = UnifiedMetadataAgent()
    agent._get_cache = AsyncMock(return_value=None)
    agent._find_known_work = AsyncMock(return_value=None)  # no S1 short-circuit
    agent._run_search_then_judge = AsyncMock(return_value=(
        {"found": True, "clean_title": "Some New Show", "content_type": "tv"},
        {"method": "search_then_judge", "data_sources_used": ["wikipedia"],
         "source_errors": {}, "error": None},
    ))
    agent._apply_to_resource = AsyncMock()
    agent._set_cache = AsyncMock()
    agent._run_react = AsyncMock()  # must NOT be called for wikipedia

    await agent.process(resource, sample_channel, db_session)

    agent._run_search_then_judge.assert_called_once()
    agent._run_react.assert_not_called()


# ---------------------------------------------------------------------------
# Bangumi routing + web-fallback wiring
# ---------------------------------------------------------------------------


def _bangumi_found():
    return (
        {
            "found": True, "clean_title": "葬送的芙莉莲", "content_type": "tv",
            "matched_entity": {
                "external_id": "bangumi:400602", "external_source": "bangumi",
                "title_cn": "葬送的芙莉莲", "is_anime": True,
                "single_season_entry": True,
            },
        },
        {"method": "bangumi_search_then_autolink",
         "data_sources_used": ["bangumi"], "source_errors": {}, "error": None},
    )


def _bangumi_not_found():
    return (
        {"found": False, "clean_title": "Show", "content_type": "tv",
         "reason": "no credible match on Bangumi"},
        {"method": "bangumi_search_then_judge",
         "data_sources_used": ["bangumi"], "source_errors": {}, "error": None},
    )


def _bangumi_not_configured():
    # Missing Bangumi token -> transient miss (mirrors metadata_bangumi's
    # not-configured shape; the marker keeps it out of the cache and must NOT
    # trigger the web fallback).
    return (
        {"found": False, "clean_title": "Show", "content_type": "tv",
         "reason": "Bangumi API key not configured"},
        {"method": "bangumi", "data_sources_used": ["bangumi"],
         "source_errors": {}, "error": "Bangumi: api key not configured"},
    )


_FB_FOUND = (
    {"found": True, "content_type": "tv",
     "matched_entity": {"external_id": "tmdb:9", "external_source": "tmdb"}},
    {"method": "search_then_web_fallback", "data_sources_used": ["wigolo"],
     "source_errors": {}, "error": None},
)


def _stub_agent() -> UnifiedMetadataAgent:
    agent = UnifiedMetadataAgent()
    agent._apply_manual_mapping = AsyncMock(return_value=False)
    agent._resource_scope_is_current = AsyncMock(return_value=True)
    agent._manual_mapping_scope = AsyncMock(return_value=None)
    agent._get_cache = AsyncMock(return_value=None)
    agent._set_cache = AsyncMock()
    agent._apply_to_resource = AsyncMock()
    agent._run_search_then_judge = AsyncMock()
    agent._run_react = AsyncMock()
    agent._find_known_work = AsyncMock(return_value=None)  # no S1 short-circuit
    return agent


async def _bangumi_resource(db_session, channel):
    import uuid

    from app.models.file_resource import FileResource

    resource = FileResource(
        id=str(uuid.uuid4()), channel_id=channel.id, guid="g1",
        title_raw="[G] Show - 01 [1080p]", title_cn="Show",
        torrent_url="magnet:?xt=urn:btih:bgmroute",
    )
    db_session.add(resource)
    await db_session.commit()
    return resource


async def test_process_routes_bangumi_to_bangumi_search_then_judge(
    db_session, sample_channel, monkeypatch,
):
    """A bangumi-source channel dispatches to run_bangumi_search_then_judge
    (never _run_search_then_judge/_run_react) and its result passes through."""
    from app.services import metadata_bangumi as mb

    sample_channel.metadata_source = "bangumi"
    resource = await _bangumi_resource(db_session, sample_channel)

    run_bangumi = AsyncMock(return_value=_bangumi_found())
    monkeypatch.setattr(mb, "run_bangumi_search_then_judge", run_bangumi)
    agent = _stub_agent()

    meta = await agent.process(resource, sample_channel, db_session)

    run_bangumi.assert_awaited_once()
    assert run_bangumi.await_args.kwargs["resource"] is resource
    agent._run_search_then_judge.assert_not_called()
    agent._run_react.assert_not_called()
    assert meta.found is True
    assert meta.clean_title == "葬送的芙莉莲"
    assert meta.matched_entity["external_id"] == "bangumi:400602"
    assert meta.search_method == "bangumi_search_then_autolink"
    assert meta.data_sources_used == ["bangumi"]


async def test_process_bangumi_not_found_invokes_web_fallback(
    db_session, sample_channel, monkeypatch,
):
    """Bangumi found=False (non-transient) -> _maybe_web_fallback fires with
    the channel's ordered whitelist and its result is adopted."""
    from app.services import metadata_bangumi as mb

    sample_channel.metadata_source = "bangumi"
    sample_channel.metadata_fallback_sources = ["bangumi", "tmdb"]
    resource = await _bangumi_resource(db_session, sample_channel)

    monkeypatch.setattr(
        mb, "run_bangumi_search_then_judge",
        AsyncMock(return_value=_bangumi_not_found()),
    )
    fb = AsyncMock(return_value=_FB_FOUND)
    monkeypatch.setattr("app.services.metadata_agent.web_fallback_judge", fb)
    agent = _stub_agent()

    meta = await agent.process(resource, sample_channel, db_session)

    fb.assert_awaited_once()
    assert fb.await_args.kwargs["fallback_sources"] == ["bangumi", "tmdb"]
    assert fb.await_args.kwargs["resource"] is resource
    assert meta.found is True
    assert meta.matched_entity["external_id"] == "tmdb:9"
    assert meta.search_method == "react_then_web_fallback"
    assert set(meta.data_sources_used) == {"bangumi", "wigolo"}


async def test_process_bangumi_transient_miss_skips_web_fallback(
    db_session, sample_channel, monkeypatch,
):
    """Bangumi not-configured (transient) -> no fallback, no cache, and the
    resource keeps the transient failure marker for the backfill to retry."""
    from app.services import metadata_bangumi as mb

    sample_channel.metadata_source = "bangumi"
    resource = await _bangumi_resource(db_session, sample_channel)

    monkeypatch.setattr(
        mb, "run_bangumi_search_then_judge",
        AsyncMock(return_value=_bangumi_not_configured()),
    )
    fb = AsyncMock(return_value=_FB_FOUND)
    monkeypatch.setattr("app.services.metadata_agent.web_fallback_judge", fb)
    agent = _stub_agent()

    meta = await agent.process(resource, sample_channel, db_session)

    fb.assert_not_awaited()
    assert resource.metadata_failure_type == "transient"
    agent._set_cache.assert_not_called()
    assert meta.found is False
    assert meta.reason == "Bangumi API key not configured"


async def test_process_bangumi_found_skips_web_fallback(
    db_session, sample_channel, monkeypatch,
):
    """A direct bangumi hit never touches the web fallback."""
    from app.services import metadata_bangumi as mb

    sample_channel.metadata_source = "bangumi"
    resource = await _bangumi_resource(db_session, sample_channel)

    monkeypatch.setattr(
        mb, "run_bangumi_search_then_judge", AsyncMock(return_value=_bangumi_found())
    )
    fb = AsyncMock(return_value=_FB_FOUND)
    monkeypatch.setattr("app.services.metadata_agent.web_fallback_judge", fb)
    agent = _stub_agent()

    meta = await agent.process(resource, sample_channel, db_session)

    fb.assert_not_awaited()
    assert meta.found is True
    assert meta.matched_entity["external_id"] == "bangumi:400602"


def _title_only_agent(monkeypatch) -> UnifiedMetadataAgent:
    from app.services import runtime_config as _rc

    monkeypatch.setitem(_rc._overrides, "llm_api_key", "k")
    return UnifiedMetadataAgent()


async def test_title_only_bangumi_not_found_invokes_web_fallback(monkeypatch):
    """Title-only bangumi miss -> fallback fires with resource=None and the
    caller's fallback_sources (None = default order)."""
    from app.services import metadata_bangumi as mb

    monkeypatch.setattr(
        mb, "run_bangumi_search_then_judge",
        AsyncMock(return_value=_bangumi_not_found()),
    )
    fb = AsyncMock(return_value=_FB_FOUND)
    monkeypatch.setattr("app.services.metadata_agent.web_fallback_judge", fb)
    agent = _title_only_agent(monkeypatch)

    meta = await agent.process_title_only("Show - 01", "bangumi")

    fb.assert_awaited_once()
    assert fb.await_args.kwargs["fallback_sources"] is None
    assert fb.await_args.kwargs["resource"] is None
    assert meta.found is True
    assert meta.matched_entity["external_id"] == "tmdb:9"


async def test_title_only_bangumi_transient_miss_skips_web_fallback(monkeypatch):
    """Title-only bangumi not-configured (transient) -> fallback not called."""
    from app.services import metadata_bangumi as mb

    monkeypatch.setattr(
        mb, "run_bangumi_search_then_judge",
        AsyncMock(return_value=_bangumi_not_configured()),
    )
    fb = AsyncMock(return_value=_FB_FOUND)
    monkeypatch.setattr("app.services.metadata_agent.web_fallback_judge", fb)
    agent = _title_only_agent(monkeypatch)

    meta = await agent.process_title_only("Show - 01", "bangumi")

    fb.assert_not_awaited()
    assert meta.found is False
    assert meta.reason == "Bangumi API key not configured"


async def test_title_only_bangumi_found_skips_web_fallback(monkeypatch):
    """Title-only bangumi hit -> fallback not called."""
    from app.services import metadata_bangumi as mb

    monkeypatch.setattr(
        mb, "run_bangumi_search_then_judge", AsyncMock(return_value=_bangumi_found())
    )
    fb = AsyncMock(return_value=_FB_FOUND)
    monkeypatch.setattr("app.services.metadata_agent.web_fallback_judge", fb)
    agent = _title_only_agent(monkeypatch)

    meta = await agent.process_title_only("Show - 01", "bangumi")

    fb.assert_not_awaited()
    assert meta.found is True


# ---------------------------------------------------------------------------
# Source-scoped cache key + upsert
# ---------------------------------------------------------------------------


def test_cache_source_key_namespaces_by_source():
    from app.services.metadata_agent import _cache_source_key
    assert _cache_source_key("bangumi") == "metadata_agent:bangumi"
    assert _cache_source_key("tmdb") == "metadata_agent:tmdb"
    # Unset source resolves to the default (wikipedia), still its own namespace.
    assert _cache_source_key(None) == "metadata_agent:wikipedia"


async def test_get_cache_is_source_scoped(db_session):
    """A result cached under one source must not be returned for another."""
    agent = UnifiedMetadataAgent()
    meta = ResourceMetadata(
        clean_title="Show", content_type="tv", found=False,
        reason="No matching work found in Bangumi",
    )
    await agent._set_cache("[G] Show - 01", "bangumi", meta, db_session)
    await db_session.commit()

    hit = await agent._get_cache("[G] Show - 01", "bangumi", db_session)
    assert hit is not None and hit.found is False

    # Different source -> miss (no cross-source poisoning)
    miss = await agent._get_cache("[G] Show - 01", "tmdb", db_session)
    assert miss is None


async def test_set_cache_upsert_overwrites_same_source(db_session):
    """A force_refresh re-run writes the same (title, source) again - it must
    overwrite the stale row, not violate the unique constraint."""
    from sqlalchemy import func, select

    from app.models.metadata_cache import MetadataCache

    agent = UnifiedMetadataAgent()
    m1 = ResourceMetadata(clean_title="Show", found=True, content_type="tv")
    m2 = ResourceMetadata(clean_title="Show", found=False, content_type="tv", reason="No match")
    await agent._set_cache("[G] Show - 01", "bangumi", m1, db_session)
    await db_session.commit()
    await agent._set_cache("[G] Show - 01", "bangumi", m2, db_session)  # must not raise
    await db_session.commit()

    hit = await agent._get_cache("[G] Show - 01", "bangumi", db_session)
    assert hit is not None and hit.found is False  # m2 overwrote m1
    count = (await db_session.execute(
        select(func.count()).select_from(MetadataCache).where(
            MetadataCache.title == "[G] Show - 01",
            MetadataCache.source == "metadata_agent:bangumi",
        )
    )).scalar_one()
    assert count == 1  # no duplicate rows


# ---------------------------------------------------------------------------
# Wikipedia: transient infra failures must classify as transient (retry, never
# cached as a permanent not_found). The wikipediaapi library raises typed
# WikipediaException subclasses (WikiConnectionError, WikiHttpTimeoutError,
# WikiInvalidJsonError, WikiHttpError) which _wiki_call maps to a
# "Wikipedia request failed: ..." transient error.
# ---------------------------------------------------------------------------


def test_classify_failure_wikipedia_infra_error_is_transient():
    """A wikipediaapi infra failure (connection, timeout, invalid JSON, non-200)
    is mapped to 'Wikipedia request failed: ...' - an infra failure, not a 'no
    match' - so it retries and is not cached as permanent not_found."""
    for err in (
        "Wikipedia: Wikipedia request failed: WikiConnectionError (https://zh.wikipedia.org/w/api.php)",
        "Wikipedia: Wikipedia request failed: WikiHttpTimeoutError (https://zh.wikipedia.org/w/api.php)",
        "Wikipedia: Wikipedia request failed: WikiInvalidJsonError (https://zh.wikipedia.org/w/api.php)",
        "Wikipedia: Wikipedia request failed: WikiHttpError (https://zh.wikipedia.org/w/api.php)",
    ):
        assert _classify_failure(_meta(found=False, search_error=err)) == "transient", err


def test_classify_failure_wikipedia_page_not_found_is_not_found():
    """A genuine page-not-found (page.exists() is False) is a real no-match,
    not an infra failure - it should be cached as not_found, not retried
    forever."""
    assert _classify_failure(
        _meta(found=False, search_error="Wikipedia: Page not found: Some Title")
    ) == "not_found"


def test_classify_failure_wikipedia_legit_no_results_is_not_found():
    """A successful search that simply had no hits is a definitive not_found."""
    assert _classify_failure(
        _meta(found=False, reason="No matching work found in Wikipedia")
    ) == "not_found"


def test_extract_search_info_surfaces_wikipedia_infra_error():
    """A failed search_wikipedia must set search_error (not just source_errors)
    so _classify_failure can see the transient marker. Previously the wikipedia
    branch never set search_error, so transient failures were misclassified as
    not_found and cached permanently."""
    messages = [
        _ai_message("search_wikipedia", {"query": "复制品也要谈恋爱", "lang": "zh"}),
        _tool_message(
            "search_wikipedia",
            {"success": False, "data": [], "error": "Wikipedia request failed: WikiConnectionError (https://zh.wikipedia.org/w/api.php)"},
            "search_wikipedia",
        ),
    ]
    info = UnifiedMetadataAgent._extract_search_info(messages)
    assert "wikipedia" in info["data_sources_used"]
    assert "Wikipedia request failed" in info["source_errors"]["wikipedia"]
    assert info["error"] and "Wikipedia request failed" in info["error"]
    # The surfaced search_error must classify as transient end-to-end.
    assert _classify_failure(_meta(found=False, search_error=info["error"])) == "transient"


def test_extract_search_info_wikipedia_empty_results_no_search_error():
    """A successful search returning no hits records 'no results' but must NOT
    set search_error (it is a definitive not_found, not an infra failure)."""
    messages = [
        _ai_message("search_wikipedia", {"query": "No Match"}),
        _tool_message("search_wikipedia", {"success": True, "data": []}, "search_wikipedia"),
    ]
    info = UnifiedMetadataAgent._extract_search_info(messages)
    assert info["source_errors"]["wikipedia"] == "no results"
    assert info["error"] is None  # legit empty -> not an infra failure


# ---------------------------------------------------------------------------
# _wikipedia_client construction + _wiki_call error mapping (wikipediaapi mocked)
# ---------------------------------------------------------------------------


class _FakeWikiPage:
    """Stand-in for a ``wikipediaapi.WikipediaPage`` exposing the attributes
    touched by _execute_search_wikipedia / _execute_get_wikipedia_page."""

    def __init__(
        self,
        *,
        title="Some Page",
        pageid=42,
        fullurl="https://en.wikipedia.org/wiki/Some_Page",
        summary="A summary",
        categories=None,
        exists=True,
        summary_exc=None,
        categories_exc=None,
        langlinks=None,
    ):
        self.title = title
        self.pageid = pageid
        self.fullurl = fullurl
        self._summary = summary
        self._categories = categories if categories is not None else {}
        self._exists = exists
        self._summary_exc = summary_exc
        self._categories_exc = categories_exc
        self._langlinks = langlinks if langlinks is not None else {}

    @property
    def summary(self):
        if self._summary_exc is not None:
            raise self._summary_exc
        return self._summary

    @property
    def categories(self):
        if self._categories_exc is not None:
            raise self._categories_exc
        return self._categories

    def exists(self):
        return self._exists

    @property
    def langlinks(self):
        return self._langlinks


def _fake_search_results(pages):
    """Build a SearchResults-like object with a ``.pages`` dict keyed by title."""
    from types import SimpleNamespace

    return SimpleNamespace(pages={p.title: p for p in pages})


def test_wikipedia_client_sets_ua_and_language(monkeypatch):
    """_wikipedia_client builds a wikipediaapi.Wikipedia with a Wikimedia-
    compliant user_agent and the requested language."""
    import wikipediaapi

    from app.services import metadata_agent as ma
    from app.services.metadata_agent import _WIKIPEDIA_USER_AGENT

    ma._wikipedia_client.cache_clear()
    captured = {}

    class _FakeWikipedia:
        def __init__(self, **kwargs):
            captured.update(kwargs)

    monkeypatch.setattr(wikipediaapi, "Wikipedia", _FakeWikipedia)
    try:
        ma._wikipedia_client("zh")
    finally:
        ma._wikipedia_client.cache_clear()

    assert captured["user_agent"] == _WIKIPEDIA_USER_AGENT
    assert "rssripple" in captured["user_agent"].lower()
    assert captured["language"] == "zh"
    assert captured["extract_format"] == wikipediaapi.ExtractFormat.WIKI


def test_wikipedia_client_caches_per_language():
    """Repeated calls for the same language return the cached client."""
    from app.services import metadata_agent as ma

    ma._wikipedia_client.cache_clear()
    a = ma._wikipedia_client("en")
    b = ma._wikipedia_client("en")
    assert a is b
    ma._wikipedia_client.cache_clear()


async def test_execute_search_wikipedia_maps_infra_error_to_transient(monkeypatch):
    """A wikipediaapi WikipediaException is mapped to a transient 'Wikipedia
    request failed' error - never a definitive not_found - so the backfill
    retries and the cache is not poisoned. (Transient retrying itself is
    handled inside wikipediaapi.)"""
    import wikipediaapi

    from app.services import metadata_agent as ma

    wiki = MagicMock()
    wiki.search.side_effect = wikipediaapi.WikiConnectionError(
        "https://zh.wikipedia.org/w/api.php"
    )
    monkeypatch.setattr(wc, "_wikipedia_client", lambda lang: wiki)

    result = await ma._execute_search_wikipedia("复制品也要谈恋爱", lang="zh")

    assert result["success"] is False
    assert result["data"] == []
    assert "Wikipedia request failed" in result["error"]
    assert "WikiConnectionError" in result["error"]


async def test_execute_search_wikipedia_returns_pages_on_success(monkeypatch):
    """A successful search returns pages with the uniform
    {title, page_id, url, summary} shape the agent tool contract expects."""
    from app.services import metadata_agent as ma

    page = _FakeWikiPage(
        title="Breaking Bad",
        pageid=14426270,
        fullurl="https://en.wikipedia.org/wiki/Breaking_Bad",
        summary="Breaking Bad is an American neo-Western crime drama television series.",
    )
    wiki = MagicMock()
    wiki.search.return_value = _fake_search_results([page])
    monkeypatch.setattr(wc, "_wikipedia_client", lambda lang: wiki)

    result = await ma._execute_search_wikipedia("Breaking Bad", lang="en")

    assert result["success"] is True
    assert len(result["data"]) == 1
    p = result["data"][0]
    assert p["title"] == "Breaking Bad"
    assert p["page_id"] == 14426270
    assert p["url"] == "https://en.wikipedia.org/wiki/Breaking_Bad"
    assert p["summary"].startswith("Breaking Bad is an American")


async def test_execute_search_wikipedia_empty_results_is_success_empty(monkeypatch):
    """A successful search with no hits is a definitive not_found
    (success=True, empty data), not an infra failure."""
    from app.services import metadata_agent as ma

    wiki = MagicMock()
    wiki.search.return_value = _fake_search_results([])
    monkeypatch.setattr(wc, "_wikipedia_client", lambda lang: wiki)

    result = await ma._execute_search_wikipedia("No Match", lang="en")

    assert result["success"] is True
    assert result["data"] == []


async def test_execute_search_wikipedia_skips_missing_and_summary_failure(monkeypatch):
    """A non-existent result stub is skipped, and a transient summary-extract
    failure on one page must not sink the whole result - the page is kept with
    an empty summary."""
    import wikipediaapi

    from app.services import metadata_agent as ma

    good = _FakeWikiPage(title="Good Page", pageid=1, summary="ok")
    missing = _FakeWikiPage(title="Missing Page", pageid=-1, exists=False)
    broken = _FakeWikiPage(
        title="Broken Summary",
        pageid=2,
        summary_exc=wikipediaapi.WikiInvalidJsonError("https://en.wikipedia.org/w/api.php"),
    )
    wiki = MagicMock()
    wiki.search.return_value = _fake_search_results([good, missing, broken])
    monkeypatch.setattr(wc, "_wikipedia_client", lambda lang: wiki)

    result = await ma._execute_search_wikipedia("query", lang="en")

    assert result["success"] is True
    titles = [p["title"] for p in result["data"]]
    assert "Good Page" in titles
    assert "Missing Page" not in titles  # exists() False -> skipped
    assert "Broken Summary" in titles    # kept despite summary failure
    broken_row = next(p for p in result["data"] if p["title"] == "Broken Summary")
    assert broken_row["summary"] == ""   # fell back to empty


async def test_execute_get_wikipedia_page_returns_full_page(monkeypatch):
    """A successful page fetch returns title, page_id, url, summary, and
    categories in the agent tool contract shape."""
    from app.services import metadata_agent as ma

    page = _FakeWikiPage(
        title="Breaking Bad",
        pageid=14426270,
        fullurl="https://en.wikipedia.org/wiki/Breaking_Bad",
        summary="Breaking Bad is an American neo-Western crime drama.",
        categories={
            "Category:2000s American crime drama television series": object(),
            "Category:Television series by Sony Pictures Television": object(),
        },
    )
    wiki = MagicMock()
    wiki.page.return_value = page
    monkeypatch.setattr(wc, "_wikipedia_client", lambda lang: wiki)
    monkeypatch.setattr(
        wc,
        "_fetch_wikipedia_page_image",
        AsyncMock(return_value="https://upload.wikimedia.org/bb.jpg"),
    )

    result = await ma._execute_get_wikipedia_page("Breaking Bad", lang="en")

    assert result["success"] is True
    d = result["data"]
    assert d["title"] == "Breaking Bad"
    assert d["page_id"] == 14426270
    assert d["url"] == "https://en.wikipedia.org/wiki/Breaking_Bad"
    assert d["summary"].startswith("Breaking Bad is an American")
    assert "Category:2000s American crime drama television series" in d["categories"]
    assert d["poster_url"] == "https://upload.wikimedia.org/bb.jpg"


async def test_execute_get_wikipedia_page_not_found(monkeypatch):
    """A page that does not exist returns a non-transient 'Page not found'
    error (cached as not_found, not retried forever)."""
    from app.services import metadata_agent as ma

    page = _FakeWikiPage(title="Nope", pageid=-1, exists=False)
    wiki = MagicMock()
    wiki.page.return_value = page
    monkeypatch.setattr(wc, "_wikipedia_client", lambda lang: wiki)

    result = await ma._execute_get_wikipedia_page("Nope", lang="en")

    assert result["success"] is False
    assert "Page not found" in result["error"]


async def test_execute_get_wikipedia_page_maps_infra_error_to_transient(monkeypatch):
    """A wikipediaapi WikipediaException during page load is mapped to a
    transient 'Wikipedia request failed' error."""
    import wikipediaapi

    from app.services import metadata_agent as ma

    page = _FakeWikiPage()
    # exists() raises - simulates an info-fetch infra failure.
    page.exists = MagicMock(
        side_effect=wikipediaapi.WikiHttpTimeoutError("https://en.wikipedia.org/w/api.php")
    )
    wiki = MagicMock()
    wiki.page.return_value = page
    monkeypatch.setattr(wc, "_wikipedia_client", lambda lang: wiki)

    result = await ma._execute_get_wikipedia_page("Some Title", lang="en")

    assert result["success"] is False
    assert "Wikipedia request failed" in result["error"]
    assert "WikiHttpTimeoutError" in result["error"]


async def test_execute_get_wikipedia_page_detects_disambiguation(monkeypatch):
    """A disambiguation page (detected via category membership) returns the
    disambiguation payload so the agent can ask for a more specific title."""
    from app.services import metadata_agent as ma

    page = _FakeWikiPage(
        title="Mercury (disambiguation)",
        categories={"Category:Disambiguation pages": object()},
    )
    wiki = MagicMock()
    wiki.page.return_value = page
    monkeypatch.setattr(wc, "_wikipedia_client", lambda lang: wiki)

    result = await ma._execute_get_wikipedia_page("Mercury", lang="en")

    assert result["success"] is True
    assert result["data"]["disambiguation"] is True


async def test_search_then_judge_skips_autolink_for_non_work_page(monkeypatch):
    """B1: a Wikipedia page whose title matches the query with high similarity
    but whose categories mark it a non-work entity (here a TV station) must NOT
    be auto-linked as a series. The auto-link branch is skipped and the path
    falls through to the judge / ReAct - the gate that stops a leaked station
    token from becoming a bogus TVSeries on title similarity alone."""
    from app.services import metadata_agent as ma

    # "幪面超人" is a real work name (not a station token), so A1 lets the query
    # through. The search returns a page titled identically (similarity 100) but
    # whose categories mark it a TV station, not a show.
    station_page = _FakeWikiPage(
        title="幪面超人",
        pageid=999,
        fullurl="https://zh.wikipedia.org/wiki/999",
        summary="幪面超人 is a television channel.",
        categories={
            "Category:Television channels in Hong Kong": object(),
            "Category:Companies based in Hong Kong": object(),
        },
    )
    wiki = MagicMock()
    wiki.search.return_value = _fake_search_results([station_page])
    wiki.page.return_value = station_page
    monkeypatch.setattr(wc, "_wikipedia_client", lambda lang: wiki)
    monkeypatch.setattr(wc, "_fetch_wikipedia_page_image", AsyncMock(return_value=None))

    agent = ma.UnifiedMetadataAgent()
    agent._model = MagicMock()
    # Judge returns no match; found=false WITH evidence falls back to _run_react.
    judge_resp = MagicMock()
    judge_resp.content = (
        '{"found": false, "clean_title": "幪面超人", "content_type": "tv", '
        '"reason": "no work-type candidate"}'
    )
    agent._model.ainvoke = AsyncMock(return_value=judge_resp)
    react_spy = AsyncMock(return_value=(
        {"found": False, "clean_title": "幪面超人", "content_type": "tv", "reason": "no match"},
        {"method": "react", "data_sources_used": [], "source_errors": {}, "error": None},
    ))
    agent._run_react = react_spy

    from app.services import runtime_config as rc_module

    monkeypatch.setattr(rc_module, "_overrides", {"web_fallback_enabled": "false"})

    resource = SimpleNamespace(
        title_cn=None, title_en=None, search_title="幪面超人",
        title="幪面超人 - 42", episode=42, season=1,
    )
    finalize, info = await agent._run_search_then_judge(
        "幪面超人 - 42", "wikipedia", resource, web_searcher=None,
    )

    # Had B1 not skipped, auto-link would have returned method
    # "search_then_autolink" with found=True and a matched_entity.
    assert info["method"] != "search_then_autolink"
    assert finalize.get("found") is False
    # Fallback disabled in this test: judge found=False with evidence falls through
    # to the original ReAct second-opinion path.
    assert react_spy.await_count == 1


def test_is_disambiguation_category_heuristic():
    from app.services.metadata_agent import _is_disambiguation_category as _isd

    assert _isd(["Category:Disambiguation pages"]) is True
    assert _isd(["Category:All article disambiguation pages"]) is True
    assert _isd(["Category:消歧义页"]) is True
    assert _isd(["Category:曖昧さ回避"]) is True
    assert _isd(["Category:2000s American crime drama television series"]) is False
    assert _isd([]) is False


class _FakeImageResp:
    def __init__(self, payload, *, raise_exc=None, status_code=200):
        self._payload = payload
        self._raise = raise_exc
        self.status_code = status_code

    def raise_for_status(self):
        if self._raise is not None:
            raise self._raise

    def json(self):
        return self._payload


class _FakeImageClient:
    """Minimal stand-in for ``httpx.AsyncClient`` used by the pageimages
    fetcher - records the request and returns a canned response."""

    def __init__(self, payload, *, raise_exc=None):
        self._resp = _FakeImageResp(payload, raise_exc=raise_exc)
        self.last_url = None
        self.last_params = None
        self.last_headers = None

    async def __aenter__(self):
        return self

    async def __aexit__(self, *a):
        return False

    async def get(self, url, params=None, headers=None):
        self.last_url = url
        self.last_params = params
        self.last_headers = headers
        return self._resp


async def test_fetch_wikipedia_page_image_prefers_original(monkeypatch):
    """The full-res ``original.source`` is preferred over the thumbnail."""
    import httpx

    from app.services import metadata_agent as ma

    payload = {
        "query": {
            "pages": {
                "12345": {
                    "pageid": 12345,
                    "title": "二十世纪电气目录",
                    "original": {"source": "https://upload.wikimedia.org/full.jpg", "width": 800},
                    "thumbnail": {"source": "https://upload.wikimedia.org/500px.jpg", "width": 500},
                }
            }
        }
    }
    fake = _FakeImageClient(payload)
    monkeypatch.setattr(httpx, "AsyncClient", lambda *a, **kw: fake)

    url = await ma._fetch_wikipedia_page_image("二十世纪电气目录", lang="zh")

    assert url == "https://upload.wikimedia.org/full.jpg"
    assert fake.last_url == "https://zh.wikipedia.org/w/api.php"
    assert fake.last_params["prop"] == "pageimages"
    assert fake.last_params["titles"] == "二十世纪电气目录"
    assert fake.last_headers["User-Agent"]


async def test_fetch_wikipedia_page_image_falls_back_to_thumbnail(monkeypatch):
    """When no original is present, the 500px thumbnail source is used."""
    import httpx

    from app.services import metadata_agent as ma

    payload = {
        "query": {
            "pages": {
                "1": {
                    "title": "NoOriginal",
                    "thumbnail": {"source": "https://upload.wikimedia.org/500px.jpg"},
                }
            }
        }
    }
    monkeypatch.setattr(httpx, "AsyncClient", lambda *a, **kw: _FakeImageClient(payload))

    url = await ma._fetch_wikipedia_page_image("NoOriginal", lang="en")

    assert url == "https://upload.wikimedia.org/500px.jpg"


async def test_fetch_wikipedia_page_image_none_when_no_image(monkeypatch):
    """A page without any pageimages entry yields None (non-fatal)."""
    import httpx

    from app.services import metadata_agent as ma

    payload = {"query": {"pages": {"1": {"title": "Plain Page"}}}}
    monkeypatch.setattr(httpx, "AsyncClient", lambda *a, **kw: _FakeImageClient(payload))

    url = await ma._fetch_wikipedia_page_image("Plain Page", lang="en")

    assert url is None


async def test_fetch_wikipedia_page_image_returns_none_on_http_error(monkeypatch):
    """An HTTP error from the API is swallowed and returns None rather than
    propagating - the caller must treat a missing poster as non-fatal."""
    import httpx

    from app.services import metadata_agent as ma

    monkeypatch.setattr(
        httpx,
        "AsyncClient",
        lambda *a, **kw: _FakeImageClient(None, raise_exc=httpx.HTTPStatusError(
            "403", request=httpx.Request("GET", "https://x"), response=httpx.Response(403)
        )),
    )

    url = await ma._fetch_wikipedia_page_image("Whatever", lang="ja")

    assert url is None


class _UrlAwareImageClient:
    """Returns a different canned response depending on whether the request
    hits the ``api.php`` (pageimages prop) or the REST ``summary`` endpoint,
    so the fallback path can be exercised."""

    def __init__(self, api_payload, rest_payload):
        self._api = api_payload
        self._rest = rest_payload

    async def __aenter__(self):
        return self

    async def __aexit__(self, *a):
        return False

    async def get(self, url, params=None, headers=None):
        if "rest_v1" in url:
            return _FakeImageResp(self._rest)
        return _FakeImageResp(self._api)


async def test_fetch_wikipedia_page_image_falls_back_to_rest_summary(monkeypatch):
    """When the pageimages prop returns no image (some zh pages are not
    assessed), the REST summary endpoint's ``originalimage`` is used instead."""
    import httpx

    from app.services import metadata_agent as ma

    # pageimages: page exists but has no original/thumbnail (the
    # 二十世纪电气目录 case).
    api_payload = {
        "query": {"pages": {"6502776": {"pageid": 6502776, "title": "二十世纪电气目录"}}}
    }
    rest_payload = {
        "title": "二十世纪电气目录",
        "originalimage": {"source": "https://upload.wikimedia.org/wikipedia/zh/4/40/20th_den_moku.png"},
    }
    monkeypatch.setattr(
        httpx,
        "AsyncClient",
        lambda *a, **kw: _UrlAwareImageClient(api_payload, rest_payload),
    )

    url = await ma._fetch_wikipedia_page_image(
        "二十世纪电气目录", lang="zh", page_id=6502776, expected_title="二十世纪电气目录"
    )

    assert url == "https://upload.wikimedia.org/wikipedia/zh/4/40/20th_den_moku.png"


async def test_fetch_wikipedia_page_image_rejects_mismatched_rest_title(monkeypatch):
    """The REST fallback is queried by title, so a non-canonical stored title
    can resolve to a different page (e.g. simplified ``灌篮高手`` hitting a
    non-Slam-Dunk zh page). When the REST page title doesn't match
    ``expected_title``, the image is rejected to avoid caching a wrong poster."""
    import httpx

    from app.services import metadata_agent as ma

    api_payload = {
        "query": {"pages": {"1": {"pageid": 1, "title": "灌篮高手"}}}  # no image
    }
    # REST resolved to an unrelated page whose title is nothing like Slam Dunk.
    rest_payload = {
        "title": "Westchester Compilation",
        "originalimage": {"source": "https://upload.wikimedia.org/wikipedia/commons/x/x/Westchester.png"},
    }
    monkeypatch.setattr(
        httpx,
        "AsyncClient",
        lambda *a, **kw: _UrlAwareImageClient(api_payload, rest_payload),
    )

    url = await ma._fetch_wikipedia_page_image(
        "灌篮高手", lang="zh", page_id=1, expected_title="灌篮高手"
    )

    assert url is None


async def test_fetch_wikipedia_page_image_rejects_wrong_pageid_then_rest_rescues(monkeypatch):
    """A stale ``page_id`` can point at the wrong article (e.g. Slam Dunk's
    stored pageid actually resolves to ``西徹斯特郡``). The pageimages image is
    rejected by title mismatch, then the REST-by-title fallback finds the real
    article and returns its image."""
    import httpx

    from app.services import metadata_agent as ma

    # pageimages: pageid 471518 resolves to the wrong article, which happens to
    # carry an unrelated image.
    api_payload = {
        "query": {
            "pages": {
                "471518": {
                    "pageid": 471518,
                    "title": "西徹斯特郡",
                    "original": {"source": "https://upload.wikimedia.org/Westchester.png"},
                }
            }
        }
    }
    # REST (queried by the work title) finds the real Slam Dunk article.
    rest_payload = {
        "title": "灌籃高手",
        "originalimage": {"source": "https://upload.wikimedia.org/Slam_Dunk_cover.png"},
    }
    monkeypatch.setattr(
        httpx,
        "AsyncClient",
        lambda *a, **kw: _UrlAwareImageClient(api_payload, rest_payload),
    )

    url = await ma._fetch_wikipedia_page_image(
        "灌篮高手", lang="zh", page_id=471518, expected_title="灌篮高手"
    )

    assert url == "https://upload.wikimedia.org/Slam_Dunk_cover.png"


# ---------------------------------------------------------------------------
# Cross-language convergence via Wikipedia langlinks
# ---------------------------------------------------------------------------


async def test_execute_get_wikipedia_page_includes_langlinks(monkeypatch):
    """Page fetch carries langlink titles (en/zh/ja only) so the upsert can
    converge per-language wiki pages of the same work onto one row."""
    from app.services import metadata_agent as ma

    page = _FakeWikiPage(
        title="Daemons of the Shadow Realm",
        pageid=70545449,
        fullurl="https://en.wikipedia.org/wiki/Daemons_of_the_Shadow_Realm",
        summary="Daemons of the Shadow Realm is a Japanese manga series.",
        categories={"Category:Japanese manga series": object()},
        langlinks={
            "zh": SimpleNamespace(title="黃泉使者"),
            "ja": SimpleNamespace(title="黄泉のツガイ"),
            "fr": SimpleNamespace(title="Les Démons du royaume des ombres"),
        },
    )
    wiki = MagicMock()
    wiki.page.return_value = page
    monkeypatch.setattr(wc, "_wikipedia_client", lambda lang: wiki)
    monkeypatch.setattr(wc, "_fetch_wikipedia_page_image", AsyncMock(return_value=None))

    result = await ma._execute_get_wikipedia_page("Daemons of the Shadow Realm", lang="en")

    assert result["success"] is True
    assert result["data"]["langlinks"] == {
        "zh": "黃泉使者",
        "ja": "黄泉のツガイ",
    }  # fr filtered out - only the languages we search in


async def test_search_then_judge_autolink_fills_cross_language_titles(monkeypatch):
    """Auto-link on an en page must populate title_cn from the langlinks and
    carry all langlink titles as alt_titles - the bridge that prevents a
    per-language duplicate series row."""
    from app.services import metadata_agent as ma

    en_page = _FakeWikiPage(
        title="Daemons of the Shadow Realm",
        pageid=70545449,
        fullurl="https://en.wikipedia.org/wiki/Daemons_of_the_Shadow_Realm",
        summary="Daemons of the Shadow Realm is a Japanese manga series.",
        categories={"Category:Japanese manga series": object()},
        langlinks={"zh": SimpleNamespace(title="黃泉使者")},
    )
    wiki = MagicMock()
    wiki.search.return_value = _fake_search_results([en_page])
    wiki.page.return_value = en_page
    monkeypatch.setattr(wc, "_wikipedia_client", lambda lang: wiki)
    monkeypatch.setattr(wc, "_fetch_wikipedia_page_image", AsyncMock(return_value=None))

    agent = ma.UnifiedMetadataAgent()
    agent._model = MagicMock()  # judge must NOT be reached (auto-link path)

    resource = SimpleNamespace(
        title_cn=None, title_en="Daemons of the Shadow Realm",
        search_title="Daemons of the Shadow Realm",
        title="Daemons of the Shadow Realm - 16", episode=16, season=1,
    )
    finalize, info = await agent._run_search_then_judge(
        "Daemons of the Shadow Realm - 16", "wikipedia", resource, web_searcher=None,
    )

    assert info["method"] == "search_then_autolink"
    me = finalize["matched_entity"]
    assert me["external_id"] == "wikipedia:en:70545449"
    assert me["title_en"] == "Daemons of the Shadow Realm"
    assert me["title_cn"] == "黃泉使者"          # filled from langlinks
    assert me["alt_titles"] == ["黃泉使者"]
    assert finalize["title_cn"] == "黃泉使者"


# ---------------------------------------------------------------------------
# Episode reconciliation on agent-free link paths
# ---------------------------------------------------------------------------

from app.services.metadata_episode_reconcile import (  # noqa: E402
    apply_episode_reconcile,
    locate_absolute_episode,
    seasons_map_from_list,
)


class TestLocateAbsoluteEpisode:
    def test_locates_within_seasons(self):
        m = {1: 24, 2: 24, 3: 24, 4: 24}
        assert locate_absolute_episode(88, m) == (4, 16)
        assert locate_absolute_episode(1, m) == (1, 1)
        assert locate_absolute_episode(24, m) == (1, 24)
        assert locate_absolute_episode(25, m) == (2, 1)
        assert locate_absolute_episode(96, m) == (4, 24)

    def test_final_season_tolerance(self):
        # TMDB episode_count lags a still-airing show: preserve E25/E26.
        m = {1: 24, 2: 24, 3: 24, 4: 24}
        assert locate_absolute_episode(97, m) == (4, 25)
        assert locate_absolute_episode(98, m) == (4, 26)
        assert locate_absolute_episode(99, m) is None

    def test_beyond_total_returns_none(self):
        assert locate_absolute_episode(200, {1: 24, 2: 24, 3: 24, 4: 24}) is None
        assert locate_absolute_episode(10, {}) is None
        assert locate_absolute_episode(0, {1: 24}) is None

    def test_sparse_season_map(self):
        assert locate_absolute_episode(30, {2: 12, 4: 24}) == (4, 18)


class TestApplyEpisodeReconcileSeasonDerivation:
    """Season-None + absolute_episode path (NN(MM) double-labelled releases
    whose season was never parsed — the 史莱姆 S4E16(88) case)."""

    MAP = {1: 24, 2: 24, 3: 24, 4: 24}

    def test_derives_season_from_absolute(self):
        r = SimpleNamespace(episode=16, season=None, is_batch=False,
                            episode_confidence="reconciled", absolute_episode=88)
        ok = apply_episode_reconcile(r, self.MAP)
        assert ok is True
        assert r.season == 4
        assert r.episode == 16
        assert r.episode_confidence == "reconciled"

    def test_beyond_total_marks_ambiguous(self):
        r = SimpleNamespace(episode=None, season=None, is_batch=False,
                            episode_confidence=None, absolute_episode=200)
        ok = apply_episode_reconcile(r, self.MAP)
        assert ok is True
        assert r.episode_confidence == "ambiguous"
        assert r.season is None

    def test_manual_untouched(self):
        r = SimpleNamespace(episode=16, season=None, is_batch=False,
                            episode_confidence="manual", absolute_episode=88)
        assert apply_episode_reconcile(r, self.MAP) is False
        assert r.season is None
        assert r.episode_confidence == "manual"

    def test_batch_untouched(self):
        r = SimpleNamespace(episode=None, season=None, is_batch=True,
                            episode_confidence=None, absolute_episode=88)
        assert apply_episode_reconcile(r, self.MAP) is False
        assert r.episode_confidence is None

    def test_no_absolute_no_season_marks_raw(self):
        r = SimpleNamespace(episode=5, season=None, is_batch=False,
                            episode_confidence=None, absolute_episode=None)
        assert apply_episode_reconcile(r, self.MAP) is False
        assert r.episode_confidence == "raw"
        assert r.episode == 5  # kept

    def test_no_episode_no_absolute_skips(self):
        r = SimpleNamespace(episode=None, season=None, is_batch=False,
                            episode_confidence=None, absolute_episode=None)
        assert apply_episode_reconcile(r, self.MAP) is False
        assert r.episode_confidence is None


def test_seasons_map_from_list():
    seasons = [
        {"season_number": 0, "episode_count": 3},   # specials ignored
        {"season_number": 1, "episode_count": 24},
        {"season_number": 2, "episode_count": 24},
    ]
    assert seasons_map_from_list(seasons) == {1: 24, 2: 24}
    assert seasons_map_from_list(None) == {}
    assert seasons_map_from_list([]) == {}


class TestApplyEpisodeReconcile:
    def test_converts_absolute_to_per_season(self):
        r = SimpleNamespace(episode=89, season=4, is_batch=False, episode_confidence=None,
                absolute_episode=None)
        ok = apply_episode_reconcile(r, {1: 24, 2: 24, 3: 24, 4: 24})
        assert ok is True
        assert r.episode == 17
        assert r.absolute_episode == 89
        assert r.episode_confidence == "reconciled"

    def test_marks_ambiguous_when_arithmetic_fails(self):
        r = SimpleNamespace(episode=89, season=1, is_batch=False, episode_confidence=None,
                absolute_episode=None)
        ok = apply_episode_reconcile(r, {1: 24, 2: 24, 3: 24, 4: 24})
        assert ok is True
        assert r.episode == 89  # kept
        assert r.episode_confidence == "ambiguous"

    def test_marks_raw_when_no_basis(self):
        r = SimpleNamespace(episode=89, season=4, is_batch=False, episode_confidence=None,
                absolute_episode=None)
        ok = apply_episode_reconcile(r, {})
        assert ok is False
        assert r.episode_confidence == "raw"

    def test_keeps_per_season_episode(self):
        r = SimpleNamespace(episode=17, season=4, is_batch=False, episode_confidence=None,
                absolute_episode=None)
        ok = apply_episode_reconcile(r, {1: 24, 2: 24, 3: 24, 4: 24})
        assert ok is True
        assert r.episode == 17
        assert r.episode_confidence == "raw"

    def test_skips_manual_and_reconciled(self):
        for conf in ("manual", "reconciled"):
            r = SimpleNamespace(episode=89, season=4, is_batch=False, episode_confidence=conf,
                    absolute_episode=None)
            assert apply_episode_reconcile(r, {1: 24, 2: 24, 3: 24, 4: 24}) is False
            assert r.episode == 89
            assert r.episode_confidence == conf

    def test_skips_batch(self):
        r = SimpleNamespace(episode=89, season=4, is_batch=True, episode_confidence=None,
                absolute_episode=None)
        assert apply_episode_reconcile(r, {1: 24, 2: 24, 3: 24, 4: 24}) is False
        assert r.episode_confidence is None


async def test_process_short_circuit_reconciles_absolute_episode(db_session, sample_channel):
    """Known-work short-circuit must reconcile absolute-across-seasons episode
    numbers using the series' persisted seasons (the agent's apply path is
    bypassed on short-circuit)."""
    import uuid

    from app.models.file_resource import FileResource
    from app.models.series import TVSeries

    series = TVSeries(
        id=str(uuid.uuid4()), title_cn="關於我轉生變成史萊姆這檔事",
        title_en="That Time I Got Reincarnated as a Slime",
        seasons=[{"season_number": n, "episode_count": 24} for n in (1, 2, 3, 4)],
    )
    db_session.add(series)
    resource = FileResource(
        id=str(uuid.uuid4()), channel_id=sample_channel.id, guid="g_slime",
        title_raw="[X] 關於我轉生變成史萊姆這檔事 / That Time I Got Reincarnated as a Slime - 89 [1080p]",
        title_cn="關於我轉生變成史萊姆這檔事", episode=89, season=4,
        torrent_url="magnet:?xt=urn:btih:slime89",
    )
    db_session.add(resource)
    await db_session.commit()

    agent = UnifiedMetadataAgent()
    agent._run_react = AsyncMock()  # must NOT be called - short-circuit wins
    res = await agent.process(resource, sample_channel, db_session)

    agent._run_react.assert_not_called()
    assert res.found is True
    assert resource.series_id == series.id
    assert resource.episode == 17
    assert resource.season == 4
    assert resource.absolute_episode == 89
    assert resource.episode_confidence == "reconciled"


async def test_process_short_circuit_without_seasons_marks_nothing(db_session, sample_channel):
    """Short-circuit with a series lacking seasons data leaves the episode
    untouched (and does not crash)."""
    import uuid

    from app.models.file_resource import FileResource
    from app.models.series import TVSeries

    series = TVSeries(id=str(uuid.uuid4()), title_cn="黄泉使者", title_en="Yomi no Tsugai")
    db_session.add(series)
    resource = FileResource(
        id=str(uuid.uuid4()), channel_id=sample_channel.id, guid="g_yomi",
        title_raw="[LoliHouse] 黄泉使者 / Yomi no Tsugai - 14 [1080p]",
        title_cn="黄泉使者", episode=14, season=1,
        torrent_url="magnet:?xt=urn:btih:yomi14",
    )
    db_session.add(resource)
    await db_session.commit()

    agent = UnifiedMetadataAgent()
    agent._run_react = AsyncMock()
    await agent.process(resource, sample_channel, db_session)

    agent._run_react.assert_not_called()
    assert resource.episode == 14
    assert resource.episode_confidence is None


async def test_series_history_context_includes_siblings(monkeypatch, db_session, sample_channel):
    """The few-shot context lists the candidate series' numbering convention
    and past sibling parses."""
    import uuid

    import app.services.metadata_service as ms
    from app.models.file_resource import FileResource
    from app.models.series import TVSeries

    series = TVSeries(
        id=str(uuid.uuid4()), title_cn="關於我轉生變成史萊姆這檔事",
        seasons=[{"season_number": n, "episode_count": 24} for n in (1, 2, 3, 4)],
    )
    db_session.add(series)
    sibling = FileResource(
        id=str(uuid.uuid4()), channel_id=sample_channel.id, guid="g_sib",
        title_raw="【豌豆字幕组】[... S4][17(89)][1080P]",
        series_id=series.id, episode=17, season=4, absolute_episode=89,
        episode_confidence="reconciled",
        torrent_url="magnet:?xt=urn:btih:sib",
    )
    db_session.add_all([sibling])
    await db_session.commit()

    monkeypatch.setattr(ms, "match_series_by_title", AsyncMock(return_value=(series, 88)))
    resource = SimpleNamespace(search_title="關於我轉生變成史萊姆這檔事", title_raw="[X] ... - 90")

    agent = UnifiedMetadataAgent()
    ctx = await agent._build_series_history_context(resource, db_session)

    assert ctx is not None
    assert "關於我轉生變成史萊姆這檔事" in ctx
    assert "{1: 24, 2: 24, 3: 24, 4: 24}" in ctx
    assert "S4E17" in ctx
    assert "absolute 89" in ctx


async def test_series_history_context_none_without_match(monkeypatch, db_session):
    import app.services.metadata_service as ms

    monkeypatch.setattr(ms, "match_series_by_title", AsyncMock(return_value=(None, 0)))
    agent = UnifiedMetadataAgent()
    resource = SimpleNamespace(search_title="unknown work", title_raw="[X] unknown - 01")
    assert await agent._build_series_history_context(resource, db_session) is None


# ---------------------------------------------------------------------------
# Batch 2: season verification (never guess the season)
# ---------------------------------------------------------------------------

from app.services.metadata_agent import (  # noqa: E402
    _apply_verified_season_default,
    _validate_inferred_season,
)
from app.services.metadata_episode_reconcile import (  # noqa: E402
    season_evidence_from_series,
    verified_season_count,
)


class TestApplyEpisodeReconcileCrossCheck:
    """Title season marker vs absolute arithmetic: a conflict must flag the
    resource ambiguous — never silently trust one side."""

    MAP = {1: 24, 2: 24, 3: 24, 4: 24}

    def test_conflict_marks_ambiguous(self):
        # absolute 30 locates to S2E6, but the resource holds S1E5.
        r = SimpleNamespace(episode=5, season=1, is_batch=False,
                            episode_confidence=None, absolute_episode=30)
        ok = apply_episode_reconcile(r, self.MAP)
        assert ok is True
        assert r.episode_confidence == "ambiguous"
        assert r.season == 1 and r.episode == 5  # values untouched

    def test_consistent_pair_passes_through(self):
        # absolute 30 == S2E6 — consistent; falls through to reconcile_episode
        # which keeps the in-range per-season number as "raw".
        r = SimpleNamespace(episode=6, season=2, is_batch=False,
                            episode_confidence=None, absolute_episode=30)
        ok = apply_episode_reconcile(r, self.MAP)
        assert ok is True
        assert r.episode == 6
        assert r.episode_confidence == "raw"

    def test_locate_none_is_no_evidence(self):
        # absolute overshoots the total + tolerance → locate returns None →
        # the cross-check stays silent and normal reconcile runs.
        r = SimpleNamespace(episode=5, season=1, is_batch=False,
                            episode_confidence=None, absolute_episode=999)
        apply_episode_reconcile(r, self.MAP)
        assert r.episode_confidence == "raw"

    def test_manual_never_cross_checked(self):
        r = SimpleNamespace(episode=5, season=1, is_batch=False,
                            episode_confidence="manual", absolute_episode=30)
        assert apply_episode_reconcile(r, self.MAP) is False
        assert r.episode_confidence == "manual"

    def test_reconciled_nn_mm_beyond_total_not_reflagged(self):
        # Pre-parser NN(MM) double-label: absolute beyond the map's total +
        # tolerance → locate None → the "reconciled" tag is left alone.
        r = SimpleNamespace(episode=16, season=4, is_batch=False,
                            episode_confidence="reconciled", absolute_episode=200)
        assert apply_episode_reconcile(r, self.MAP) is False
        assert r.episode_confidence == "reconciled"


class TestVerifiedSeasonCount:
    def test_number_of_seasons_preferred(self):
        assert verified_season_count({"number_of_seasons": 3}) == 3
        assert verified_season_count(
            {"number_of_seasons": 2, "seasons": [{"season_number": 1}]}
        ) == 2

    def test_seasons_list_excludes_specials(self):
        assert verified_season_count({"seasons": [
            {"season_number": 0, "episode_count": 3},
            {"season_number": 1, "episode_count": 12},
        ]}) == 1

    def test_no_usable_data_returns_none(self):
        assert verified_season_count(None) is None
        assert verified_season_count({}) is None
        assert verified_season_count({"number_of_seasons": 0, "seasons": []}) is None
        assert verified_season_count({"seasons": [{"season_number": 0}]}) is None

    def test_match_scoped_single_season_entry(self):
        assert verified_season_count({"single_season_entry": True}) == 1
        # Explicit work-level structure remains authoritative.
        assert verified_season_count({
            "number_of_seasons": 2,
            "single_season_entry": True,
        }) == 2

    def test_bangumi_series_identity_restores_entry_evidence(self):
        series = SimpleNamespace(
            external_source="bangumi",
            external_id="bangumi:123",
            number_of_seasons=None,
            seasons=None,
        )
        evidence = season_evidence_from_series(series)
        assert evidence["single_season_entry"] is True
        assert verified_season_count(evidence) == 1


class TestVerifiedSeasonDefault:
    """_apply_verified_season_default: season=1 only when the matched entity
    proves a single season; otherwise season stays None + season_ambiguous."""

    def test_single_season_entity_defaults_to_1(self):
        meta = ResourceMetadata(
            clean_title="X", content_type="tv", found=True,
            matched_entity={"number_of_seasons": 1},
        )
        _apply_verified_season_default(meta)
        assert meta.season == 1
        assert meta.season_ambiguous is False

    def test_single_season_entry_defaults_without_work_count(self):
        meta = _meta(
            matched_entity={"single_season_entry": True},
        )
        _apply_verified_season_default(meta)
        assert meta.season == 1
        assert meta.season_ambiguous is False

    def test_single_entry_seasons_list_defaults_to_1(self):
        meta = ResourceMetadata(
            clean_title="X", content_type="tv", found=True,
            matched_entity={"seasons": [
                {"season_number": 0, "episode_count": 2},
                {"season_number": 1, "episode_count": 12},
            ]},
        )
        _apply_verified_season_default(meta)
        assert meta.season == 1
        assert meta.season_ambiguous is False

    def test_multi_season_entity_marks_ambiguous(self):
        meta = ResourceMetadata(
            clean_title="X", content_type="tv", found=True,
            matched_entity={"number_of_seasons": 4},
        )
        _apply_verified_season_default(meta)
        assert meta.season is None
        assert meta.season_ambiguous is True

    def test_no_seasons_data_marks_ambiguous(self):
        meta = ResourceMetadata(
            clean_title="X", content_type="tv", found=True,
            matched_entity={"title_cn": "X"},
        )
        _apply_verified_season_default(meta)
        assert meta.season is None
        assert meta.season_ambiguous is True

    def test_explicit_season_untouched(self):
        meta = ResourceMetadata(
            clean_title="X", content_type="tv", found=True, season=3,
            matched_entity={"number_of_seasons": 4},
        )
        _apply_verified_season_default(meta)
        assert meta.season == 3
        assert meta.season_ambiguous is False

    def test_movie_and_not_found_untouched(self):
        movie = ResourceMetadata(clean_title="X", content_type="movie", found=True)
        _apply_verified_season_default(movie)
        assert movie.season is None and movie.season_ambiguous is False
        nf = ResourceMetadata(clean_title="X", content_type="tv", found=False)
        _apply_verified_season_default(nf)
        assert nf.season is None and nf.season_ambiguous is False


class TestValidateInferredSeason:
    """_validate_inferred_season: an LLM-supplied season is only kept when the
    matched entity's evidence supports it; otherwise it is dropped + marked
    ambiguous (never create/link a guessed season)."""

    def test_season_within_explicit_count_kept(self):
        meta = ResourceMetadata(
            clean_title="X", content_type="tv", found=True, season=3,
            matched_entity={"number_of_seasons": 4},
        )
        _validate_inferred_season(meta)
        assert meta.season == 3
        assert meta.season_ambiguous is False

    def test_season_present_in_map_kept(self):
        meta = ResourceMetadata(
            clean_title="X", content_type="tv", found=True, season=2,
            matched_entity={"seasons": [
                {"season_number": 1, "episode_count": 12},
                {"season_number": 2, "episode_count": 12},
            ]},
        )
        _validate_inferred_season(meta)
        assert meta.season == 2
        assert meta.season_ambiguous is False

    def test_hallucinated_season_dropped(self):
        meta = ResourceMetadata(
            clean_title="X", content_type="tv", found=True, season=4,
            matched_entity={"number_of_seasons": 2},
        )
        _validate_inferred_season(meta)
        assert meta.season is None
        assert meta.season_ambiguous is True

    def test_season_absent_from_map_dropped(self):
        meta = ResourceMetadata(
            clean_title="X", content_type="tv", found=True, season=5,
            matched_entity={"seasons": [
                {"season_number": 1, "episode_count": 12},
            ]},
        )
        _validate_inferred_season(meta)
        assert meta.season is None
        assert meta.season_ambiguous is True

    def test_no_season_evidence_dropped(self):
        meta = ResourceMetadata(
            clean_title="X", content_type="tv", found=True, season=1,
            matched_entity={"title_cn": "X"},
        )
        _validate_inferred_season(meta)
        assert meta.season is None
        assert meta.season_ambiguous is True

    def test_specials_season_zero_kept(self):
        meta = ResourceMetadata(
            clean_title="X", content_type="tv", found=True, season=0,
            matched_entity={"number_of_seasons": 3},
        )
        _validate_inferred_season(meta)
        assert meta.season == 0
        assert meta.season_ambiguous is False

    def test_then_verified_default_recovers_single_season(self):
        # LLM guessed season 4 on a provably single-season work: the guess is
        # dropped, then the verified default pins the only real season.
        meta = ResourceMetadata(
            clean_title="X", content_type="tv", found=True, season=4,
            matched_entity={"number_of_seasons": 1},
        )
        _validate_inferred_season(meta)
        _apply_verified_season_default(meta)
        assert meta.season == 1
        assert meta.season_ambiguous is False

    def test_movie_not_found_and_no_season_untouched(self):
        movie = ResourceMetadata(
            clean_title="X", content_type="movie", found=True, season=2,
            matched_entity={"number_of_seasons": 1},
        )
        _validate_inferred_season(movie)
        assert movie.season == 2 and movie.season_ambiguous is False
        nf = ResourceMetadata(
            clean_title="X", content_type="tv", found=False, season=2,
            matched_entity={"number_of_seasons": 1},
        )
        _validate_inferred_season(nf)
        assert nf.season == 2 and nf.season_ambiguous is False
        none_season = ResourceMetadata(
            clean_title="X", content_type="tv", found=True, season=None,
            matched_entity={"number_of_seasons": 2},
        )
        _validate_inferred_season(none_season)
        assert none_season.season is None and none_season.season_ambiguous is False


# ---------------------------------------------------------------------------
# Batch 3: same-title works injection into the production message
# ---------------------------------------------------------------------------


def test_build_production_message_includes_same_title_context():
    agent = UnifiedMetadataAgent()
    resource = SimpleNamespace(
        title_raw="[G] 攻壳机动队 - 01 [1080p]", title_cn="攻壳机动队",
        title_en=None, subtitle_group=None, episode=1, season=None,
        resolution=None, source=None, video_codec=None, audio_codec=None,
        subtitle_type=None, container=None, title_year=None,
    )
    msg = agent._build_production_message(
        resource, SimpleNamespace(name="ch"),
        same_title_context="本地库存在同名作品: [攻壳机动队 (1995, movie)]; 结合标题年份选择正确作品",
    )
    assert "本地库存在同名作品" in msg
    assert "结合标题年份选择正确作品" in msg


def test_build_production_message_omits_same_title_context_when_none():
    agent = UnifiedMetadataAgent()
    resource = SimpleNamespace(
        title_raw="[G] Show - 01 [1080p]", title_cn=None,
        title_en=None, subtitle_group=None, episode=None, season=None,
        resolution=None, source=None, video_codec=None, audio_codec=None,
        subtitle_type=None, container=None, title_year=None,
    )
    msg = agent._build_production_message(resource, SimpleNamespace(name="ch"))
    assert "同名作品" not in msg


async def test_build_same_title_context_queries_local_db(db_session):
    """≥2 colliding local works → injection text; fewer → None."""
    import uuid
    from datetime import date

    from app.models.movie import Movie
    from app.models.series import TVSeries

    s = TVSeries(
        id=str(uuid.uuid4()), title_cn="攻壳机动队", content_type="tv",
        start_date=date(2002, 10, 1), number_of_seasons=2,
    )
    m = Movie(
        id=str(uuid.uuid4()), title_cn="攻壳机动队", content_type="movie",
        release_date=date(1995, 11, 18),
    )
    db_session.add_all([s, m])
    await db_session.flush()

    agent = UnifiedMetadataAgent()
    resource = SimpleNamespace(
        title_raw="[G] 攻壳机动队 2026 - 01", search_title="攻壳机动队",
    )
    ctx = await agent._build_same_title_context(resource, db_session)
    assert ctx is not None
    assert "本地库存在同名作品" in ctx
    assert "1995, movie" in ctx
    assert "2002, tv, 2 seasons" in ctx

    # Only one matching work → no injection.
    lone = SimpleNamespace(title_raw="[G] 狮子王 - 01", search_title="狮子王")
    assert await agent._build_same_title_context(lone, db_session) is None


# ---------------------------------------------------------------------------
# Batch 3: known-work short-circuit season rule (resolve_missing_season)
# ---------------------------------------------------------------------------

from app.services.metadata_episode_reconcile import resolve_missing_season  # noqa: E402


class TestResolveMissingSeason:
    """Shared verified-season helper for link paths that bypass
    ``_apply_to_resource`` (short-circuit / agent-free / manual link)."""

    @staticmethod
    def _r(**kw):
        base = dict(season=None, is_batch=False, episode_confidence=None, episode=5)
        base.update(kw)
        return SimpleNamespace(**base)

    def test_single_season_via_number_of_seasons_defaults_1(self):
        r = self._r()
        out = resolve_missing_season(r, {"number_of_seasons": 1, "seasons": None})
        assert out == "season-defaulted"
        assert r.season == 1
        assert r.episode_confidence is None

    def test_single_season_via_seasons_list_defaults_1(self):
        r = self._r()
        entity = {"seasons": [
            {"season_number": 0, "episode_count": 2},  # specials ignored
            {"season_number": 1, "episode_count": 12},
        ]}
        assert resolve_missing_season(r, entity) == "season-defaulted"
        assert r.season == 1

    def test_multi_season_marks_ambiguous(self):
        r = self._r()
        out = resolve_missing_season(r, {"number_of_seasons": 3})
        assert out == "marked-ambiguous"
        assert r.season is None
        assert r.episode_confidence == "ambiguous"

    def test_matching_bilingual_sequel_suffix_uses_verified_season(self):
        for title_cn, title_en in (
            ("乙女游戏世界对路人角色很不友好2", "Otome Game Sekai 2"),
            ("乡下大叔成为剑圣II", "Katainaka no Ossan II"),
        ):
            r = self._r(title_cn=title_cn, title_en=title_en)
            entity = {
                "number_of_seasons": 2,
                "seasons": [
                    {"season_number": 1, "episode_count": 12},
                    {"season_number": 2, "episode_count": 12},
                ],
            }
            assert resolve_missing_season(r, entity) == "season-title-inferred"
            assert r.season == 2
            assert r.episode_confidence == "raw"

    def test_single_or_unverified_bare_suffix_stays_ambiguous(self):
        single = self._r(title_cn="作品2", title_en=None)
        assert resolve_missing_season(single, {"number_of_seasons": 2}) == "marked-ambiguous"
        assert single.season is None

        unavailable = self._r(title_cn="作品III", title_en="Show III")
        assert resolve_missing_season(unavailable, {"number_of_seasons": 2}) == "marked-ambiguous"
        assert unavailable.season is None

    def test_unknown_season_count_marks_ambiguous(self):
        r = self._r()
        assert resolve_missing_season(r, {}) == "marked-ambiguous"
        assert r.season is None
        assert r.episode_confidence == "ambiguous"
        r2 = self._r()
        assert resolve_missing_season(r2, None) == "marked-ambiguous"

    def test_noop_when_season_known(self):
        r = self._r(season=2)
        assert resolve_missing_season(r, {"number_of_seasons": 3}) is None
        assert r.season == 2
        assert r.episode_confidence is None

    def test_batch_scope_none_single_season_defaults_1(self):
        """无季标记合集 + 作品可验证单季 → season=1（verified，非猜测）。"""
        r = self._r(is_batch=True, batch_scope=None, episode=None)
        out = resolve_missing_season(r, {"number_of_seasons": 1, "seasons": None})
        assert out == "season-defaulted"
        assert r.season == 1
        assert r.episode_confidence is None

    def test_batch_scope_season_single_season_defaults_1(self):
        r = self._r(is_batch=True, batch_scope="season", episode=None)
        entity = {"seasons": [
            {"season_number": 0, "episode_count": 2},  # specials ignored
            {"season_number": 1, "episode_count": 12},
        ]}
        assert resolve_missing_season(r, entity) == "season-defaulted"
        assert r.season == 1
        assert r.episode_confidence is None

    def test_batch_multi_season_never_ambiguous(self):
        """合集多季/无证据：不动 season，绝不标 ambiguous（走 coverage 门禁）。"""
        r = self._r(is_batch=True, batch_scope=None, episode=None)
        assert resolve_missing_season(r, {"number_of_seasons": 3}) is None
        assert r.season is None
        assert r.episode_confidence is None

    def test_batch_no_evidence_never_ambiguous(self):
        r = self._r(is_batch=True, batch_scope="season", episode=None)
        assert resolve_missing_season(r, {}) is None
        assert resolve_missing_season(r, None) is None
        assert r.season is None
        assert r.episode_confidence is None

    def test_batch_multi_scope_noop(self):
        """multi_season/franchise/movies 合集完全不取单季默认。"""
        for scope in ("multi_season", "franchise", "movies"):
            r = self._r(is_batch=True, batch_scope=scope, episode=None)
            assert resolve_missing_season(r, {"number_of_seasons": 1}) is None
            assert r.season is None
            assert r.episode_confidence is None

    def test_batch_manual_noop(self):
        r = self._r(is_batch=True, batch_scope=None, episode=None,
                    episode_confidence="manual")
        assert resolve_missing_season(r, {"number_of_seasons": 1}) is None
        assert r.season is None
        assert r.episode_confidence == "manual"

    def test_noop_for_manual(self):
        r = self._r(episode_confidence="manual")
        assert resolve_missing_season(r, {"number_of_seasons": 1}) is None
        assert r.season is None
        assert r.episode_confidence == "manual"


async def test_process_short_circuit_applies_verified_season_default(db_session, sample_channel):
    """Short-circuit to a provably single-season series defaults a season-less
    resource to season=1 (verified, not guessed)."""
    import uuid

    from app.models.file_resource import FileResource
    from app.models.series import TVSeries

    series = TVSeries(
        id=str(uuid.uuid4()), title_cn="单身季节剧", content_type="tv",
        number_of_seasons=1,
        seasons=[{"season_number": 1, "episode_count": 12}],
    )
    db_session.add(series)
    resource = FileResource(
        id=str(uuid.uuid4()), channel_id=sample_channel.id, guid="g_single",
        title_raw="[X] 单身季节剧 - 05 [1080p]",
        title_cn="单身季节剧", episode=5, season=None,
        torrent_url="magnet:?xt=urn:btih:single05",
    )
    db_session.add(resource)
    await db_session.commit()

    agent = UnifiedMetadataAgent()
    agent._run_react = AsyncMock()  # must NOT be called - short-circuit wins
    res = await agent.process(resource, sample_channel, db_session)

    agent._run_react.assert_not_called()
    assert res.found is True
    assert resource.series_id == series.id
    assert resource.season == 1
    assert resource.episode_confidence == "raw"  # in-range per-season number


async def test_process_short_circuit_marks_season_uncertain(db_session, sample_channel):
    """Short-circuit to a multi-season series: a season-less resource is
    marked 季号不确定 (ambiguous), never defaulted."""
    import uuid

    from app.models.file_resource import FileResource
    from app.models.series import TVSeries

    series = TVSeries(
        id=str(uuid.uuid4()), title_cn="多季剧短", content_type="tv",
        number_of_seasons=3,
        seasons=[{"season_number": n, "episode_count": 24} for n in (1, 2, 3)],
    )
    db_session.add(series)
    resource = FileResource(
        id=str(uuid.uuid4()), channel_id=sample_channel.id, guid="g_multi",
        title_raw="[X] 多季剧短 - 05 [1080p]",
        title_cn="多季剧短", episode=5, season=None,
        torrent_url="magnet:?xt=urn:btih:multi05",
    )
    db_session.add(resource)
    await db_session.commit()

    agent = UnifiedMetadataAgent()
    agent._run_react = AsyncMock()
    await agent.process(resource, sample_channel, db_session)

    agent._run_react.assert_not_called()
    assert resource.series_id == series.id
    assert resource.season is None
    assert resource.episode_confidence == "ambiguous"


async def test_process_short_circuit_derives_season_from_absolute(db_session, sample_channel):
    """Short-circuit with only an absolute-across-seasons number: reconcile
    derives the season BEFORE the season-uncertain rule runs, so no false
    季号不确定 marking."""
    import uuid

    from app.models.file_resource import FileResource
    from app.models.series import TVSeries

    series = TVSeries(
        id=str(uuid.uuid4()), title_cn="绝对集号剧", content_type="tv",
        number_of_seasons=4,
        seasons=[{"season_number": n, "episode_count": 24} for n in (1, 2, 3, 4)],
    )
    db_session.add(series)
    resource = FileResource(
        id=str(uuid.uuid4()), channel_id=sample_channel.id, guid="g_abs",
        title_raw="[X] 绝对集号剧 - 89 [1080p]",
        title_cn="绝对集号剧", episode=89, season=None, absolute_episode=89,
        episode_confidence="reconciled",
        torrent_url="magnet:?xt=urn:btih:abs89",
    )
    db_session.add(resource)
    await db_session.commit()

    agent = UnifiedMetadataAgent()
    agent._run_react = AsyncMock()
    await agent.process(resource, sample_channel, db_session)

    agent._run_react.assert_not_called()
    assert resource.series_id == series.id
    assert (resource.season, resource.episode) == (4, 17)
    assert resource.episode_confidence == "reconciled"



# ---------------------------------------------------------------------------
# _normalize_finalize_dates
# ---------------------------------------------------------------------------


def test_normalize_finalize_dates_tv_first_air_date_fills_start_date():
    from app.services.metadata_agent import _normalize_finalize_dates

    fd = {
        "found": True,
        "content_type": "tv",
        "matched_entity": {"first_air_date": "2023-10-08"},
    }
    _normalize_finalize_dates(fd)
    assert fd["matched_entity"]["start_date"] == "2023-10-08"


def test_normalize_finalize_dates_tv_release_date_fills_start_date():
    from app.services.metadata_agent import _normalize_finalize_dates

    fd = {
        "found": True,
        "content_type": "tv",
        "matched_entity": {"release_date": "2021-04-01"},
    }
    _normalize_finalize_dates(fd)
    assert fd["matched_entity"]["start_date"] == "2021-04-01"


def test_normalize_finalize_dates_tv_keeps_existing_start_date():
    from app.services.metadata_agent import _normalize_finalize_dates

    fd = {
        "found": True,
        "content_type": "tv",
        "matched_entity": {
            "start_date": "2020-01-01",
            "first_air_date": "2023-10-08",
        },
    }
    _normalize_finalize_dates(fd)
    assert fd["matched_entity"]["start_date"] == "2020-01-01"


def test_normalize_finalize_dates_movie_symmetric_branch():
    from app.services.metadata_agent import _normalize_finalize_dates

    fd = {
        "found": True,
        "content_type": "movie",
        "matched_entity": {"first_air_date": "2019-07-19"},
    }
    _normalize_finalize_dates(fd)
    assert fd["matched_entity"]["release_date"] == "2019-07-19"

    fd2 = {
        "found": True,
        "content_type": "movie",
        "matched_entity": {"start_date": "2019-07-19"},
    }
    _normalize_finalize_dates(fd2)
    assert fd2["matched_entity"]["release_date"] == "2019-07-19"


def test_normalize_finalize_dates_movie_keeps_existing_release_date():
    from app.services.metadata_agent import _normalize_finalize_dates

    fd = {
        "found": True,
        "content_type": "movie",
        "matched_entity": {
            "release_date": "2019-07-19",
            "first_air_date": "2020-01-01",
        },
    }
    _normalize_finalize_dates(fd)
    assert fd["matched_entity"]["release_date"] == "2019-07-19"


def test_normalize_finalize_dates_no_entity_or_no_source_key_is_noop():
    from app.services.metadata_agent import _normalize_finalize_dates

    fd = {"found": False, "content_type": "tv"}
    _normalize_finalize_dates(fd)
    assert "matched_entity" not in fd

    fd2 = {"found": True, "content_type": "tv", "matched_entity": {"title_cn": "x"}}
    _normalize_finalize_dates(fd2)
    assert "start_date" not in fd2["matched_entity"]


# ---------------------------------------------------------------------------
# Tool wrappers: JSON serialization + finalize sentinel
# ---------------------------------------------------------------------------

import app.services.metadata_agent as ma_module  # noqa: E402


async def test_search_tmdb_tool_serializes_result(monkeypatch):
    """The @tool wrapper JSON-serializes the source result with unicode kept."""
    import json as _json

    monkeypatch.setattr(
        ma_module,
        "_execute_search_tmdb",
        AsyncMock(return_value={"success": True, "data": [{"tmdb_id": 1, "title_cn": "葬送的芙莉莲"}]}),
    )
    out = await ma_module.search_tmdb.coroutine("query")
    parsed = _json.loads(out)
    assert parsed["success"] is True
    assert parsed["data"][0]["title_cn"] == "葬送的芙莉莲"


async def test_get_tmdb_details_tool_serializes_result(monkeypatch):
    import json as _json

    monkeypatch.setattr(
        ma_module,
        "_execute_get_tmdb_details",
        AsyncMock(return_value={"success": True, "data": {"number_of_seasons": 2}}),
    )
    out = await ma_module.get_tmdb_details.coroutine("85937", "tv")
    assert _json.loads(out)["data"]["number_of_seasons"] == 2


async def test_search_wikipedia_tool_serializes_result(monkeypatch):
    import json as _json

    monkeypatch.setattr(
        ma_module,
        "_execute_search_wikipedia",
        AsyncMock(return_value={"success": True, "data": [{"title": "Show"}]}),
    )
    out = await ma_module.search_wikipedia.coroutine("Show", lang="zh")
    assert _json.loads(out)["data"][0]["title"] == "Show"


async def test_get_wikipedia_page_tool_serializes_result(monkeypatch):
    import json as _json

    monkeypatch.setattr(
        ma_module,
        "_execute_get_wikipedia_page",
        AsyncMock(return_value={"success": True, "data": {"title": "Show", "categories": {}}}),
    )
    out = await ma_module.get_wikipedia_page.coroutine("Show", lang="zh")
    assert _json.loads(out)["data"]["title"] == "Show"


def test_finalize_tool_returns_sentinel():
    assert ma_module.finalize.func("{}") == "FINALIZED"


def test_title_year_hint_mentions_the_parsed_year():
    hint = ma_module._title_year_hint(2005)
    assert "2005" in hint
    assert "strong evidence" in hint


# ---------------------------------------------------------------------------
# Genre helpers: _parse_genre_array
# ---------------------------------------------------------------------------


def test_parse_genre_array_extracts_first_array_and_clamps():
    from app.services.metadata_agent import _parse_genre_array
    assert _parse_genre_array('Genres: ["Animation", "Adventure"]') == ["Animation", "Adventure"]
    assert _parse_genre_array("no brackets") == []
    assert _parse_genre_array(None) == []


def test_parse_genre_array_returns_empty_on_bad_json():
    from app.services.metadata_agent import _parse_genre_array
    assert _parse_genre_array("prefix [ {invalid json] tail") == []


# ---------------------------------------------------------------------------
# _agent_for_source lazy graph construction
# ---------------------------------------------------------------------------


def test_agent_for_source_builds_and_caches_one_graph_per_source(monkeypatch):
    created: list[list] = []

    def _fake_create(model, tools, prompt):
        created.append(tools)
        return object()

    monkeypatch.setattr(ma_module, "create_react_agent", _fake_create)
    agent = UnifiedMetadataAgent()
    a = agent._agent_for_source("tmdb")
    b = agent._agent_for_source("tmdb")
    c = agent._agent_for_source("wikipedia")
    d = agent._agent_for_source(None)  # normalizes to wikipedia
    assert a is b
    assert c is d
    assert len(created) == 2


# ---------------------------------------------------------------------------
# _ensure_genre: synopsis-based genre fallback
# ---------------------------------------------------------------------------


async def test_ensure_genre_infers_from_synopsis():
    agent = UnifiedMetadataAgent()
    agent._model = MagicMock()
    resp = MagicMock()
    resp.content = '["Animation", "Adventure"]'
    agent._model.ainvoke = AsyncMock(return_value=resp)
    fd = {"found": True, "matched_entity": {
        "title_cn": "Show", "description": "A synopsis that describes the show.",
    }}
    await agent._ensure_genre(fd)
    assert fd["matched_entity"]["genre"] == ["Animation", "Adventure"]


async def test_ensure_genre_handles_non_string_content():
    """A list-typed model response is JSON-dumped before array extraction."""
    agent = UnifiedMetadataAgent()
    agent._model = MagicMock()
    resp = MagicMock()
    resp.content = ["Animation"]
    agent._model.ainvoke = AsyncMock(return_value=resp)
    fd = {"found": True, "matched_entity": {
        "title_cn": "Show", "description": "A synopsis.",
    }}
    await agent._ensure_genre(fd)
    assert fd["matched_entity"]["genre"] == ["Animation"]


async def test_ensure_genre_llm_failure_is_silent():
    """An LLM error must not block or invalidate the match."""
    agent = UnifiedMetadataAgent()
    agent._model = MagicMock()
    agent._model.ainvoke = AsyncMock(side_effect=RuntimeError("llm down"))
    fd = {"found": True, "matched_entity": {
        "title_cn": "Show", "description": "A synopsis.",
    }}
    await agent._ensure_genre(fd)
    assert "genre" not in fd["matched_entity"]


async def test_ensure_genre_noop_without_description_or_with_genre():
    agent = UnifiedMetadataAgent()
    agent._model = MagicMock()
    agent._model.ainvoke = AsyncMock(return_value=MagicMock(content="[]"))
    await agent._ensure_genre({"found": True, "matched_entity": {"title_cn": "X"}})
    await agent._ensure_genre({"found": True, "matched_entity": {
        "genre": ["Animation"], "description": "desc",
    }})
    agent._model.ainvoke.assert_not_called()


# ---------------------------------------------------------------------------
# _attach_tmdb_episode_list guards + fill
# ---------------------------------------------------------------------------


async def test_attach_tmdb_episode_list_skips_ineligible(monkeypatch):
    fetch = AsyncMock()
    monkeypatch.setattr(ma_module, "fetch_tmdb_episode_list", fetch)
    await ma_module._attach_tmdb_episode_list({"found": False, "content_type": "tv"})
    await ma_module._attach_tmdb_episode_list({"found": True, "content_type": "movie"})
    await ma_module._attach_tmdb_episode_list({"found": True, "content_type": "tv", "matched_entity": {}})
    await ma_module._attach_tmdb_episode_list({"found": True, "content_type": "tv",
                                              "matched_entity": {"episode_list": ["x"]}})
    fetch.assert_not_called()


async def test_attach_tmdb_episode_list_requires_tmdb_id_and_seasons(monkeypatch):
    fetch = AsyncMock()
    monkeypatch.setattr(ma_module, "fetch_tmdb_episode_list", fetch)
    await ma_module._attach_tmdb_episode_list({"found": True, "content_type": "tv", "matched_entity": {
        "external_id": "mal:123", "external_source": "mal",
        "seasons": [{"season_number": 1}],
    }})
    await ma_module._attach_tmdb_episode_list({"found": True, "content_type": "tv", "matched_entity": {
        "external_id": "tmdb:9", "external_source": "tmdb",
    }})
    fetch.assert_not_called()


async def test_attach_tmdb_episode_list_fills_from_prefix_id(monkeypatch):
    fetch = AsyncMock(return_value=[{"episode_number": 1}])
    monkeypatch.setattr(ma_module, "fetch_tmdb_episode_list", fetch)
    fd = {"found": True, "content_type": "tv", "matched_entity": {
        "external_id": "tmdb:9", "external_source": "tmdb",
        "seasons": [{"season_number": 1}],
    }}
    await ma_module._attach_tmdb_episode_list(fd)
    assert fd["matched_entity"]["episode_list"] == [{"episode_number": 1}]
    fetch.assert_awaited_once()
    fetch.assert_awaited_with("9", [{"season_number": 1}])


async def test_attach_tmdb_episode_list_numeric_id_without_prefix(monkeypatch):
    fetch = AsyncMock(return_value=[{"episode_number": 1}])
    monkeypatch.setattr(ma_module, "fetch_tmdb_episode_list", fetch)
    fd = {"found": True, "content_type": "tv", "matched_entity": {
        "external_id": "123", "external_source": "tmdb",
        "seasons": [{"season_number": 1}],
    }}
    await ma_module._attach_tmdb_episode_list(fd)
    fetch.assert_awaited_once()
    fetch.assert_awaited_with("123", [{"season_number": 1}])


# ---------------------------------------------------------------------------
# _run_react success + invocation-failure paths
# ---------------------------------------------------------------------------


async def test_run_react_success_extracts_finalize():
    agent = UnifiedMetadataAgent()
    fake = MagicMock()
    fake.ainvoke = AsyncMock(return_value={"messages": [
        _ai_message("search_wikipedia", {"query": "Show", "lang": "en"}),
        _tool_message("search_wikipedia", {"success": True, "data": [
            {"page_id": 123, "url": "https://en.wikipedia.org/wiki/Show"}]}, "search_wikipedia"),
        _ai_message("finalize", {"result_json": (
            '{"found": true, "clean_title": "Show", "content_type": "tv", '
            '"matched_entity": {"external_id": "wikipedia:en:123"}}'
        )}),
    ]})
    agent._agent_for_source = MagicMock(return_value=fake)
    finalize_dict, info = await agent._run_react("msg", "wikipedia")
    assert finalize_dict["found"] is True
    assert finalize_dict["matched_entity"]["external_id"] == "wikipedia:en:123"
    assert info == {"method": "wikipedia", "data_sources_used": ["wikipedia"], "source_errors": {}, "error": None}


async def test_run_react_invocation_failure_is_wrapped_transient():
    agent = UnifiedMetadataAgent()
    fake = MagicMock()
    fake.ainvoke = AsyncMock(side_effect=RuntimeError("boom"))
    agent._agent_for_source = MagicMock(return_value=fake)
    finalize_dict, info = await agent._run_react("msg", "wikipedia")
    assert finalize_dict["found"] is False
    assert "Agent error: boom" in finalize_dict["reason"]
    assert info["error"] == "boom"
    assert info["data_sources_used"] == ["wikipedia"]


# ---------------------------------------------------------------------------
# _extract_finalize_result branches
# ---------------------------------------------------------------------------


def test_extract_finalize_result_parses_last_ai_finalize():
    agent = UnifiedMetadataAgent()
    messages = [
        _ai_message("search_wikipedia", {"query": "q"}),
        _ai_message("finalize", {"result_json": '{"found": true}'}),
    ]
    assert agent._extract_finalize_result(messages) == {"found": True}


def test_extract_finalize_result_skips_bad_ai_json_then_uses_tool_message():
    agent = UnifiedMetadataAgent()
    messages = [
        _ai_message("finalize", {"result_json": "{not json"}),
        _tool_message("finalize", {"found": True}, "finalize"),
    ]
    assert agent._extract_finalize_result(messages) == {"found": True}


def test_extract_finalize_result_no_finalize_returns_default():
    from langchain_core.messages import ToolMessage

    agent = UnifiedMetadataAgent()
    messages = [
        _ai_message("search_wikipedia", {"query": "q"}),
        ToolMessage(content='["not", "a", "dict"]', name="finalize", tool_call_id="f"),
    ]
    out = agent._extract_finalize_result(messages)
    assert out["found"] is False
    assert "did not call finalize" in out["reason"]


def test_extract_finalize_result_unparseable_tool_message_returns_default():
    """A finalize ToolMessage with non-JSON content is skipped (no crash)."""
    from langchain_core.messages import ToolMessage

    agent = UnifiedMetadataAgent()
    messages = [ToolMessage(content="not json", name="finalize", tool_call_id="f")]
    out = agent._extract_finalize_result(messages)
    assert out["found"] is False
    assert "did not call finalize" in out["reason"]


# ---------------------------------------------------------------------------
# _extract_search_info tool-branch coverage
# ---------------------------------------------------------------------------


def test_extract_search_info_covers_all_tool_branches():
    from langchain_core.messages import ToolMessage

    messages = [
        _ai_message("search_tmdb", {"query": "x"}),
        _ai_message("get_tmdb_details", {"tmdb_id": "1", "media_type": "tv"}),
        _ai_message("search_wikipedia", {"query": "y"}),
        _ai_message("get_wikipedia_page", {"title": "y"}),
        _tool_message("search_tmdb", {"success": False, "error": "TMDB 500"}, "search_tmdb"),
        _tool_message("search_tmdb", {"success": True, "data": []}, "search_tmdb"),
        ToolMessage(content="not json", name="search_tmdb", tool_call_id="c1"),
        _tool_message("get_tmdb_details", {"success": False, "error": "details boom"}, "get_tmdb_details"),
        ToolMessage(content="not json", name="get_tmdb_details", tool_call_id="c2"),
        ToolMessage(content="not json", name="search_wikipedia", tool_call_id="c3"),
    ]
    info = UnifiedMetadataAgent._extract_search_info(messages)
    assert info["method"] == "tmdb|wikipedia"
    assert info["data_sources_used"] == ["tmdb", "wikipedia"]
    assert info["source_errors"] == {"tmdb": "TMDB 500"}
    assert "TMDB 500" in info["error"]


# ---------------------------------------------------------------------------
# process(): remaining edge branches
# ---------------------------------------------------------------------------


async def test_process_empty_title_returns_none():
    agent = UnifiedMetadataAgent()
    res = await agent.process(SimpleNamespace(title_raw="   "), SimpleNamespace(), MagicMock())
    assert res is None


async def test_process_applies_cached_success_without_rerun():
    """A definitive cached success (found + entity) short-circuits the live run."""
    agent = _patched_agent()
    cached = _meta(found=True, matched_entity={"external_id": "x"})
    agent._get_cache.return_value = cached
    resource = _ns_resource()
    res = await agent.process(resource, SimpleNamespace(id="ch", metadata_source=None), MagicMock())
    agent._run_react.assert_not_called()
    agent._apply_to_resource.assert_called_once()
    assert res is cached
    assert resource.metadata_attempts == 1
    assert resource.metadata_failure_type is None


async def test_process_applies_cached_non_work_immediately():
    agent = _patched_agent()
    cached = _meta(found=False, reason="The RSS entry is a music album release")
    agent._get_cache.return_value = cached
    res = await agent.process(_ns_resource(), SimpleNamespace(id="ch", metadata_source=None), MagicMock())
    agent._run_react.assert_not_called()
    assert res.found is False
    assert res.reason == "The RSS entry is a music album release"


async def test_process_short_circuit_movie_links_movie_id():
    """The movie half of the S1 known-work branch (movie_id set, series_id cleared)."""
    agent = _patched_agent()
    agent._get_cache = AsyncMock(return_value=None)
    agent._find_known_work = AsyncMock(return_value=("movie", "m-123"))
    resource = SimpleNamespace(
        title_raw="[G] Some Movie 2025 [1080p]", title_cn="Some Movie", title_en=None,
        search_title=None, series_id=None, movie_id=None,
        metadata_attempts=0, last_metadata_attempt_at=None, metadata_failure_type=None,
    )
    meta = await agent.process(
        resource, SimpleNamespace(id="ch", metadata_source=None), MagicMock()
    )
    assert meta.found is True
    assert meta.content_type == "movie"
    assert resource.movie_id == "m-123"
    assert resource.series_id is None
    assert resource.search_title == "Some Movie"


async def test_process_non_media_is_non_work_and_cached():
    agent = _patched_agent()
    agent._get_cache.return_value = None
    resource = _ns_resource()
    resource.title_raw = "BitComet Stable (build 2.21.6.23) 比特彗星全功能解锁豪华版"
    meta = await agent.process(resource, SimpleNamespace(id="ch", metadata_source=None), MagicMock())
    agent._run_react.assert_not_called()
    assert meta.found is False
    assert "non-media" in meta.reason
    agent._apply_to_resource.assert_called_once()
    agent._set_cache.assert_called_once()
    assert resource.metadata_failure_type == "non_work"


async def test_process_routes_tmdb_to_react_then_web_fallback(monkeypatch):
    """A tmdb-source channel runs ReAct, then the web fallback (here disabled)."""
    agent = _stub_agent()
    agent._run_react.return_value = (
        {"found": False, "clean_title": "X", "content_type": "tv",
         "reason": "No matching work found in TMDB"},
        {"method": "react", "data_sources_used": ["tmdb"], "source_errors": {}, "error": None},
    )
    monkeypatch.setattr(ma_module, "web_fallback_judge", AsyncMock(return_value=None))
    channel = SimpleNamespace(
        id="ch", metadata_source="tmdb", metadata_fallback_sources=None, name="ch",
    )
    meta = await agent.process(_ns_resource(), channel, MagicMock())
    agent._run_react.assert_called_once()
    assert meta.found is False


# ---------------------------------------------------------------------------
# process_title_only edge branches
# ---------------------------------------------------------------------------


async def test_process_title_only_empty_title(monkeypatch):
    from app.services import runtime_config as _rc

    monkeypatch.setitem(_rc._overrides, "llm_api_key", None)
    # The agent constructor still builds a ChatOpenAI client; without any key
    # in the environment (CI) the SDK raises at construction. A dummy
    # OPENAI_API_KEY satisfies the SDK while the None override keeps the
    # code path under test ("no key configured").
    monkeypatch.setenv("OPENAI_API_KEY", "dummy")
    agent = UnifiedMetadataAgent()
    meta = await agent.process_title_only("   ")
    assert meta.found is False
    assert meta.reason == "Empty title"


async def test_process_title_only_without_llm_key(monkeypatch):
    from app.services import runtime_config as _rc

    monkeypatch.setitem(_rc._overrides, "llm_api_key", None)
    monkeypatch.setenv("OPENAI_API_KEY", "dummy")
    agent = UnifiedMetadataAgent()
    meta = await agent.process_title_only("Some Show - 01")
    assert meta.found is False
    assert meta.reason == "LLM API key not configured"


async def test_process_title_only_wikipedia_routes_search_then_judge(monkeypatch):
    agent = _title_only_agent(monkeypatch)
    agent._run_search_then_judge = AsyncMock(return_value=(
        {"found": True, "clean_title": "Show", "content_type": "tv",
         "matched_entity": {"external_id": "wikipedia:en:1"}},
        {"method": "search_then_judge", "data_sources_used": ["wikipedia"],
         "source_errors": {}, "error": None},
    ))
    meta = await agent.process_title_only("[G] Show - 01", "wikipedia")
    agent._run_search_then_judge.assert_awaited_once()
    assert meta.found is True


async def test_process_title_only_bangumi_with_season_hint(monkeypatch):
    """season_hint builds the lightweight hint_resource for the bangumi flow."""
    from app.services import metadata_bangumi as _mb

    monkeypatch.setattr(
        _mb, "run_bangumi_search_then_judge", AsyncMock(return_value=_bangumi_found())
    )
    agent = _title_only_agent(monkeypatch)
    meta = await agent.process_title_only("Show - 01", "bangumi", season_hint=2)
    assert meta.found is True
    assert meta.matched_entity["external_id"] == "bangumi:400602"


async def test_process_title_only_tmdb_react_and_fallback(monkeypatch):
    """Title-only tmdb path: ReAct message (with year hint) then web fallback."""
    agent = _title_only_agent(monkeypatch)
    agent._run_react = AsyncMock(return_value=(
        {"found": False, "clean_title": "Show", "content_type": "tv", "reason": "no match"},
        {"method": "react", "data_sources_used": ["tmdb"], "source_errors": {}, "error": None},
    ))
    monkeypatch.setattr(ma_module, "web_fallback_judge", AsyncMock(return_value=None))
    meta = await agent.process_title_only("Some Show 2005 - 01", "tmdb")
    agent._run_react.assert_awaited_once()
    assert meta.found is False


# ---------------------------------------------------------------------------
# _maybe_web_fallback: fallback search failure is transient
# ---------------------------------------------------------------------------


async def test_maybe_web_fallback_failure_is_transient(monkeypatch):
    fb = AsyncMock(return_value=(
        {"found": False, "clean_title": "X", "content_type": "tv", "reason": "no match"},
        {"method": "web", "data_sources_used": ["wigolo"],
         "source_errors": {"wigolo": "502"}, "error": "wigolo HTTP 502"},
    ))
    monkeypatch.setattr(ma_module, "web_fallback_judge", fb)
    agent = UnifiedMetadataAgent()
    fd = {"found": False, "clean_title": "X", "content_type": "tv",
          "reason": "No matching work found in TMDB"}
    info = {"method": "react", "data_sources_used": ["tmdb"], "source_errors": {}, "error": None}
    out_fd, out_info = await agent._maybe_web_fallback(fd, info, "X")
    assert out_fd["reason"] == "wigolo HTTP 502"
    assert out_info["method"] == "react_then_web_fallback"
    assert out_info["error"] == "wigolo HTTP 502"
    assert out_info["data_sources_used"] == ["tmdb", "wigolo"]


# ---------------------------------------------------------------------------
# Message builders: year hints
# ---------------------------------------------------------------------------


def test_build_title_only_message_appends_year_hint():
    agent = UnifiedMetadataAgent()
    msg = agent._build_title_only_message("Some Show 2005 - 01", "tmdb")
    assert "2005" in msg


def test_build_production_message_appends_title_year_hint():
    agent = UnifiedMetadataAgent()
    resource = SimpleNamespace(
        title_raw="[G] Show - 01", title_cn=None, title_en=None,
        subtitle_group=None, episode=None, season=None,
        resolution=None, source=None, video_codec=None, audio_codec=None,
        subtitle_type=None, container=None, title_year=2026,
    )
    msg = agent._build_production_message(resource, SimpleNamespace(name="ch"))
    assert "2026" in msg


# ---------------------------------------------------------------------------
# Module-level agent singleton
# ---------------------------------------------------------------------------


def test_get_agent_returns_and_caches_singleton():
    ma_module._agent_instance = None
    try:
        a = ma_module.get_agent()
        b = ma_module.get_agent()
        assert a is b
        assert isinstance(a, ma_module.UnifiedMetadataAgent)
    finally:
        ma_module.reset_metadata_agent()


def test_reset_metadata_agent_clears_singleton():
    ma_module._agent_instance = object()
    ma_module.reset_metadata_agent()
    assert ma_module._agent_instance is None
